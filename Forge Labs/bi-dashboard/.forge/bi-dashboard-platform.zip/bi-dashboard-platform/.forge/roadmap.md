---
type: roadmap
status: approved
generated_at: 2026-09-29
derived_from: .forge/prd.md
version: 1
---

# Roadmap — Plateforme BI configurable

> Ce document définit **ce qui sera livré et dans quel ordre**. Chaque règle métier citée
> référence son ID source dans `.forge/prd.md` (`B*`, `C*`, `US-*`).
>
> Une roadmap n'est pas une liste de tâches : c'est un **ordre d'arbitrage**. Ce qui est
> repoussé compte autant que ce qui est livré, et le pourquoi est la partie qui ne s'oublie pas.
>
> **Cette roadmap est vivante en un sens précis** : elle est un engagement de _séquence_, pas de
> _date_. Aucune échéance n'y figure, parce qu'aucune mesure de vélocité n'existe encore sur ce
> projet. Inventer des dates serait du bruit : elles se lisent comme un engagement, elles ne
> s'appuient sur rien.

---

## 1. Vision par version

| Version    | Thème / promesse                                                  | Critère de succès principal                                                 |
| ---------- | ----------------------------------------------------------------- | --------------------------------------------------------------------------- |
| Fondations | Un noyau qui ignore l'interface, la base de données et les droits | Le noyau s'exécute sans React, sans base, sans authentification             |
| MVP        | Un non-développeur publie sa première vue, seul                   | Une vue est créée, publiée et rouverte **sans intervention de développeur** |
| V1         | Plusieurs personnes, plusieurs droits, plusieurs versions         | Deux administrateurs aux droits distincts coexistent sans se marcher dessus |
| V1.5       | **Un second projet consomme le noyau**                            | Un composant **sans DOM** rend le socle — la preuve que `C6` tient          |
| V2+        | Ce que la V1 aura appris                                          | Chaque entrée a une **raison** tirée des retours, pas une envie             |

**Pourquoi V1.5 existe et n'est pas un caprice de découpage.** C'est la tranche la plus importante
du document, et c'est la moins évidente en apparence. `C6` interdit d'extraire le socle en
bibliothèque tant qu'aucun second projet ne l'a consommé : avant ça, « c'est réutilisable » reste
une **hypothèse**, pas un fait. Or Elora (`C6`, mobile, sans DOM) est le test le plus sévère
disponible : un socle qui tient dans un composant sans DOM n'a aucune dépendance cachée à une
interface web. Si la V1.5 réussit, l'extraction en package est **autorisée**. Si elle échoue,
l'échec est bon marché — mieux vaut le découvrir sur Elora qu'après avoir publié un package npm.

**Pourquoi il n'y a pas de V2 dans ce document.** Écrire une V2 sans retour de la V1, c'est
inventer des priorités. La section 4 est un **carnet de candidats** avec leurs conditions
d'entrée, pas un calendrier. Ce qui n'a pas de condition d'entrée n'y entre pas.

---

## 2. Fondations — avant tout produit

> Le socle n'existe pas tant que le noyau ne sait pas faire deux choses : valider une
> configuration **sans** interface, et **ne rien** stocker.

### 2.1 Périmètre

| Élément                                               | Règles (B*/C*) | Justification                                                                                               |
| ----------------------------------------------------- | -------------- | ----------------------------------------------------------------------------------------------------------- |
| Schéma de configuration versionné                     | `B2`, ADR-003  | Un indicateur est une **référence** ; aucun code exécutable ne doit pouvoir entrer dans le JSON             |
| Validation pure, sans React ni DOM                    | `C1`, `C3`     | Le noyau ne doit dépendre d'aucune bibliothèque d'interface, sinon il n'est pas un noyau                    |
| Ports : sources, exécution, persistance, autorisation | `C1`, `C2`     | Le socle définit ce qu'il ignore : il ne choisit ni la base, ni l'authentification, ni le moteur de requête |
| Port de **composants** par capacité                   | ADR-004        | Un registre remplace les imports codés en dur — c'est ce qui rend Elora possible (§ 1)                      |
| Journal d'exécution expurgé                           | `B28`          | Poser le format du journal **avant** d'écrire la première vue : c'est un format qu'on ne change pas         |
| Scan de corruption de caractères                      | —              | Outillage déjà écrit et auto-testé ; il s'applique à tout code produit ensuite                              |

### 2.2 Ce qui n'est PAS dans les fondations

| Élément                     | Raison                                                                        | Version cible |
| --------------------------- | ----------------------------------------------------------------------------- | ------------- |
| Composants React            | Le noyau n'a pas de rendu ; le réagitif est séparé et remplaçable             | MVP           |
| Persistance                 | `C1` — le socle ne choisit pas de base ; le pilote implémente le port         | MVP           |
| Grille, graphiques, filtres | Aucun besoin tant qu'aucune vue n'existe ; les anticiper retarderait le noyau | MVP           |

### 2.3 Risques

| Risque                                                                         | Prob.  | Impact | Mitigation                                                                 |
| ------------------------------------------------------------------------------ | ------ | ------ | -------------------------------------------------------------------------- |
| Le noyau glisse vers le web par inadvertance, et devient non testable hors DOM | MOYEN  | ÉLEVÉ  | Test du noyau **sans** React dans la boucle ; `C3` est un critère de revue |
| Un port trop abstrait pour être implémenté par un hôte                         | MOYEN  | MOYEN  | Écrire un **deuxième** implémentateur avant de figer un port               |
| Le format du journal doit changer après coup                                   | FAIBLE | ÉLEVÉ  | Le poser en fondations, avec la rétention `B29`                            |

---

## 3. MVP — une vue, publiée, par une personne seule

> Le plus petit ensemble qui résout le problème principal et peut être utilisé par de vraies
> personnes, **sans développeur dans la boucle**.

### 3.1 Périmètre

| US (PRD)                         | Règles (B*)                                           | Justification de l'inclusion                                                  |
| -------------------------------- | ----------------------------------------------------- | ----------------------------------------------------------------------------- |
| US-1 : consulter ses vues        | `B1`                                                  | Sans lecture, rien n'est démontrable                                          |
| US-2 : créer une vue — étape 1   | `B1`                                                  | Nom obligatoire ; description facultative par défaut                          |
| US-3 : créer une vue — étape 2   | `B3`, `B4`, `B25`                                     | Le cœur du besoin : choisir des **variables déclarées**, pas des champs       |
| US-4 : créer une vue — étape 3   | `B26`                                                 | Disposition et **ordre stable** : deux ouvertures, même résultat              |
| US-5 : publier une vue           | `B27`                                                 | La publication **vide est refusée** — c'est une garde, pas une fonctionnalité |
| US-9 : consommer une vue publiée | `B7`, `B14`, `B22`                                    | Sans consommation, le MVP ne prouve rien                                      |
| US-13 : recevoir un refus        | `B21`                                                 | Un refus incomprehensible fait abandonner ; il fait partie du chemin nominal  |
| US-14 : ne rien voir d'interdit  | `B6`, `B8`, `B23`                                     | L'absence de fuite est une fonctionnalité, pas une propriété implicite        |
| —                                | `B25` (contrôle sur **tout** chemin vers les données) | C'est le filet unique sous US-3, US-9 et US-14                                |

**US-6, US-7, US-8, US-10, US-11, US-12 sont hors MVP** — la section 3.2 dit pourquoi, tranche
par tranche, et c'est là que se joue la crédibilité de ce découpage.

### 3.2 Ce qui n'est PAS dans le MVP

| Élément                                          | Raison                                                                                                                                                   | Risque de l'exclusion                                     | Cible |
| ------------------------------------------------ | -------------------------------------------------------------------------------------------------------------------------------------------------------- | --------------------------------------------------------- | ----- |
| **US-6** modifier sans casser la version publiée | Un MVP à un seul auteur n'a rien à casser : personne d'autre ne lit. La version immobile est **plus simple** à travers et révèle moins de trous          | On découvre la régression de version au moment du partage | V1    |
| **US-7** partager                                | Exige US-6. Partager une vue qu'on ne peut pas éditer proprement revient à diffuser un brouillon                                                         | Le MVP ne démontre pas la valeur collective               | V1    |
| **US-8** dupliquer                               | Dépend de US-7 : dupliquer suppose qu'on lise une vue qui n'est pas la sienne                                                                            | Sans elle, un lecteur ne peut rien faire de ce qu'il voit | V1    |
| **US-10** assistant d'installation               | Utile à l'**intégrateur**, pas à l'utilisateur final. Un assistant qui n'a rien à générer n'a rien à prouver                                             | L'intégration devient manuelle pour le pilote             | V1    |
| **US-11** vues par défaut et journal             | N'a de sens qu'à plusieurs profils. À une personne, une vue par défaut est sa vue                                                                        | L'administration n'est pas testée avant qu'elle existe    | V1    |
| **US-12** origine et fraîcheur des chiffres      | Le MVP doit d'abord produire des chiffres **juste** avant d'expliquer d'où ils viennent                                                                  | Un utilisateur peut lire un chiffre périmé sans le savoir | V1    |
| **US-6 + B30 filtrage croisé**                   | Le filtrage croisé est retained en **V1** : il supprime l'anti-pattern du « total qui ne mène nulle part » à coût bien moindre que la descente en détail | Un total ne mène nulle part dans le MVP                   | V1    |

### 3.3 Risques spécifiques au MVP

| Risque                                                       | Prob. | Impact | Mitigation                                                                                                   |
| ------------------------------------------------------------ | ----- | ------ | ------------------------------------------------------------------------------------------------------------ |
| Le MVP ne prouve que l'**observation**, pas l'**analyse**    | ÉLEVÉ | MOYEN  | C'est assumé et écrit : le filtrage croisé arrive en V1, sinon le MVP n'a aucun intérêt exploratoire         |
| Une seule personne : les conflits de droits ne se voient pas | ÉLEVÉ | MOYEN  | Les contrôles `B7`/`B25` sont testés **contre le contrat backend réel**, pas en monopersonne (`security.md`) |
| Le pilote ne respecte pas une frontière du noyau             | MOYEN | ÉLEVÉ  | Test du noyau sans React dès les fondations (§ 2.3)                                                          |

---

## 4. V1 — plusieurs personnes, plusieurs droits

> Le MVP est mono-utilisateur. La V1 est le moment où le produit cesse d'être un outil et devient
> une **organisation** : plusieurs personnes, plusieurs versions, plusieurs périmètres.

### 4.1 Ajouts par rapport au MVP

| US (PRD)                               | Règles (B*)           | Justification                                                                                |
| -------------------------------------- | --------------------- | -------------------------------------------------------------------------------------------- |
| US-6 : modifier sans casser la publiée | `B11`–`B15`           | Le versionnage est ce qui autorise ensuite le partage sans risque                            |
| US-7 : partager                        | `B16`, `B17`, `B18`   | Partage nominatif **et** groupes ; un partage ne confère aucun droit nouveau                 |
| US-8 : dupliquer                       | `B19`                 | Le lecteur doit pouvoir agir sans devenir auteur ; le filtre est essentiel au partage        |
| US-10 : assistant d'installation       | `B24`                 | Économise le **retour arrière** et la détection : c'est le levier d'intégration, pas un luxe |
| US-11 : vues par défaut et journal     | `B10b`, `B28`–`B35`   | `journal:read` distinct par défaut ; la consultation est elle-même journalisée               |
| US-12 : origine et fraîcheur           | `B14`, `B21`, `B22`   | Un chiffre sans date n'est pas un chiffre, c'est une impression                              |
| —                                      | `B30` filtrage croisé | Le correctif au total qui ne mène nulle part, à coût minimal                                 |

### 4.2 Ce qui est repoussé en V2+

| Élément                        | Raison                                                                                                                           | Risque                                                                        |
| ------------------------------ | -------------------------------------------------------------------------------------------------------------------------------- | ----------------------------------------------------------------------------- |
| Descente en détail             | Hors périmètre au PRD (§ 9) : c'est une capacité d'exécution supplémentaire avec ses propres règles d'accès, pas une navigation  | Une investigation reste impossible ; le filtrage croisé couvre le cas courant |
| Export de données              | Hors périmètre (§ 9) ; chaque format est un contrat de sécurité à part (CSV = fuite de périmètre, PDF = capture non contrôlable) | Les utilisateurs contourneront par capture d'écran                            |
| Alertes et rapports programmés | Hors périmètre (§ 9) : cycles de vie longs, qui n'ont de sens qu'une fois les usages stables                                     | Une anomalie n'alerte pas ; la détection reste manuelle                       |
| Analyse temps réel             | `C7` — le rafraîchissement périodique est accepté                                                                                | Un tableau de bord « figé » sans signal                                       |
| Jointure libre                 | Hors périmètre (§ 9) : le croisement se fait par variables déclarées                                                             | Une question transverse reste inexprimable                                    |

### 4.3 Risques spécifiques à la V1

| Risque                                                                 | Prob. | Impact | Mitigation                                                                  |
| ---------------------------------------------------------------------- | ----- | ------ | --------------------------------------------------------------------------- |
| Le versionnement est reconstruit après coup                            | MOYEN | ÉLEVÉ  | Le format de configuration est versionné **dès les fondations** (`B2`)      |
| `journal:read` séparé gêne les petits projets (un seul administrateur) | ÉLEVÉ | FAIBLE | `B32` l'autorise explicitement : une ligne de configuration suffit          |
| La portée du journal déborde sur d'autres applications                 | MOYEN | ÉLEVÉ  | `B34` : bornée au périmètre du titulaire, testé comme une règle de sécurité |

### 4.4 Dépendances inter-versions

| La V1 dépend de                | Nature    | Critique ?                                   |
| ------------------------------ | --------- | -------------------------------------------- |
| Port d'autorisation implémenté | technique | **oui** — `B7`/`B25` ne sont pas négociables |
| Persistance des versions       | technique | **oui** — sans elle, US-6 n'existe pas       |
| Partage par groupes            | produit   | non — mais attendu, sinon le partage déçoit  |

---

## 5. V1.5 — la preuve de la réemploiabilité

> Ce n'est pas une fonctionnalité. C'est un **test qui ne peut pas être exécuté autrement**, et sa
> réussite est ce qui débloque la sortie du monolithe.

### 5.1 Périmètre

| Élément                                      | Règles (B*/C*) | Justification                                                                   |
| -------------------------------------------- | -------------- | ------------------------------------------------------------------------------- |
| Un composant de vue **sans DOM**             | `C6`           | React Native n'a pas de composants web : toute dépendance d'interface se révèle |
| Le même noyau de validation                  | `C1`, `C3`     | Aucune adaptation du cœur de métier — c'est le critère, pas « ça marche »       |
| Le registre de composants alimenté par Elora | ADR-004        | Preuve que la substitution d'interface est réelle, pas théorique                |
| Le même format de configuration              | `B2`           | Un fichier de vue écrit pour le web, relu sans changement par un projet mobile  |

### 5.2 Ce que la réussite débloque

| Élément                   | Condition                                                                |
| ------------------------- | ------------------------------------------------------------------------ |
| Extraction en package npm | `C6` satisfait — un second hôte a consommé le socle sans adapter le cœur |
| Documentation publique    | Une API existe, donc elle doit être décrite et stabilisée                |
| Semver et politique de    | Le coût du changement d'API devient un fait mesurable, pas une hypothèse |
| compatibilité             |                                                                          |

**Ce que l'échec signifierait.** Le noyau n'était pas neutre : il portait une dépendance
d'interface invisible. C'est une **bonne nouvelle** — un échec constaté sur Elora coûte une
tranche, pas une version publiée. C'est la raison de placer cette tranche avant toute sortie
externe.

---

## 6. V2+ — carnet de candidats, pas calendrier

> Chaque ligne a une **condition d'entrée**. Ce qui n'en a pas n'est pas une priorité, c'est un
> souhait.

| Candidat                | Condition d'entrée                                                                                   | Dépend de                                                           |
| ----------------------- | ---------------------------------------------------------------------------------------------------- | ------------------------------------------------------------------- |
| Descente en détail      | Retours V1 montrant qu'un **besoin d'investigation** existe et que le filtrage croisé n'y suffit pas | `B30` en production depuis une V1                                   |
| Export                  | Un besoin nommé par un projet hôte, avec son **format** et son périmètre de droits définis           | `B7`/`B25` — l'export est un chemin vers les données comme un autre |
| Alertes / programmation | La V1 tourne chez au moins deux hôtes, donc les usages sont comparables                              | Rétention `B29` — une alerte hors fenêtre chaude est muette         |
| RSS ou partage public   | `C8` l'exclut ; le rouvrir est une décision de sécurité, pas une fonctionnalité                      | Revue de `C8`                                                       |
| Analyse temps réel      | Un besoin explicite **et** une mesure de coût (SQL, le coût est le vrai frein)                       | `C7`                                                                |
| Jointure libre          | Un catalogue de variables qui **ne suffit plus** à exprimer les croisements courants                 | Retour sur `B3`                                                     |

**Pourquoi l'export est le candidat le plus tentant et le plus dangereux.** Il paraît petit : une
fonction de téléchargement. Mais un export est un **chemin vers les données** — donc soumis à
`B25` comme n'importe quel autre, avec un piège particulier : un CSV ne respecte ni les périmètres
de lignes du viewer, ni les colonnes masquées. L'exporter sans revérifier les trois contrôles, c'est
faire fuiter précisément ce que l'interface cachait. C'est pourquoi sa condition d'entrée est un
**format nommé**, pas une demande.

---

## 7. Compromis assumés

> La section la plus importante du document. Chaque exclusion est un compromis **choisi**.

| Compromis                              | Ce qu'on perd                                             | Ce qu'on gagne                                              | Risque à long terme                                                  |
| -------------------------------------- | --------------------------------------------------------- | ----------------------------------------------------------- | -------------------------------------------------------------------- |
| **Mono-utilisateur au MVP**            | Toute démonstration de valeur collective                  | Un noyau testé sur un seul parcours, donc complet           | On peut croire le produit fini trop tôt — d'où le gate de la V1      |
| **Pas de versionnement au MVP**        | La protection contre l'altération d'une vue publiée       | Une version publiée **immuable** : le plus simple à prouver | La V1 doit introduire le versionnement sans casser le MVP            |
| **Pas de partage au MVP**              | La démonstration du produit à un comité                   | Le chemin nominal le plus court vers la publication         | Le MVP ne prouve pas la promesse **collective**                      |
| **Pas d'assistant à l'intégration**    | L'installation devient manuelle                           | On teste le socle chez un vrai hôte, pas chez un imaginary  | L'intégration coûte cher tant qu'il n'y a qu'un seul hôte            |
| **`journal:read` séparé par défaut**   | Un administrateur seul doit se voir attribuer deux droits | Le moindre privilège reste le défaut                        | Un administrateur se plaint de ne rien voir — `B32` y répond         |
| **Un seul pouvoir d'écriture** (`B36`) | Impossible d'accorder « corriger mais pas créer »         | Trois droits deviennent un, moins d'erreurs de mapping      | Le besoin ressurgera ; la propriété (`B17`) est l'échappatoire       |
| **Pas d'échéances**                    | Pas de planning lisible par un tiers                      | Aucun engagement faux                                       | La visibilité de l'avancement passe par les gates, pas par des dates |

---

## 8. Effort relatif

| Version    | Slices (est.) | Taille | Facteurs de risque                                                        |
| ---------- | ------------- | ------ | ------------------------------------------------------------------------- |
| Fondations | 4–6           | M      | Transverse, bloque tout ; le format de configuration ne se reprendra pas  |
| MVP        | 8–12          | L      | Le nombre de contrôles de sécurité est le vrai coût, pas l'interface      |
| V1         | 8–12          | L      | Le versionnement et le partage sont couplés — ils ne se livrent pas seuls |
| V1.5       | 3–5           | S      | Dépend entièrement de l'API du MVP ; pas de conception nouvelle           |
| V2+        | à définir     | —      | À chiffrer **après** retours, jamais avant                                |

_Tailles relatives : S = 1–3 slices simples, M = 4–7, L = 8–12, XL = 13+ ou slices complexes._

**L'estimation qui compte** : le MVP est _L_ alors que sa démonstration tient en une après-midi. Le
coût n'est pas dans l'écran, il est dans `B7`/`B25`/`B6`/`B8`/`B23` — cinq règles de sécurité dont
chacune doit être prouvée contre le **contrat backend réel**, pas un mock. Une règle de sécurité
testée contre un mock n'est pas testée.

---

## 9. Dépendances externes

| Dépendance                  | Impacte          | Statut                                              | Risque si indisponible                                                                       |
| --------------------------- | ---------------- | --------------------------------------------------- | -------------------------------------------------------------------------------------------- |
| Backend de données cible    | Fondations + MVP | **à définir par le pilote**                         | Le socle définit le port ; son implémentation est un choix d'hôte                            |
| Moteur de requêtes          | Fondations       | **à définir**                                       | Un port trop couplé à un moteur rend la réemploiabilité fausse                               |
| Serveur Elora (Expo)        | V1.5             | projet existant, lecture seule                      | `C6` non testable ; la sortie du monolithe reste bloquée                                     |
| Dépôt `ace3i-bankingsms-ui` | **MVP (pilote)** | projet de référence ; exception ouverte par ADR-006 | Le pilote n'a pas de vraie autorisation derrière ; `B7`/`B25` seraient testés contre un faux |

**Point à trancher en Phase 4** : le moteur de requêtes. C'est le choix le plus structurant de la
phase d'architecture, parce qu'il décide si le port d'exécution est un **adaptateur** (le moteur
est derrière une interface) ou une **dépendance** (le moteur est derrière un registre). Le second
cas est plus rapide et rend `C6` faux. Le PRD ne tranche pas ; la roadmap le signale.

---

## Checklist de gate

- [x] Le MVP résout le problème principal du PRD (`C9` : une vue publiée sans développeur).
- [x] Chaque exclusion est justifiée par une **raison**, pas par un manque de temps.
- [x] Les risques par version sont identifiés, avec mitigation.
- [x] Les dépendances externes sont listées avec leur statut.
- [x] L'effort relatif est cohérent entre versions et justifié.
- [x] Aucune fonctionnalité **P1** n'est en V2+ sans justification exceptionnelle.
      **Vérifié par recoupement avec le PRD** : 12 US sont P1, 2 sont P2. Les 4 P1 repoussées le
      sont **vers la V1, jamais vers la V2+** — US-6, US-7, US-8 (chaîne de publication et de
      partage) et US-12 (fraîcheur des chiffres). Justification en § 3.2 : le MVP est mono-utilisateur,
      or US-6 à US-8 n'ont aucun déclencheur sans un second lecteur, et US-12 exige des chiffres
      déjà justes, ce que le MVP n'a pas encore démontré. Les deux seules P2 (`US-10`, `US-11`)
      sont naturellement en V1.
- [x] Le document ne contient pas de jargon d'implémentation.
- [x] **La V1.5 est présente** : sans second hôte, `C6` reste une hypothèse et la sortie du
      monolithe n'a aucun déclencheur.
- [x] **Aucune date** : aucune mesure de vélocité n'existe sur ce projet.

## Points laissés ouverts à la phase suivante

1. ~~**Le moteur de requêtes**~~ : **tranché en Phase 4** — **adaptateur**, pas dépendance. Voir ADR-007.
2. ~~**`benchmarks.md`**~~ : **tranché** — approuvé, avec la clause de verdict remplacée par un
   tableau d'**écarts constatés**. Un `PASS` est un auto-contrôle de l'agent, pas une mesure.
3. **Le pilote** : **tranché** — `ace3i-bankingsms-ui` par ADR-006, **comme pilote de validation** :
   c'est lui qui fournit l'autorisation réelle contre laquelle `B7`/`B25` sont éprouvées. Le
   **code** se développe dans ce dépôt (`pilot/`, `src/**`) ; `ace3i` ne reçoit qu'un point
   d'entrée d'intégration, réversible et séparé. `read_only: true` conservé (INC-005).
