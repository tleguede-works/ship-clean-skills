---
type: conventions
status: approved
generated_at: 2026-09-29
---

# Conventions techniques — Plateforme BI configurable

> Document unique. Tous les plans d'implémentation (Phase 5) y font référence plutôt que de reformuler ces règles.
> Ce document démarre en Phase 0 avec ce qui est connu, s'enrichit en Phase 4, et peut être amendé à tout moment.
> Les sections marquées `À DÉCIDER` sont tranchées phase par phase. Après la Phase 4, il ne doit plus
> en rester une marquée **cette phase** — mais une section peut être **re-datée** vers une phase
> ultérieure si elle n'est pas tranchable sans le squelette du projet. Une re-datation doit être
> motivée ; un report silencieux ne l'est pas.

---

## Décision de cadrage : où vit le pilote

| Décision              | Valeur                                                     | Conséquence                                                                                                                                      |
| --------------------- | ---------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------ |
| Pilotage initial      | Dans **ce** dépôt, comme application Next.js de référence  | Le dépôt ne contient pas de package publié au démarrage                                                                                          |
| `ace3i-bankingsms-ui` | Projet de référence, **pilote du MVP** — exception ADR-006 | Seul projet disposant d'une vraie autorisation derrière ; `state.json` reste `read_only: true` et l'outillage de protection reste armé (INC-005) |
| Extraction en package | Après validation par **deux** consommateurs                | Le second consommateur n'est pas encore identifié                                                                                                |

Cette décision découle directement de la déclaration d'`ace3i-bankingsms-ui` comme référence. Elle respecte la contrainte « ne pas créer de package immédiatement » tout en gardant l'extractibilité.

---

## Stack technique cible

| Domaine             | Choix                                               | Version                                     | Justification                                                                                                                                                                                                                                                                                                                                                                                                                 |
| ------------------- | --------------------------------------------------- | ------------------------------------------- | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| Langage             | TypeScript                                          | ^5.9                                        | `strict: true`, pas de `any` ; même toolchain que l'app de référence                                                                                                                                                                                                                                                                                                                                                          |
| Framework UI        | React                                               | ^19.2 (peer dependency)                     | Cible d'un composant de bibliothèque ; le runtime doit rester utilisable hors Next.js                                                                                                                                                                                                                                                                                                                                         |
| Framework hôte      | Next.js App Router                                  | ^16.3 (adapter optionnel)                   | Un des deux hôtes visés ; ne doit jamais devenir une dépendance du core                                                                                                                                                                                                                                                                                                                                                       |
| Base de données     | **Aucune imposée**                                  | —                                           | Le package ne persiste rien ; la persistance est un port implémenté par l'hôte ou un BFF                                                                                                                                                                                                                                                                                                                                      |
| ORM / Query builder | **Aucun**                                           | —                                           | Le moteur de requête est un port ; l'implémentation appartient au service d'exécution de l'hôte                                                                                                                                                                                                                                                                                                                               |
| State management    | **Reducer pur dans `src/core`**, branché par l'hôte | ADR-010                                     | Le brouillon porte des **règles** (`B26`, `B5`, `B6`, `B12`), pas des états d'interface. Un reducer dans React ne serait testable qu'à travers un DOM — et une règle de sécurité testée à travers une couche d'interface est testée à moitié. Implémentation de référence du pilote : `useReducer`. Aucune bibliothèque d'état dans `src/core` ni `src/react` (`C1`, `C3`)                                                    |
| Cache data client   | **Port `QueryCacheAdapter`**, jamais une dépendance | ADR-013                                     | Trois règles : la **fraîcheur vient de la réponse du service** (`B14`), jamais du cache ; le cache est **en mémoire** ; il est **vide à la déconnexion**. Une valeur en cache s'affiche toujours avec son état et sa date, jamais comme fraîche. Implémentation de référence : TanStack Query dans le **pilote seul** — jamais importée par `src/core` ni `src/react`                                                         |
| Formulaires         | **Contrôlés, sans bibliothèque**                    | ADR-012                                     | L'argument est technique, pas de goût : `B1` rend le caractère obligatoire de la description **configurable à l'exécution**, et une bibliothèque à schéma statique se bat contre cette règle. La vraie complexité — catalogue avec aperçus et options filtrées par droits — est dans `src/core`, pas dans le formulaire. Le socle expose son propre `ValidationResult`, jamais un type de bibliothèque                        |
| Validation          | Zod                                                 | ^4.6                                        | Schémas runtime + types inférés + conversion JSON Schema pour l'outillage                                                                                                                                                                                                                                                                                                                                                     |
| HTTP client         | Aucun dans le core                                  | —                                           | Le core ne connaît ni Axios ni fetch ; le `QueryProvider` est une interface                                                                                                                                                                                                                                                                                                                                                   |
| Styling             | CSS custom properties + utilitaires de l'hôte       | Tailwind CSS v4 (convention shadcn)         | Le thème passe par des variables CSS (`:root` / `.dark`) : le socle n'est lié à aucun moteur de style                                                                                                                                                                                                                                                                                                                         |
| Composants UI       | **shadcn par défaut, remplaçable**                  | CLI shadcn, composants **et** blocs de page | Accélérateur réel pour la coquille applicative (connexion, tableau de bord, barre latérale). Voir ADR-005 : distribution **par copie**, pas dépendance                                                                                                                                                                                                                                                                        |
| Icônes              | Fournies par l'hôte                                 | —                                           | Aucun icon library en dépendance du core                                                                                                                                                                                                                                                                                                                                                                                      |
| Tests unitaires     | **Vitest**                                          | ADR-011                                     | La couverture se mesure en **règles testées**, pas en lignes : chaque `B*` a au moins un test nommé par son ID, ce qui est vérifiable ; un seuil de lignes ne l'est pas et ne veut rien dire sur un cœur où cinq règles de sécurité portent tout. Les tests de `src/core` tournent **sans React** — une règle de business qui exige un DOM est mal placée. **Commandes : `À DÉCIDER EN PHASE 5`** — le squelette n'existe pas |
| Tests composants    | **Vitest + Testing Library**                        | ADR-011                                     | Rendu par état, assertions sur le rôle accessible, **jamais sur l'implémentation**. Les cinq règles qui portent la valeur sont `refused` ≠ `error`, recharge sans effacement, filtre « non disponible », absence de résultat, refus explicite. **Commandes : `À DÉCIDER EN PHASE 5`**                                                                                                                                         |
| Tests E2E           | Playwright                                          | ^1.63                                       | Cohérence avec l'app de référence et l'app hôte cible                                                                                                                                                                                                                                                                                                                                                                         |
| Lint                | ESLint flat config                                  | ^9.39                                       | Standard du projet ; **pas** hérité de l'app de référence (ADR-008)                                                                                                                                                                                                                                                                                                                                                           |
| Format              | Prettier                                            | ^3.9                                        | Standard du projet ; **pas** hérité de l'app de référence (ADR-008)                                                                                                                                                                                                                                                                                                                                                           |
| Package manager     | **bun**                                             | —                                           | Choix de l'utilisateur, voir ADR-008. L'argument de « cohérence avec l'app de référence » est **abandonné** : elle est en lecture seule, son gestionnaire n'a plus à contraindre ce dépôt. `bun pm pack` sera la vérification de distribution                                                                                                                                                                                 |
| Runtime             | **Node**, version épinglée                          | via `.node-version`                         | L'utilisateur utilise `fnm` (Fast Node Manager) : le fichier `.node-version` est le canal qu'il attend. Voir ADR-008                                                                                                                                                                                                                                                                                                          |

---

## Structure de dossiers cible

```
bi-dashboard-platform/
├── .forge/                          # livrables de planification (autorité : state.json)
│   ├── state.json
│   ├── conventions.md
│   ├── prd.md
│   ├── roadmap.md
│   ├── benchmarks.md
│   ├── architecture.md
│   ├── test-plan.md
│   ├── design/
│   │   ├── design-system.md
│   │   └── screens/
│   ├── plans/                       # un plan par slice
│   └── audit/
├── src/
│   ├── core/                        # AUCUNE dépendance React — contrats, schémas, migrations, reducer pur
│   ├── react/                       # provider, hooks headless, états runtime
│   ├── ui/                          # UI par défaut, optionnelle et remplaçable
│   ├── next/                        # seul module autorisé à importer `next/*`
│   └── widgets/                     # manifests et renderers par défaut
├── pilot/                           # application Next.js de référence (monolithe modulaire)
│   ├── app/
│   └── adapters/                    # CatalogProvider / QueryProvider / ViewRepository de démonstration
├── tooling/
│   └── setup-prompt/                # prompt d'installation versionné (puis CLI)
├── e2e/
├── package.json
└── AGENTS.md
```

### Règles de frontière entre couches (non négociables)

- `src/core` n'importe **rien** de `src/react`, `src/ui`, `src/next`, `pilot`, ni aucun package externe hors Zod.
- Seul `src/next` importe `next/*`.
- Aucun module `src/**` n'importe quoi que ce soit depuis `pilot/adapters`.
- Un widget enregistré par l'hôte est résolu par une **clé stable** ; aucun composant n'est stocké dans la configuration sérialisée.
- Ces frontières sont vérifiées par ESLint (`import/no-restricted-paths`) — le plan d'outillage de la Phase 4 définit la config exacte.

---

## Conventions de nommage

| Élément                    | Règle                                                          | Exemple                                       |
| -------------------------- | -------------------------------------------------------------- | --------------------------------------------- |
| Fichier composant          | kebab-case + suffixe `.tsx`                                    | `widget-editor.tsx`                           |
| Fichier service/utilitaire | kebab-case + suffixe `.ts`                                     | `query-spec.ts`                               |
| Fichier de validation      | nom du domaine,schéma exporté nommé                            | `view-definition.ts` → `ViewDefinitionSchema` |
| Fichier de type            | suffixe `-types.ts` si regroupement, sinon co-localisé         | `data-frame.ts`                               |
| Fichier de test            | co-localisé, suffixe `.test.ts(x)`                             | `view-definition.test.ts`                     |
| Routes / URLs              | pgf kebab-case, segment `/ui/<domaine>`                        | `/ui/vues`                                    |
| Props de composant         | `type XProps` (jamais `interface`)                             | `type WidgetEditorProps = { … }`              |
| Fonctions                  | verbes explicites, un seul export nommé par fichier de logique | `validateViewDefinition()`                    |
| Constantes                 | `SCREAMING_SNAKE_CASE`, groupées dans un fichier dédié         | `MAX_WIDGETS_DEFAULT`                         |
| Identifiant métier         | `bi.<domaine>.<objet>` — jamais le nom d'une colonne           | `bi.view.status`                              |

---

## Conventions de code

### Typage

- `strict: true`, `noUncheckedIndexedAccess` à activer en Phase 4 si le outillage le permet.
- Aucun `any`. `unknown` + type guards pour toute frontière de donnée externe.
- Les schémas Zod sont la **source de vérité** ; les types TypeScript sont inférés, jamais réécrits à la main.
- Toute donnée venant d'un adaptateur est parsée par un schéma avant d'atteindre un composant.

### Composants

- Le core ne contient aucun composant. Le runtime React expose des composants **headless** ; le rendu par défaut vit dans `src/ui`.
- Les renderers de widgets reçoivent un `DataFrame` normalisé, jamais une réponse HTTP.
- Tout état asynchrone a un état nommé et testable (`loading`, `refreshing`, `empty`, `stale`, `partial`, `forbidden`, `rejected`, `error`) — jamais une Cascade de booléens.
- Pas de composant monolithique : une responsabilité par fichier.

### State management

- L'état de **configuration** d'un widget en cours d'édition est local au wizard, et il est sérialisable.
- L'état de **données** d'un widget est détenu par le cache data client, jamais par le composant.
- Le core expose un reducer pur pour les transitions de l'assistant ; il ne dépend d'aucun store global.
- Aucun store global n'est imposé à l'hôte.

### Formulaires

- Les formulaires du wizard sont **contrôlés** : la source de vérité est l'état de configuration sérialisé, pas l'état interne d'une librairie de formulaires.
- La validation est déclenchée à l'action explicite (Continuer / Enregistrer), jamais à chaque frappe.
- Un résumé d'erreurs précède le premier champ en erreur lors d'une soumission.

### Data fetching

- Le core ne fait **jamais** d'appel réseau. Il définit les ports `CatalogProvider`, `QueryProvider`, `ViewRepository`.
- Toute requête de widget reçoit un `AbortSignal` et respecte le signal.
- Les résultats identiques sont dédupliqués par empreinte de requête normalisée, jamais par identité d'objet.
- Le rafraîchissement global d'une vue est **une exécution coordonnée**, jamais N effets indépendants.

---

## Gestion d'erreur standard

### Erreurs réseau

```
Provider (QueryProvider / ViewRepository) → normalise en BiError typée → le runtime la mappe
vers un état nommé → l'UI affiche un message métier + action « Réessayer ».
Le composant ne connaît jamais le type de transport (Axios, fetch, GraphQL).
```

### Erreurs de validation

```
Schéma Zod côté client (défense rapide) → validation serveur autoritaire au save/preview/execute.
Erreur = { path, code, message, severity } — jamais un message libre non structuré.
Une erreur de validation ne détruit jamais l'état saisi.
```

### Erreurs serveur

```
Codes stables (ex. FORBIDDEN, TARGET_UNKNOWN, QUERY_REJECTED, VERSION_CONFLICT, RATE_LIMITED).
Aucun stack trace, nom de table, fragment SQL ni exception brute n'est exposé au client.
Un 403 d'autorisation est distinguishable d'un 404 d' nonexistence.
```

---

## Stratégie de tests

### Tests unitaires

- Framework : **Vitest** (ADR-011) — package ESM ; ne doit pas forcer la migration de Jest dans les apps consommatrices
- Pattern : un `describe` par règle métier, les IDs du PRD (B*/E*/C*) cités dans le nom du test
- Emplacement : co-localisé avec le fichier testé
- **Les tests de `src/core` tournent sans React.** Si une règle de business exige un DOM, elle est mal placée
- Commande : `bun run test` — **`À DÉCIDER EN PHASE 5`** (re-datée : le squelette n'existe pas)

### Tests de contrat de sécurité

> **Re-datés en Phase 5 pour l'exécution, tranchés ici pour la nature.** Voir ADR-011.

- Objet : les **trois contrôles** (`NFR §7.2`) et `B25`
- Principe : le socle **publie une suite de tests** que l'adaptateur d'un hôte doit passer. Un hôte qui
  l'ignore n'est pas conforme, et ce n'est pas détectable autrement
- Refus : « une règle de sécurité testée contre un mock n'est pas testée » (`security.md`)
- `E6` (troncature) et `E7` (durée) sont des **tests d'injection de faute**, pas des tests de chemin nominal
- Commande : `bun run test:contract` — **`À DÉCIDER EN PHASE 5`**

### Tests composants

- Framework : **Vitest + Testing Library** (ADR-011)
- Pattern : rendu par état (un test par état nommé), assertions sur le rôle accessible et non sur l'implémentation
- Mocking : adaptateurs en mémoire (`InMemoryViewRepository`, `StaticCatalogProvider`) — jamais de mock HTTP pour un test de composant
- Emplacement : co-localisé
- Commande : `bun run test` — **`À DÉCIDER EN PHASE 5`**

### Tests E2E

- Framework : Playwright
- Pattern : un spec par parcours métier de bout en bout (créer → publier → consommer → dupliquer)
- Emplacement : `e2e/`
- Commande : `bun run test:e2e` — **`À DÉCIDER EN PHASE 5`**

### Règle transverse

Un test doit couvrir **une règle ou un edge case identifié** (B*/E*/C*) et le citer. Un test qui ne touche aucune règle n'est pas un test de règle.

**La métrique de couverture est le nombre de règles testées, pas le pourcentage de lignes.** Un seuil
de lignes est un nombre qu'on choisit pour ne pas échouer ; le nombre de règles sans test est un
nombre qu'on ne peut pas gonfler.

---

## Patterns retenus

| Pattern                   | Quand l'utiliser                                                | Exemple                                                                            |
| ------------------------- | --------------------------------------------------------------- | ---------------------------------------------------------------------------------- |
| Port + Adapter            | Toute dépendance externe (data, persistance, auth, i18n, cache) | `QueryProvider` implémenté par REST dans le pilote, par GraphQL chez un autre hôte |
| Registry                  | Tout ce qui est extensible sans modifier le package             | `WidgetRegistry` : clé + version → editor + renderer                               |
| Reducer pur               | Toute machine à états de configuration                          | transitions de l'assistant, calcul de `isPublishable()`                            |
| Fingerprint de requête    | Tout cache ou déduplication                                     | hash canonique de `{targetId, dimensions, measures, filters, timeRange, scopeKey}` |
| Immutabilité par version  | Tout artefact partagé                                           | un `publish()` crée une nouvelle version, ne modifie jamais la précédente          |
| Échec fermé (fail closed) | Toute décision d'autorisation ou de data scope                  | scope non résolu ⇒ aucun résultat rendu                                            |
| In-memory first           | Tout port testé ou non branché                                  | l'app pilote démarre sans backend                                                  |

---

## Accessibilité (règle transverse, non négociable)

- Toute interaction a un équivalent clavier ; le drag-and-drop est un enhancement.
- Le déplacement et le redimensionnement ont une commande clavier explicite avec annonces `aria-live`.
- Tout graphique a un nom accessible, un résumé et une alternative tableau.
- La couleur n'est jamais le seul signal.
- Les erreurs de page sont annoncées une fois, via une région adaptée.
- Respect de `prefers-reduced-motion`, focus visible, contraste AA.
- Objectif : **zéro** violation sérieuse ou critique sur les parcours principaux.

---

## Commandes

```bash
# Commandes — `À DÉCIDER EN PHASE 5` (re-datées)
# Le squelette n'existe pas : une commande documentée mais non exécutée
# est une promesse. Les scripts sont écrits avec le projet, en Phase 7.
# Le package manager est bun, pas npm : `bun run <script>`.
# `bun <script>` sans "run" fonctionne aussi, mais `bun run` explicite est
# le style retenu : il distingue un script du package d'une commande de bun.
bun run dev
bun run build
bun run lint
bun run typecheck
bun run test
bun run test:e2e

# Version de runtime : geree par `.node-version`, lue par fnm.
# Ne jamais figer la version en dur dans une commande ou un script :
# un `fnm use` joue hors du bon repertoire produit un runtime different
# sans aucun signal.
```

> **Pourquoi `bun` et pas `npm`.** Ce n'est pas une preference d'outillage mais une condition de
> coherence : `bun` est le gestionnaire du **futur package npm** du socle. Utiliser `npm` pour le
> développer et `bun` pour le publier exposerait deux arbres de dépendances, donc deux
> résolutions potentiellement différentes entre ce que l'on teste et ce que l'on publie. Le
> gestionnaire doit être **le même** de l'installation à la vérification de distribution
> (`bun pm pack`), sans quoi « ce qui est testé » n'est plus « ce qui est publié ».
>
> **L'app de référence n'a plus son mot à dire.** L'argument de cohérence qui justifiait `npm`
> (`conventions.md` ligne d'origine) ne vaut plus : `ace3i-bankingsms-ui` est en lecture seule, son
> gestionnaire n'a aucune raison de contraindre un dépôt indépendant. Voir ADR-008.

---

## Ce qui n'appartient PAS à ce document

Toute règle spécifique à une seule slice va dans le plan d'implémentation de cette slice, signalée comme déviation dans la section « Déviations par rapport à conventions.md ».

---

## Checklist de gate

- [x] Toute décision (nommage, structure, gestion d'erreur, tests) est actionnable.
- [x] La stack cible est entièrement spécifiée (framework, state, forms, HTTP, styling, tests). — **tranché en Phase 4** : state (ADR-010), cache (ADR-013), formulaires (ADR-012), tests (ADR-011). **Restent ouvertes : les commandes**, re-datées en Phase 5
- [x] Le document ne contient aucune règle spécifique à une seule slice.
- [ ] Les commandes (dev, build, lint, test) sont documentées **et fonctionnelles**. — bloqué : le squelette n'existe pas. `À DÉCIDER EN PHASE 5`
- [x] **Aucune section marquée `À DÉCIDER EN PHASE 4` ne subsiste.** — **amendé** : le gate
      initial était « aucune section ne subsiste », ce qui rendait impossible toute décision de
      garder une ouverture. La formulation retenue admet la **re-datation explicite** vers une phase
      ultérieure, à condition qu'elle soit motivée. Trois sections l'ont été, toutes pour la même
      raison et avec la même justification : **le squelette n'existe pas**, donc une commande ou un
      script ne peut pas être écrit ni vérifié. Les sections de stack sont, elles, tranchées.

> **Le statut de ce document ne se lit pas ici.** Il vit dans `.forge/state.json`, qui est
> l'autorité, et dans le front matter ci-dessus, qui en est le miroir. Ce document est en outre
> **vivant** : il s'enrichit à chaque phase et se verrouille en Phase 4.