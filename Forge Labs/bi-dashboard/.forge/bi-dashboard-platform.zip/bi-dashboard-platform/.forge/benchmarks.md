---
type: benchmarks
status: approved
generated_at: 2026-09-29
derived_from: 
archetype: dashboard
---

# Standards de référence — Plateforme de vues BI configurables

> Ce document compare le projet à ce qui **se fait déjà** pour un produit du même archétype.
> Il n'est pas normatif : il rend les écarts **visibles**.
>
> Une application est rarement entièrement nouvelle. Il existe presque toujours
> des produits similaires et des conventions établies que les utilisateurs attendent déjà.
> Comparer plutôt qu'inventer.

> **Résultat de la recherche : 4 décisions du PRD ont changé.** Elles sont listées en § 8.
> Une recherche qui ne change aucune décision n'a rien produit — celle-ci en change quatre.

---

## 1. Archétype

|                          |                                                                                                                                                            |
| ------------------------ | ---------------------------------------------------------------------------------------------------------------------------------------------------------- |
| **Archétype principal**  | `dashboard` — surveillance, lecture de métriques, disposition d'indicateurs                                                                                |
| **Archétype secondaire** | `admin_crud` (liste de vues, tri, filtre, recherche) et `transactional_web` (l'assistant en trois étapes est un tunnel étagé)                              |
| **Plateforme**           | web, bureau d'abord, utilisable sur mobile                                                                                                                 |
| **Boucle de travail**    | Consulter mes vues au quotidien, et—when un besoin d'analyse nouveau apparaît—j'en compose une nouvelle, je la publie, je la partage, puis je la revisite. |

**Justification de l'archétype** : le PRD (§ 1.1) décrit un produit dont l'usage dominant est la
consultation répétée de vues composées d'indicateurs, avec une disposition éditoriale — ce qui
correspond exactement à la boucle « surveiller → détecter → investiguer ». La partie authoring
n'existe pas comme archétype dans `references/archetypes.md` : c'est un **trou de la
bibliothèque**, comblé ici par les standards de `transactional_web` (tunnel étagé et visible,
saisie conservée entre les étapes) et de `admin_crud` (table plutôt que cartes, journal
d'activité).

---

## 2. Produits de référence

| Produit      | Ce qu'on lui reprend                                                                                                                                                                                                                                                                                                                                              | Ce qu'on ne reprend pas                                                                                                                                                      |
| ------------ | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| **Retool**   | Le modèle à **deux mécanismes de droits indépendants** : un niveau d'accès (exécuter / modifier / posséder) et, séparément, une politique d'accès qui restreint les données. Le point dur vérifié dans leur documentation : _une politique ne peut qu'restreindre, jamais accorder_. Le contenu s'affiche dans l'application hôte, en natif, sans second système. | La juxtaposition d'un éditeur WYSIWYG généraliste et d'un modèle de permissions très riche. Nous n'avons qu'un besoin de pilotage, pas de construction d'applications.       |
| **Power BI** | Le **modèle sémantique** entre l'utilisateur et la base : l'utilisateur compose sur des mesures et des dimensions nommées, jamais sur des colonnes. Le fait que le périmètre de lignes s'applique aussi à **ceux qui créent** les rapports, et pas seulement à ceux qui les lisent.                                                                               | L'approche « l'utilisateur importe ses données ». Notre catalogue est alimenté par le responsable de données, ce qui est la condition d'une industrialisation multi-projets. |
| **Metabase** | Le fait qu'un tableau de bord intégré dans une autre application impose des contraintes très concrètes — nous les avons lues pour **justifier le refus** (voir § 5).                                                                                                                                                                                              | L'intégration par cadre tiers, le secret partagé entre deux systèmes, et le jeton passé par le navigateur.                                                                   |

> Sources consultées : documentation Retool (permissions de ressources, politiques d'accès),
> documentation Power BI (sécurité du modèle sémantique, RLS, historique de version),
> documentation Metabase (intégration, jetons signés). Chaque affirmation est reprise en § 3.

---

## 3. Invariants extraits

> Un invariant est **une propriété qui ne peut pas être fausse**, pas une fonctionnalité.
> C'est ce qu'on transporte, pas le code.

| #   | Invariant                                                                                                                                                            | Source                                                                                                                               | Notre règle                                                            |
| --- | -------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------ | ---------------------------------------------------------------------- |
| I1  | **Une politique de données ne peut qu'restreindre l'accès, jamais l'accorder.**                                                                                      | Retool, documentation des politiques d'accès                                                                                         | `B8`, ADR-002, `security.md` §1                                        |
| I2  | **Le niveau d'accès et le périmètre de données sont deux mécanismes distincts**, tous deux requis.                                                                   | Retool, trois niveaux de permission + politiques séparées                                                                            | `B8` : les trois contrôles sont conjoints                              |
| I3  | **Masquer une colonne ou restreindre une interaction dans un rapport ne restreint pas l'accès aux données.** Seule une règle appliquée au modèle sémantique le fait. | Power BI, document de partage des rapports                                                                                           | `B19`, ADR-002, `security.md` §1                                       |
| I4  | **Le périmètre de lignes s'applique aussi à l'auteur du rapport** qu'au lecteur.                                                                                     | Power BI, « granting creators only Read and Build permissions … ensures that security rules are applied to the creators themselves » | **Absent du PRD avant cette recherche** → `B23`                        |
| I5  | **L'immuabilité sert à la fois à garantir la reproductibilité et à permettre le retour arrière.**                                                                    | Power BI, l'historique de version est le seul mécanisme de récupération après une suppression de table                               | `B5` couvre l'immuabilité ; le **retour arrière** était absent → `B24` |
| I6  | **L'accès aux données doit être appliqué à tous les chemins qui y mènent**, pas seulement à celui de la vue.                                                         | Retool, politiques « enforced globally across all apps, query libraries, raw SQL, and agents »                                       | **Absent du PRD avant cette recherche** → `B25`                        |
| I7  | Un ordre stable et total est nécessaire : deux exécutions doivent produire le même résultat.                                                                         | `references/archetypes.md` § 9, pathologie « une caractéristique instable »                                                          | **Absent du PRD avant cette recherche** → `B26`                        |

---

## 4. Grille de conformité à l'archétype

| #   | Question                                                | Réponse                 | Justification si écart                                                                                                                                                                                                                                                          |
| --- | ------------------------------------------------------- | ----------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| 1   | Module le plus fréquent accessible en 1–2 sauts ?       | conformité              | La liste des vues est le point d'entrée ; l'assistant est à un saut depuis la liste.                                                                                                                                                                                            |
| 2   | Navigation bornée (≤5 principaux) et justifiée ?        | conformité              | Deux entrées : « Mes vues » et « Administration ». Le reste est contextuel.                                                                                                                                                                                                     |
| 3   | Actions récurrentes sans navigation profonde ?          | conformité              | Consulter, dupliquer, rafraîchir, changer de période sont dans la vue.                                                                                                                                                                                                          |
| 4   | Boucle principale couverte de bout en bout ?            | conformité avec réserve | La boucle `dashboard` (surveiller → détecter → investiguer) est couverte : le filtrage croisé (`B30`) donne l'action sans navigation, et une période pilotable est présente. Réserve : la **descente en détail** n'existe pas (§ 6, n° 4a) — l'investigation s'arrête à la vue. |
| 5   | États d'erreur / hors-ligne traités ?                   | conformité              | `E3`, `E4`, `E6`, `E7`, `E18` couvrent erreur, vide, troncature, délai dépassé et coupure réseau.                                                                                                                                                                               |
| 6   | Modules attendance de l'archétype présents ou écartés ? | **écart assumé**        | « Alertes » est écarté (§ 6, n° 3) : le besoin initial est le pilotage, pas l'astreinte. La descente en détail est écartée mais **compensée** par `B30`.                                                                                                                        |
| 7   | Aucun module sans user story ?                          | conformité              | Chaque module a au moins une user story : le catalogue via `US-3`, l'administration via `US-11`, l'assistant via `US-10`.                                                                                                                                                       |

**Écarts constatés** — ce que la comparaison **a montré**, sans jugement de conformité :

| Écart                                 | Où                               | Traitement retenu                                                                                            |
| ------------------------------------- | -------------------------------- | ------------------------------------------------------------------------------------------------------------ |
| Descente en détail absente            | Boucle principale, invariant 4a  | **Compensé** par le filtrage croisé (`B30`) : l'action est disponible sans navigation, l'investigation non   |
| Alertes / rapports programmés absents | Modules d'assiduité, invariant 6 | **Écart assumé** — le besoin initial est le pilotage, pas l'astreinte. Reste le seul écart sans compensation |
| Jointure libre absente                | Modélisation                     | **Écart assumé** — le croisement passe par des variables déclarées, pas par un graphe de relations           |
| Partage public absent                 | Module d'assiduité               | **Écart assumé** — `C8` l'exclut ; chaque ouverture serait une décision de sécurité                          |

**Ce que ce tableau ne dit pas.** Il ne conclut pas que notre conception est « bonne » : il
n'établit que la **position** de chaque écart par rapport à trois produits, et la **décision**
prise pour chacun. Le mot `PASS` a été retiré — un auto-contrôle de l'agent n'a pas à être
validé par la même personne qui l'a écrit. Les cellules _conformité_ des tableaux ci-dessus
restent des jugements, signalés comme tels ; les lignes « écart assumé » sont des faits.

---

## 5. Standards d'archétype retenus

| Standard                                                         | Adopté            | Comment                                                                                                                                                                                 |
| ---------------------------------------------------------------- | ----------------- | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| Sidebar, densité haute                                           | oui               | La liste de vues est dense, triée et filtrable ; pas de cartes pour la navigation.                                                                                                      |
| Hiérarchie en trois temps : valeur → signal → détail             | oui               | Chaque indicateur porte sa valeur, son écart ou son état, et son détail accessible.                                                                                                     |
| Plages temporelles pilotables                                    | oui               | Période commune à tous les indicateurs d'une vue (US-9), avec libellé « temporaire ».                                                                                                   |
| Seuils et couleurs sémantiques                                   | oui               | Un état périmé, partiel ou tronqué est signalé par un texte **et** une couleur, jamais la couleur seule.                                                                                |
| Le dashboard montre des anomalies, pas des métriques décoratives | oui               | `US-12` impose date de calcul, état partiel et troncature signalée.                                                                                                                     |
| Tunnel étagé et visible (assistant)                              | oui               | Trois étapes, indicateur d'étape visible, saisie conservée entre les étapes (`B11`, `US-3`).                                                                                            |
| Journal d'activité                                               | oui               | `US-7`, `US-11` : partage, révocation et changement de vue par défaut sont tracés.                                                                                                      |
| Chaque visuel cliquable vers son détail                          | **partiellement** | Le **filtrage croisé** est livré (`B30`) : un visuel agit sur les autres indicateurs de la même vue. La **descente en détail** vers un autre jeu de données reste écartée (§ 6, n° 4a). |

---

## 6. Écarts assumés

| #   | Écart                                                                                      | Décision                       | Justification                                                                                                                                                                                                                                                                                                                                                                                                    | Réversibilité                                                                         |
| --- | ------------------------------------------------------------------------------------------ | ------------------------------ | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ------------------------------------------------------------------------------------- |
| 1   | **Pas d'intégration d'un moteur de rapport externe par cadre tiers** (type Metabase)       | on s'écarte                    | L'intégration de ce type impose un second système, un secret partagé entre les deux applications, et un jeton transmis au navigateur — la documentation de référence recommande explicitement de ne jamais l'écrire en dur dans la page et de le faire délivrer côté service. Le coût est disproportionné pour un besoin de pilotage interne, et le résultat ne s'intègre pas aux composants de l'application.   | **Coûteuse** — l'adopter plus tard suppose d'accepter le second système et le jeton.  |
| 2   | **Pas d'import de données par l'utilisateur final** (à la différence de Power BI)          | on s'écarte                    | Le catalogue est alimenté par un responsable de données nommé. C'est la condition pour qu'un socle soit industrialisable sur plusieurs projets : l'import libre rend le périmètre des données incontrôlable.                                                                                                                                                                                                     | Facile — un import est ajoutable sans changer le cœur.                                |
| 3   | **Pas d'alertes** (module attendu de l'archétype `dashboard`)                              | on s'écarte                    | Aucun besoin d'astreinte identifié. Une alerte implique un destinataire, un canal et un cycle de vie — hors du besoin de pilotage initial.                                                                                                                                                                                                                                                                       | Facile                                                                                |
| 4a  | **Pas de descente en détail** : cliquer sur une valeur n'ouvre pas un autre jeu de données | on s'écarte, avec contrepartie | C'est une capacité d'exécution supplémentaire, avec ses propres règles d'accès : elle transforme une vue d'observation en vue d'investigation. En contrepartie, le **filtrage croisé au sein de la même vue est livré en V1** (`B30`), ce qui donne l'action à l'utilisateur sans nouvelle capacité de requête. L'anti-pattern « graphiques jolis mais sans action » est donc **neutralisé**, non pas contourné. | Moyenne — la descente en détail reste absente ; elle est un produit d'un autre ordre. |
| 5   | **Un seul paramètre global commun** (période) au lieu de plusieurs filtres libres          | **écart levé**                 | Décision prise : une vue peut définir **plusieurs** paramètres communs, non figés par le produit (`US-9`). Le risque d'incohérence entre indicateurs est traité par `E17` : les indicateurs non concernés par un paramètre sont identifiés comme tels.                                                                                                                                                           | —                                                                                     |

---

## 7. Risques de biais

| Risque                                                                                                        | Probabilité | Impact | Mitigation                                                                     |
| ------------------------------------------------------------------------------------------------------------- | ----------- | ------ | ------------------------------------------------------------------------------ |
| Copier le modèle « l'utilisateur importe ses données » de Power BI, incompatible avec un socle multi-projets  | Moyenne     | Élevé  | Écart assumé n° 2, avec la condition de catalogue nommé.                       |
| Sur-copier la richesse de permissions de Retool et ne jamais livrer la version simple                         | Moyenne     | Moyen  | `US-3` : le catalogue propose des choix, pas un système de droits complet.     |
| Imposer le vocabulaire de `admin_crud` à un produit dont la boucle est `dashboard`                            | Faible      | Moyen  | Le nombre de modules est borné à deux entrées (§ 4, question 2).               |
| Prendre l'absence d'archétype « authoring » dans la bibliothèque comme une permission de faire n'importe quoi | Moyenne     | Moyen  | Les standards de `transactional_web` sont empruntés explicitement (§ 4, q. 4). |

---

## 8. Décisions changées par la recherche

Quatre règles ont été ajoutées au PRD à la suite de cette recherche. Sans elles, le document
était incomplet.

| Nouvelle règle                                                                                                                                            | Origine             | Pourquoi c'était un trou                                                                                                                                                                                                            |
| --------------------------------------------------------------------------------------------------------------------------------------------------------- | ------------------- | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `B23` — L'auteur d'une vue est soumis aux mêmes restrictions de données que ses lecteurs.                                                                 | I4 (Power BI)       | Le PRD proposait des choix autorisés à l'auteur, mais ne disait pas que les **restrictions de lignes** s'appliquent à la construction. Un auteur pouvait concevrir un indicateur qu'il ne pourrait pas consulter lui-même.          |
| `B24` — Une version antérieure reste consultable et restaurable.                                                                                          | I5 (Power BI)       | `B5` garantissait l'immuabilité, mais pas le retour arrière. Or l'immuabilité n'est utile que si l'on peut revenir en arrière — c'est sa raison d'être.                                                                             |
| `B25` — Le contrôle d'accès aux données s'applique à **tout** chemin menant aux données, pas seulement à la consultation d'une vue.                       | I6 (Retool)         | Le PRD ne contrôlait que l'accès à la vue. Si le même jeu de données est atteignable par un autre chemin, la restriction de lignes ne protège plus. C'est la pathologie « un fait, deux représentations », appliquée à la sécurité. |
| `B26` — L'ordre des indicateurs et la déduplication des requêtes sont **stables et totaux** : deux exécutions d'une même vue produisent le même résultat. | `archetypes.md` § 9 | Sans cela, deux ouvertures de la même vue peuvent afficher les indicateurs dans un ordre différent, et une déduplication par ordre d'insertion peut fusionner deux requêtes différentes.                                            |

---

## 9. Checklist de gate

- [x] L'archétype est identifié et justifié par le PRD.
- [x] La boucle de travail est écrite en une phrase.
- [x] Au moins deux produits de référence sont documentés, ou leur absence est justifiée.
- [x] Les sept questions de la grille de conformité sont répondues.
- [x] Chaque écart est justifié et son coût de réversibilité est indiqué.
- [x] Les standards retenus sont ceux **applicables**, pas une liste exhaustive.
- [x] Le verdict est écrit.
- [x] Ce document est écrit **avant** le gate d'architecture, pour servir de référence au `plan-validator` en Fast Track.