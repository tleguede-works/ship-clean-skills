---
type: design-system
status: approved
generated_at: 2026-09-29
derived_from: .forge/prd.md
---

# Design System — Plateforme BI configurable

> Ce document définit les fondations visuelles et les patterns d'interaction du socle.
> Tout écran y fait référence. Modifier un token ici impacte tout le produit.
>
> **Ce document n'est pas un catalogue de couleurs.** C'est le document qui répond à une seule
> question, repeatedly, sur toute sa longueur : _« un composant React Native pourrait-il rendre
> ça ? »_ — parce que le socle doit être consommé par Elora en V1.5, et que `C6` interdit
> d'extraire en package tant que la réemploiabilité n'est pas un fait.

---

## 0. Direction visuelle

| Ancre               | Contenu                                                                                                                                                                                                                                                                                                                               |
| ------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| **Références**      | Les tableaux de bord denses de l'app de référence (`ace3i-bankingsms-ui`, blocs shadcn `dashboard-01`) ; **Retool** pour la densité sans delight ; **Grafana** pour la densité de lecture d'un indicateur unique. Volontairement **pas** Stripe ni Linear : leur registre est celui du produit marketing, pas de l'outil de pilotage. |
| **Ambiance**        | **Dense, opérationnelle, trustworthiness.**                                                                                                                                                                                                                                                                                           |
| **Anti-références** | Pas de cartes ombrées flottantes. Pas de dégradés. Pas d'illustration décorative. Pas d'animation de entrée de contenu chiffré. Pas de couleur seule pour porter un état. Pas de « donut chart » par confort. Pas d'espace blanc décoratif entre deux informations de même niveau.                                                    |

**Archétype** : `dashboard` (principal) + `admin_crud` + `transactional_web` (secondaires) — voir
`.forge/benchmarks.md` § 1.
**Plateforme** : web, bureau d'abord, utilisable sur mobile.
**Boucle de travail** : consulter mes vues au quotidien ; quand un besoin d'analyse nouveau apparaît,
j'en compose une, je la publie, je la partage, puis je la revisite.

**Densité** : **dense.** Un utilisateur de pilotage ouvre plusieurs vues par heure et compare des
valeurs entre elles. L'air est un coût, pas un confort : un écran de tableau de bord doit montrer
plusieurs indicateurs **dans le même regard**, sans défilement. Justification : la densité est le
seul paramètre de design qui change le nombre de comparaisons possibles par unité de temps.

### 0.1 Le test de portabilité — la contrainte qui structure ce document

Un design system réutilisable ne peut pas être une liste de valeurs CSS. Il faut distinguer ce qui
**transporte** de ce qui est **lié à la plateforme**.

| Couche        | Contenu                                                                                   | Transporte vers un hôte sans DOM ?          |
| ------------- | ----------------------------------------------------------------------------------------- | ------------------------------------------- |
| **Décisions** | Rôles sémantiques, ratios, hiérarchie, états, densité, règles de communication d'un refus | **Oui** — ce sont des choix, pas des pixels |
| **Liaison**   | Variables CSS, classes utilitaires, valeurs `oklch`                                       | **Non** — réimplémentable par l'hôte        |

**Règle** : toute ligne de ce document est marquée `[P]` (portable) ou `[W]` (web). Une spécification
d'écran qui n'utilise **que** des décisions `[P]` est portable par construction. C'est le critère
qu'Elora vérifiera en V1.5, et c'est la seule façon de découvrir une dépendance d'interface
cachée **avant** la sortie du monolithe.

**Ce qui ne transporte pas, et qu'il ne faut pas prétendre transporter** : `--shadow-md`, `--bp-*`,
toute valeur en `px`, toute animation CSS, `hover`. Un hôte sans DOM les réinvente. Le design system
doit donc dire **quelle intention** remplace ces notions — pas « ignorez cette ligne ».

---

## 1. Design tokens

### 1.1 Rôles de couleur — la couche portable `[P]`

Le socle ne définit **jamais** une couleur directement dans un composant. Il utilise un **rôle**, et
l'hôte fournit la valeur. C'est ce qui rend la substitution totale (ADR-004, ADR-005).

| Rôle sémantique   | Usage                                      | Ce qu'il ne doit **jamais** porter             | Pourquoi ce rôle existe                                                                      |
| ----------------- | ------------------------------------------ | ---------------------------------------------- | -------------------------------------------------------------------------------------------- |
| `text-primary`    | Valeur d'indicateur, titre                 | —                                              | Un chiffre doit être la chose la plus lisible de l'écran                                     |
| `text-secondary`  | Libellé, unité, date                       | —                                              | L'unité d'un chiffre est souvent oubliée ; elle est ici                                      |
| `text-muted`      | Métadonnée non critique                    | Une information de sécurité                    | Le `B28` impose que le journal ne montre rien de sensible : la distinction est structurelle  |
| `surface-base`    | Fond de la zone de données                 | —                                              | —                                                                                            |
| `surface-raised`  | Une vue par rapport à une autre            | —                                              | Une vue est une surface, pas un décor                                                        |
| `border-subtle`   | Séparation entre indicateurs               | **L'ombre n'est pas le séparateur par défaut** | Une ombre implique une élévation : faux ici, tout est plat                                   |
| `status-fresh`    | Donnée calculée, périmée d'un délai connu  | —                                              | `B14` : un résultat périmé est signalé, jamais présenté comme actuel                         |
| `status-stale`    | Donnée périmée                             | —                                              | Idem — l'opposé de `status-fresh`                                                            |
| `status-partial`  | Résultat tronqué, incomplet                | —                                              | `B22` : ne jamais mélanger sans cohérence annoncée                                           |
| `status-error`    | Échec d'exécution                          | —                                              | Différent d'un refus d'accès : l'un est un incident, l'autre une règle                       |
| `status-refused`  | Refus d'accès, explained en langage métier | —                                              | `B13` : un refus n'est pas une erreur. **Doit être visuellement distinct de `status-error`** |
| `status-selected` | Filtre croisé actif                        | —                                              | `B30` : le filtre doit être visible sans le dire                                             |

**Trois rôles que la plupart des design systems fusionnent, et qu'il ne faut pas fusionner ici** :

1. `status-error` (l'exécution a échoué) et `status-refused` (vous n'avez pas le droit). Un
   utilisateur doit pouvoir dire lequel est survenu **sans lire le texte**. Les fusionner rend
   l'impossibilité de comprendre un refus, ce que `B13` combat directement.
2. `text-primary` et `text-muted` : un chiffre périmé reste un chiffre. Il change de statut, pas
   de nature. Le mettre en gris le ferait disparaître, or `B14` exige qu'il reste visible.
3. `status-fresh` et `status-stale` : ce ne sont pas des couleurs de fond mais des **textes**, et le
   signal est porté par le libellé **et** la couleur. Jamais la couleur seule.

### 1.2 Liaison web — valeurs concrètes `[W]`

Liaison en `oklch`, convention shadcn (ADR-005). **Ce bloc est la partie non portable** : il est
documenté pour que le pilote soit cohérent, pas pour être réutilisé tel quel.

| Token                | Valeur                        | Usage                                                 |
| -------------------- | ----------------------------- | ----------------------------------------------------- |
| `--background`       | `oklch(0.99 0.003 250)`       | Fond de page — **pas blanc pur** (le gate l'interdit) |
| `--surface`          | `oklch(1 0 0)`                | Fond d'indicateur, panneau                            |
| `--surface-raised`   | `oklch(0.985 0.004 250)`      | Vue dans la liste des vues                            |
| `--foreground`       | `oklch(0.22 0.012 255)`       | Texte principal                                       |
| `--muted-foreground` | `oklch(0.52 0.014 255)`       | Libellés, unités                                      |
| `--border`           | `oklch(0.92 0.006 250)`       | Séparation — **jamais l'ombre**                       |
| `--primary`          | `oklch(0.52 0.14 255)`        | Actions, sélection                                    |
| `--status-fresh`     | `oklch(0.55 0.13 155)`        | Frais                                                 |
| `--status-stale`     | `oklch(0.62 0.13 75)`         | Périmé                                                |
| `--status-partial`   | `oklch(0.58 0.12 320)`        | Tronqué                                               |
| `--status-error`     | `oklch(0.55 0.19 25)`         | Échec d'exécution                                     |
| `--status-refused`   | `oklch(0.45 0.09 300)`        | Refus d'accès — **distinct de `--status-error`**      |
| `--status-selected`  | `oklch(0.52 0.14 255 / 0.12)` | Filtre croisé actif                                   |

> **Contrainte de portabilité à respecter** : `--status-refused` est volontairement **plus sombre et
> moins saturé** que `--status-error`, et non dans la même famille de teinte. Le fonctionnement par
> la teinte seule est ce qui permet à un hôte sans DOM de choisir deux couleurs qu'il sait
> distinguer. Si les deux rôles étaient deux nuances de rouge, la distinction disparaîtrait.

### 1.3 Typographie `[P]` — le ratio est la décision, la police est la liaison

Un chiffre doit être lisible **en un regard**, à distance de lecture, et comparable d'un indicateur à
l'autre. Cela fixe trois choses indépendantes de la police :

| Décision `[P]`      | Valeur                   | Raison                                                                                                       |
| ------------------- | ------------------------ | ------------------------------------------------------------------------------------------------------------ |
| Ratio de l'échelle  | **1.2 (majorant tiers)** | Assez serré : 1.25+ détruit la comparaison en un regard, 1.125 la rend impossible                            |
| Corps du chiffre    | `500`, jamais `700`      | Un chiffre trop gras devient un titre ; il perd sa fonction de mesure                                        |
| Chiffres tabulaires | **obligatoire**          | `font-variant-numeric: tabular-nums` — deux nombres alignés verticalement se comparent ; proportionnels, non |

| Rôle           | Taille      | Graisse | Usage                                                       |
| -------------- | ----------- | ------- | ----------------------------------------------------------- |
| `metric`       | `1.5rem`    | `500`   | Valeur d'un indicateur — **le plus gros élément d'une vue** |
| `metric-unit`  | `0.875rem`  | `400`   | Unité, accolée à la valeur, jamais sur une ligne séparée    |
| `metric-delta` | `0.875rem`  | `500`   | Écart vs période précédente — toujours **signé**            |
| `title`        | `1.25rem`   | `600`   | Titre de vue                                                |
| `body`         | `1rem`      | `400`   | Texte courant                                               |
| `label`        | `0.8125rem` | `500`   | Libellé d'indicateur                                        |
| `caption`      | `0.75rem`   | `400`   | Date de calcul, fraîcheur                                   |
| `overline`     | `0.6875rem` | `600`   | Catégorie, statut — en capitales                            |

**Lié à la plateforme `[W]`** : la famille. Un hôte sans DOM choisit la sienne ; l'échelle, la
graisse et le `tabular-nums` restent exigibles.

### 1.4 Espacement et rayons `[P]`

| Token     | Valeur | Usage                                             |
| --------- | ------ | ------------------------------------------------- |
| `space-1` | `4px`  | Icône ↔ libellé                                   |
| `space-2` | `8px`  | Libellé ↔ valeur                                  |
| `space-3` | `12px` | Entre deux indicateurs                            |
| `space-4` | `16px` | Entre deux cartes d'indicateurs d'une même rangée |
| `space-6` | `24px` | Entre deux sections                               |
| `space-8` | `32px` | Padding d'un panneau                              |
| `radius`  | `6px`  | **Un seul rayon.** Un seul, pas une échelle       |

> **Pourquoi un seul rayon.** Une échelle de rayons signale une hiérarchie de matière — verre, métal,
> plastique. Un tableau de bord n'a pas de matière : il a de la densité. Un rayon unique et une
> bordure qui fait le séparateur disent la même chose, moins cher. C'est aussi ce qui permet à un
> hôte d'appliquer son propre rayon sans casser la métrique d'information.

**Portabilité** : les _rapports_ (`space-2 = 2 × space-1`) sont portables ; les pixels ne le sont pas.
Un hôte sans DOM applique ses propres unités en gardant les rapports.

### 1.5 Élévation `[P]` l'intention, `[W]` la réalisation

| Décision `[P]` | Rôle                                                                | Liaison web `[W]`                |
| -------------- | ------------------------------------------------------------------- | -------------------------------- |
| `flat`         | **Par défaut.** Tout est sur la même surface                        | `box-shadow: none`               |
| `raised`       | Seule chose qui flotte au-dessus du contenu : modale, menu, popover | `0 4px 12px oklch(0 0 0 / 0.12)` |
| `overlay`      | Ce qui masque le reste de l'application                             | `oklch(0 0 0 / 0.4)`             |

> **L'ombre n'est pas un séparateur.** Le gate l'interdit, et pour une raison concrète : une ombre
> suppose qu'un élément est _au-dessus_ d'un autre. Dans une grille d'indicateurs, rien n'est
> au-dessus de rien — tout est le même niveau d'information. Séparer par l'ombre ferait dire « ceci
> est plus important » à chaque indicateur, donc à aucun. **La bordure est le séparateur.**

### 1.6 Mouvement `[P]`

| Décision   | Valeur  | Usage                                        |
| ---------- | ------- | -------------------------------------------- |
| `instant`  | `0ms`   | Changement de valeur d'un chiffre déjà connu |
| `fast`     | `120ms` | Survol, focus                                |
| `normal`   | `200ms` | Ouverture de modale, changement de panneau   |
| `ease-out` | —       | **Seule** courbe admise pour une apparition  |

**Règle** : **aucune animation ne porte une information**. Un chiffre ne s'anime pas, un résultat
n'apparaît pas en séquence. Si une animation peut être supprimée sans rien retirer, elle est
supprimée — sur un tableau de bord dense, le mouvement coûte une information.

> **Ce que dit cette règle à un hôte sans DOM** : il n'y a rien à réimplémenter. La décision
> portable est « ne pas animer l'information », pas « utiliser 200 ms ».

### 1.7 Points de rupture `[W]`

| Token   | Valeur   | Usage                                   |
| ------- | -------- | --------------------------------------- |
| `bp-sm` | `640px`  | Une colonne d'indicateurs               |
| `bp-md` | `1024px` | Deux à trois colonnes + sidebar visible |
| `bp-lg` | `1440px` | Colonnes pleines, sidebar déployée      |

---

## 2. Composants primitifs

> Un composant du socle est une **capacité** nommée, résolue par un registre (ADR-004). Ce tableau
> décrit ce qu'un composant doit savoir faire, pas son apparence — l'apparence appartient à
> l'implémentation par défaut (shadcn) ou à l'hôte.

### 2.1 Les huit composants du socle, et leur contrainte

| Capacité         | Rôle                                    | États exigés                                              | Contrainte de portabilité                                                            |
| ---------------- | --------------------------------------- | --------------------------------------------------------- | ------------------------------------------------------------------------------------ |
| `Metric`         | Afficher une valeur et son unité        | value · unit · delta·signe obligatoire · status · loading | Aucun. Nombres tabulaires exigibles                                                  |
| `MetricGrid`     | Disposer des indicateurs                | à plat · recharge (sans effacer)                          | `[P]` : la règle d'ordre est `B26`, pas le layout                                    |
| `FilterChips`    | Filtre croisé                           | inactif · actif · **non disponible**                      | Le « non disponible » est un état de premier plan (`B4`)                             |
| `PeriodSelector` | Choisir la période                      | liste · personnalisée · temporaire                        | `B30` : période appliquée côté service, pas côté client                              |
| `StateBadge`     | Signaler fraîcheur / troncature / échec | fresh · stale · partial · error · **refused**             | `error` et `refused` doivent être **visuellement distincts**                         |
| `RefusalNotice`  | Expliquer un refus                      | refus simple · refus avec action possible                 | `B13` : langage métier, jamais de code technique ; propose une action si elle existe |
| `ViewCard`       | Une vue dans une liste                  | brouillon · publié · partagé · par défaut                 | Ne montre jamais un contenu interdit, **même en résumé** (`B23`)                     |
| `WizardSteps`    | L'assistant en 3 étapes                 | étape courante · complétée · bloquée · visitée            | `B24` : la saisie est conservée au retour arrière                                    |

**Trois composants que la plupart des design systems n'ont pas et qu'ici sont obligatoires** :

1. **`StateBadge` avec `refused` distinct de `error`.** Sans lui, un utilisateur ne peut pas
   distinguer « ça a échoué » de « vous n'avez pas le droit » — deux diagnostics, deux actions
   opposées. `B13` et `B28` l'exigent indirectement.
2. **`MetricGrid` avec état de recharge qui n'efface pas.** Recharger doit conserver les valeurs
   affichées jusqu'aux nouvelles, sinon l'écran clignote et l'utilisateur perd sa place dans sa
   lecture. `B14` : un résultat périmé est signalé, pas remplacé silencieusement.
3. **`FilterChips` avec « non disponible ».** Un filtre interdit ne doit pas être absent — son absence
   serait incompréhensible. Il doit être **présent et marqué** (`B4`, `B14`).

### 2.2 Ce que le socle ne fournit pas

Le socle **ne fournit pas** de composant de rapport, de tableau générique, de formulaire complexe, de
grille réorganisable. Ces éléments appartiennent à l'hôte ou à l'assistant. Le socle ne dessine que
ce dont la **consultation d'une vue** a besoin — tout le reste appartient à l'hôte.

---

## 3. Patterns de navigation

### 3.1 Structure

```
┌─────────────────────────────────────────────────────────────┐
│  Sidebar (plateau 2 entrées)          │   Zone de vue      │
│  ┌──────────┐                          │  ┌───────────────┐ │
│  │ Mes vues │  ← boucle quotidienne    │  │  Titre        │ │
│  ├──────────┤                          │  │  période      │ │
│  │ Admin.   │  ← occasionnel          │  ├───────────────┤ │
│  ├──────────┤                          │  │  MetricGrid   │ │
│  │ Plus ▾   │  ← overflow             │  │  (dense)      │ │
│  └──────────┘                          │  ├───────────────┤ │
│                                        │  │  Filters      │ │
│  ─────────────────────────────         │  └───────────────┘ │
│  Liste des vues (triée, filtrable)      │                    │
└─────────────────────────────────────────────────────────────┘
```

### 3.2 Navigation principale

**Type** : sidebar, collapsible en icônes sous 1024px.
**Plateau** : **2 entrées**, très en dessous du maximum de 5. Un tableau de bord n'a pas besoin de
cinq destinations ; il en a besoin de deux : regarder, et — quand c'est nécessaire — gérer.

| Rang | Module         | Libellé  | Fréq. | Centralité | Justification                                                                                                |
| ---- | -------------- | -------- | ----- | ---------- | ------------------------------------------------------------------------------------------------------------ |
| 1    | Mes vues       | Mes vues | 5/5   | 5/5        | **La boucle quotidienne.** Deux entrées suffisent : consulter est l'usage dominant, composer est l'exception |
| 2    | Administration | Gérer    | 2/5   | 3/5        | Définir une vue par défaut, consulter le journal (`US-11`) — utile mais mensuel pour la plupart              |

**Overflow** :

| Module                   | Libellé   | Raison du placement en overflow                                                                                        |
| ------------------------ | --------- | ---------------------------------------------------------------------------------------------------------------------- |
| Assistant d'installation | Installer | Usage **unique**, jamais récurrent — sa place dans le menu principal dirait qu'il fait partie de la boucle quotidienne |

> **« Mes vues » est premier parce qu'il est le plus utilisé, pas parce qu'il s'appelle Accueil.**
> Il n'y a pas d'entrée « Accueil » : elle ouvrirait une liste vide de plus, et la première chose
> qu'un utilisateur de pilotage veut voir est _ses_ indicateurs, pas un tableau de bord générique.

L'ordre retenu est enregistré de façon vérifiable :

```bash
# Le schéma réel impose key / label / rank / frequency / task_criticality /
# rationale. Une version antérieure de ce document donnait "label / rank /
# screen" : elle était rejetée par set-nav, qui retourne invalid_nav.
# Sous PowerShell, les guillemets sont dévorés par le shell — passer par un
# script Node, ou par un fichier JSON lu puis relayé.
```

Navigation effectivement enregistrée dans `state.json` :

| `key`      | Libellé  | Rang | `screen`              | Fréq. | Centralité |
| ---------- | -------- | ---- | --------------------- | ----- | ---------- |
| `mes-vues` | Mes vues | 1    | `liste-des-vues`      | 5     | 5          |
| `gerer`    | Gérer    | 2    | `administration-vues` | 2     | 3          |

### 3.3 Fil d'Ariane

**Sur desktop uniquement.** `Mes vues › [nom de la vue]`. Jamais sur la page d'une vue en pleine
consultation : la vue est la destination, un fil d'Ariane à un seul cran est du bruit.

### 3.4 Routes

**Les routes sont en anglais, l'interface en français.** C'est la séparation usuelle : le code, les
URL et les identifiants sont lus par des développeurs et des machines ; l'interface est lue par des
utilisateurs. Une URL française serait un défaut, pas une localisation.

| Règle                                              | Exemple                                                   |
| -------------------------------------------------- | --------------------------------------------------------- |
| segments en `kebab-case` ASCII                     | `/views/new/layout`, **pas** `/vues/nouvelle/disposition` |
| noms de segments **descriptifs**, jamais numérotés | `/views/new/metrics`, pas `/views/new/2`                  |
| pluriel pour une collection                        | `/views`                                                  |
| paramètres entre accolades                         | `/views/{id}`                                             |
| jamais de date ni de version dans l'URL            | une URL doit être partageable et stable                   |

> **Pourquoi des segments descriptifs plutôt que `step-1`.** Le tunnel **est** numéroté dans
> l'interface — l'utilisateur doit savoir où il en est. Mais l'URL n'a pas à porter le numéro :
> `/views/new/layout` reste lisible, et insérer un écran de confirmation demain ne décale rien. Un
> numéro dans une URL est un engagement à ne jamais insérer d'étape.

| Écran                   | Route                |
| ----------------------- | -------------------- |
| Liste des vues          | `/views`             |
| Création — informations | `/views/new`         |
| Création — indicateurs  | `/views/new/metrics` |
| Création — disposition  | `/views/new/layout`  |
| Consultation d'une vue  | `/views/{id}`        |
| Administration          | `/admin`             |

**Ce qui reste en français, et pourquoi** : les libellés, les titres de page, les descriptions
d'erreur, les messages de refus — et les **fichiers de spécification** de ce dépôt. Un fichier
`liste-des-vues.md` n'est lu que par vous et par l'agent ; une URL `/vues` est dans l'historique de
navigation de tout le monde, et dans les journaux du serveur.

### 3.5 Transitions

Pas de transition entre deux vues. Le remplacement est instantané : un tableau de bord dense où
l'écran glisse fait perdre la position de lecture, et la position de lecture **est** l'information
que l'utilisateur tient.

---

## 4. Grille et layout

### 4.1 Grille

12 colonnes, `gap: space-3`, `max-width: bp-lg` (1440px), marges `space-8`. Padding `space-4` sur
mobile, `space-6` au-dessus de 1024px.

### 4.2 Règle de composition d'une vue

Une vue est une **grille d'indicateurs**, jamais une liste de cartes alignées verticalement :

| Rangée | Colonnes | Règle                                                         |
| ------ | -------- | ------------------------------------------------------------- |
| KPIs   | 4–6      | Un indicateur = valeur + unité + delta + statut. Rien d'autre |
| Détail | 8–12     | Tableaux, séries temporelles                                  |
| Pied   | pleine   | Notes, fraîcheur, avertissements                              |

> **Pourquoi pas de cartes.** Le gate interdit l'ombre comme séparateur, et une carte **est** une
> ombre ou une bordure arrondie. Mais surtout : une carte crée une frontière là où il n'y a rien à
> délimiter. Dix indicateurs dans une grille se lisent d'un regard ; dix cartes se lisent une par
> une. La densité est l'objectif (§ 0), et la carte en est l'ennemie directe.

**Ordre** : `B26` — l'ordre est celui déclaré par l'auteur et il est **stable**. Le reflow responsive
ne doit pas le rompre : un indicateur qui change de rang entre deux ouvertures oblige l'utilisateur à
le retrouver.

---

## Checklist de gate

**Direction**

- [x] Les trois ancres sont écrites : références, ambiance, anti-références.
- [x] L'archétype est identifié et justifié (`.forge/benchmarks.md` § 1).
- [x] La densité est choisie consciemment et justifiée (dense : comparer plus par unité de temps).
- [x] **Aucun skill de design externe n'a été chargé, et l'absence est justifiée** : les
      contraintes déterminantes ici — portabilité sans DOM (`C6`), densité d'indicateurs,
      communication d'un refus (`B13`) — sont des contraintes de **produit**, pas de style. Un
      générateur de direction visuelle aurait produit un thème attractive et non portable. Le point
      de départ était plus fort : l'app de référence, l'archétype déjà établi, et la liste des `B*`
      qui disent ce que l'interface doit permettre.

**Tokens**

- [x] Tous les tokens ont une **valeur concrète** ; aucun « à voir plus tard ».
- [x] Aucun gabarit non résidu : le contrôle `forge-guard.js placeholders` ne signale rien. Ce qui
      écrit le mot « placeholder » dans une checklist doit l'écrire en toutes lettres, sinon il
      **devient** lui-même un placeholder — le contrôle aurait alors à tort.
- [x] La palette couvre tous les états : default, hover, active, disabled, error, refused, fresh,
      stale, partial, selected.
- [x] **La palette n'est pas une palette par défaut** : `oklch` avec des teintes choisies
      (255 bleu, 155 vert, 75 ambre, 320 violet, 25 rouge, 300 bleu-gris pour le refus).
- [x] Le fond n'est pas du blanc pur : `oklch(0.99 0.003 250)`.
- [x] L'échelle typographique a un **ratio réel** : 1.2 (majorant tiers), pas une suite d'ad hoc.
- [x] Chaque token est marqué `[P]` (portable) ou `[W]` (web).

**Composants**

- [x] Les composants du socle sont énumérés avec leur **capacité**, pas leur apparence.
- [x] Chaque composant a ses états documentés, dont les états métier (`refused`, `non disponible`,
      `recharge sans effacement`).
- [x] **L'ombre n'est pas le séparateur** : la bordure l'est, et la grille n'utilise pas de cartes.
- [x] Trois composants obligatoires absents de la plupart des design systems sont présents, avec
      leur raison (`refused` ≠ `error`, recharge sans effacement, filtre « non disponible »).

**Navigation**

- [x] La navigation est définie pour desktop ET mobile (sidebar collapsible sous 1024px).
- [x] L'ordre est justifié par la fréquence, avec score et raison par entrée.
- [x] La barre principale ne dépasse pas 5 items : **2**, le reste documenté.
- [x] « Accueil » n'est pas une entrée, et le premier rang est justifié par la fréquence.
- [ ] **L'ordre est enregistré via `state.js set-nav`** — à exécuter à la validation, avec les écrans.

**Layout**

- [x] La grille couvre les trois rangées d'une vue (KPI / détail / pied).
- [x] Les animations sont nommées (`120ms` / `200ms` / `instant`) et **ne portent aucune
      information**.
- [x] Au moins un choix visuel est assumé et contestable : **le rayon unique et la grille sans
      cartes**, qui refusent la métaphore de matière au profit de la densité.

## Points laissés ouverts pour la suite

1. **Aucun écran n'est encore spécifié.** Le parcours de création en 3 étapes (`US-2`/`US-3`/`US-4`)
   est l'écran le plus contraint : c'est un tunnel (`transactional_web`) dans un produit `dashboard`.
   Il est la première cible du test `[P]`.
2. **Le thème sombre n'est pas défini.** Il devra l'être, mais il **double** la liaison `[W]` sans
   rien ajouter aux décisions `[P]` — donc il ne remet pas en cause la portabilité.
3. **La densité a une contrepartie qui reste à trancher** : sur un écran étroit, dense et lisible
   entrent en conflit. La règle (passer en 2 colonnes, accepter le défilement vertical) est
   proposée mais n'est pas validée.