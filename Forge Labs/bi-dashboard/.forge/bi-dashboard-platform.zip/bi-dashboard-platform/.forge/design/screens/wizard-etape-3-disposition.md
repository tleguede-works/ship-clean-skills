---
type: screen
slug: wizard-etape-3-disposition
title: Créer une vue — étape 3, disposition
module: views
status: approved
generated_at: 2026-09-29
derived_from: 
rule_ids: [B5, B6, B12, B16, B26, B27, B17]
edge_case_ids: [E9, E13, E1, E2, E12]
flow: creation-de-vue
---

# Écran — Créer une vue, étape 3 : disposition

> Dernière étape, et la seule qui possède deux décisions de fond : **la disposition** (où va quoi)
> et **la publication** (est-ce publié ou brouillon). C'est ici que `E9` vit — la publication d'une
> vue sans indicateur est refusée, et le refus doit coûter à l'utilisateur **exactement zéro
> saisie**.

---

## 1. Rôle de l'écran

|                          |                                                                   |
| ------------------------ | ----------------------------------------------------------------- |
| **Archétype d'app**      | `dashboard` — l'écran **est** un tableau de bord,assayé en direct |
| **Module**               | `views` — rang 1                                                  |
| **Route**                | `/views/new/layout`                                               |
| **Type**                 | `wizard step` — 3 sur 3                                           |
| **Utilisateurs**         | auteur de vue, avec `view:write`, et `view:publish` pour publier  |
| **User stories servies** | `US-4`, `US-5`                                                    |
| **Règles métier**        | `B5`, `B6`, `B12`, `B16`, `B17`, `B26`, `B27`                     |
| **Edge cases**           | `E9`, `E13`, `E1`, `E2`, `E12`                                    |

**Une phrase** : cet écran permet à l'auteur de disposer ses indicateurs et de choisir ce qui se
passe au clic sur « Publier », afin de voir sa vue exactement comme ses lecteurs la verront.

**Pourquoi au rang 1** : c'est la seule étape où l'auteur voit le **résultat**, pas un formulaire.
C'est le moment de vérité de la composition, et il doit donc ressembler à ce que les lecteurs
verront — sinon l'auteur publie autre chose que ce qu'il croyait.

---

## 2. Direction visuelle de cet écran

|                               |                                                                                   |
| ----------------------------- | --------------------------------------------------------------------------------- |
| **Mood**                      | dense, opérationnelle — **identique** à la page de consultation d'une vue         |
| **Densité**                   | **dense**, sans exception                                                         | La disposition se juge à la densité : un test sur la disposition est un jugement sur la disposition |
| **Niveau de contraste**       | identique à la page de vue — aucune différence                                    | Une différence ici dirait à l'auteur qu'il verra autre chose en production. Ce serait un mensonge   |
| **Surface**                   | `--surface` sur `--background`                                                    |
| **Accent utilisé**            | `--primary` uniquement sur les poignées de réorganisation et les boutons d'action |
| **Traitement photographique** | aucun                                                                             |
| **Référence**                 | **la page de consultation d'une vue, à l'identique**                              |

### 2.1 Anti-générique

- [x] Pas de blanc pur
- [x] **Pas de carte par indicateur** — grille, comme dans le design system
- [x] Pas d'uniformité — `metric` 1.5rem/500, `label` 0.8125rem, `caption` 0.75rem
- [x] Pas de gris générique
- [x] Pas de centrage — la grille occupe la largeur, alignée à gauche
- [x] Pas d'illustration
- [x] Un seul rapport d'échelle

**Choix assumé et non neutre** : l'étape 3 **n'a pas de mode « aperçu »**. Il n'y a pas de bascule
« voir l'aperçu » / « voir la disposition » — il n'y a que la disposition, et elle ressemble à la
vue publiée. Un écran d'aperçu séparé est le défaut classique : il différerait de la réalité, donc
l'auteur publierait autre chose que ce qu'il a approuvé, et le premier utilisateur de la vue le
constaterait.

---

## 3. Anatomie

```
WizardFrame
├── StepIndicator                 3/3                                          [P]
├── ViewHeader
│   ├── Title                     nom saisi à l'étape 1
│   ├── StateBadge                brouillon | publié
│   └── PeriodSelector            période — agit sur l'aperçu
├── MetricGrid                    DISPOSITION RÉELLE, exécutée
│   └── MetricCard × n
│       ├── VariableName
│       ├── Metric                valeur, unité, delta
│       ├── StateBadge            normal | stale | partial | error
│       └── DragHandle            réorganisation ; clavier = boutons
├── CompositionBar
│   ├── Button                    "Retour"
│   ├── Button                    "Enregistrer le brouillon"   (toujours)
│   └── Button (primaire)         "Publier"                   → US-5
└── PublishBlock
    ├── AudienceSelector          nominatif | groupes
│   └── RefusalNotice             refus E9, refus de droits
```

| #   | Composant                      | Rôle                                                 | Source             |
| --- | ------------------------------ | ---------------------------------------------------- | ------------------ |
| 1   | `WizardFrame`, `StepIndicator` | Tunnel                                               | design-system §2.1 |
| 2   | `MetricGrid`, `Metric`         | **La vue telle qu'elle sera**                        | design-system §2.1 |
| 3   | `StateBadge`                   | `brouillon` / `publié`, et les états de fraîcheur    | design-system §2.1 |
| 4   | `PeriodSelector`               | Période commune                                      | design-system §2.1 |
| 5   | `FilterChips`                  | Filtre croisé, actif ici (contrairement à l'étape 2) | design-system §2.1 |
| 6   | `RefusalNotice`                | **Le refus de `E9`**, et les refus de droits         | design-system §2.1 |
| 7   | `DragHandle`                   | Réorganisation ; pairé clavier/poignée               | slice-local        |
| 8   | `AudienceSelector`             | Partage nominatif et groupes (`B7`)                  | slice-local        |

---

## 4. States — les 9, sans exception

| État                         | Déclencheur                                                                                         | Rendu                                                                                                                                                                             | Feedback utilisateur                                                                                                                    |
| ---------------------------- | --------------------------------------------------------------------------------------------------- | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | --------------------------------------------------------------------------------------------------------------------------------------- |
| **Chargement**               | Ouverture, ou réorganisation d'un indicateur                                                        | Les valeurs **restent affichées** avec `status-stale` et leur date. **Jamais** de squelette : un squelette ferait croire que la valeur n'a jamais existé                          | `B14` : un résultat périmé est signalé, jamais masqué                                                                                   |
| **Rempli**                   | Indicateurs disposés, exécution réussie                                                             | Grille remplie, `PeriodSelector` actif                                                                                                                                            | —                                                                                                                                       |
| **Vide — jamais visité**     | **Aucune variable : l'auteur a passé l'étape 2 sans rien choisir.** Le tunnel arrive ici quand même | Grille vide, `RefusalNotice` : « Ajoutez au moins un indicateur à l'étape 2 », bouton « Publier » **désactivé** avec la raison affichée                                           | `E9`. L'écran ne masque pas l'anomalie : il la nomme et donne le chemin                                                                 |
| **Vide — aucune donnée**     | Indicateurs présents mais **aucune donnée sur la période**                                          | `B7`/`E5` : chaque indicateur affiche « aucune donnée sur la période active » avec une proposition d'élargir la période si c'est possible                                         | La disposition reste visible et déplaçable : une grille vide ne doit pas empêcher l'auteur de corriger la disposition                   |
| **Erreur de chargement**     | Échec d'exécution d'un indicateur                                                                   | `status-error` sur **cet** indicateur, les autres restent lisibles, « Réessayer »                                                                                                 | `E4` : un indicateur qui échoue ne casse pas la vue                                                                                     |
| **Erreur de soumission**     | Publication refusée · audience invalide                                                             | `RefusalNotice` au-dessus de la barre d'actions, avec la cause en langage métier                                                                                                  | `E9`, `E13`. **La saisie et la disposition sont conservées** — c'est l'exigence explicite de `E9`                                       |
| **Succès**                   | Publication acceptée                                                                                | `StateBadge` passe à `publié`, action devient « Voir la vue »                                                                                                                     | Confirmation **par le changement d'état**, pas par un toast                                                                             |
| **Hors-ligne / permissions** | Réseau perdu · `view:publish` révoqué                                                               | Hors-ligne : valeurs conservées en `stale`, « publication indisponible hors ligne ». Droits : bouton « Publier » désactivé, motif affiché, `Enregistrer le brouillon` reste actif | `E18` : composer hors-ligne est un usage normal ; publier ne l'est pas                                                                  |
| **Lecture seule**            | `view:read` seul                                                                                    | Grille visible en lecture, aucune poignée, aucun bouton d'action                                                                                                                  | `B23` : l'auteur est soumis aux mêmes restrictions que ses lecteurs. Il doit donc **voir sa vue refusée au même endroit qu'un lecteur** |

> **`E1` (deux éditeurs sur le même brouillon) est un état d'écran, et le pire.** Si l'auteur B
> modifie la disposition pendant que le A est dessus, l'écran affiche un bandeau non bloquant :
> « Cette vue a été modifiée par {auteur} à {heure} ». Le brouillon local est **conservé** ; aucune
> saisie n'est écrasée. Choisir entre recharger, garder ma copie ou annuler — jamais écraser
> silencieusement, jamais perdre le travail.

---

## 5. Interactions

| Élément                | Événement             | Comportement                                            | Feedback visuel                                                                              | État résultant   | ID           |
| ---------------------- | --------------------- | ------------------------------------------------------- | -------------------------------------------------------------------------------------------- | ---------------- | ------------ |
| `DragHandle`           | `drag`                | Réordonne l'indicateur                                  | La grille se recompose, la valeur **ne se réexécute pas**                                    | ordre modifié    | `B26`        |
| `DragHandle` (clavier) | `Espace` puis `↑`/`↓` | Déplace l'indicateur focused                            | Le même changement, announced par un `aria-live`                                             | ordre modifié    | `B26`        |
| `PeriodSelector`       | `change`              | Change la période, réexécute                            | Valeurs en `stale` pendant l'exécution                                                       | nouveau résultat | `B22`        |
| `FilterChips`          | `tap`                 | Filtre croisé, appliqué **côté service**                | `status-selected` sur le filtre actif ; les indicateurs non concernés portent « non filtré » | filtrage         | `B30`, `E17` |
| « Publier »            | `submit`              | Publication, refusée si 0 indicateur                    | `RefusalNotice` explicative **sans perte de saisie**                                         | publié / refusé  | `B27`, `E9`  |
| `AudienceSelector`     | `change`              | Choisit les destinataires                               | Liste des noms et groupes                                                                    | audience définie | `B7`         |
| Audience supprimée     | `auto`                | `RefusalNotice` : audience invalide                     | Action : corriger l'audience, **pas** publier en silence                                     | `E13`            | `E13`        |
| Variable disparue      | `auto`                | `StateBadge` `mise à jour requise`, publication bloquée | `E2`                                                                                         | bloqué           | `E2`, `B12`  |
| Bandeau de concurrence | `auto`                | Informe, ne bloque pas, ne remplace rien                | Choix : recharger / garder ma copie / annuler                                                | `E1`             | `E1`         |

- **Focus / clavier** : toute réorganisation par glisser a un **équivalent clavier** — sans lui,
  l'ordre n'est pas accessible, donc `B26` n'est pas tenu. `Tab` parcourt les poignées, `Espace`
  saisit, flèches déplacent, `Échap` annule le déplacement en cours.
- **Gestes** : glisser-déposer **et** boutons monter/descendre, toujours les deux. Le geste seul
  n'est pas accessible ; le bouton seul est lent sur de longues vues.
- **Animations** : `duration-fast` sur le déplacement. La réorganisation **ne s'anime pas** de façon
  visible — l'indicateur change de case, il ne glisse pas. Sur une grille dense, un glissement
  masquerait la valeur qu'on vient de déplacer.
- **Retour arrière** : le navigateur, disposition conservée (`B16` — le brouillon n'est jamais
  détruit par un échec).

---

## 6. Responsive

| Breakpoint              | Comportement                                                                  | Ce qui se replie / disparaît                                            |
| ----------------------- | ----------------------------------------------------------------------------- | ----------------------------------------------------------------------- |
| **Mobile** (<640px)     | Une colonne, ordre conservé (`B26` : le **rang** ne bouge pas, la largeur si) | `DragHandle` remplacée par boutons ; `PeriodSelector` en ligne compacte |
| **Tablet** (640–1024px) | 2 colonnes                                                                    | rien                                                                    |
| **Desktop** (>1024px)   | Grille 4–6 KPI puis détail, `CompositionBar` sticky en bas                    | rien                                                                    |

- **Cible tactile** : 44 × 44 px sur les poignées et les boutons de la barre d'actions. Les
  `MetricCard` ne sont pas des cibles tactiles : elles ne sont cliquables que si un filtre croisé
  s'y applique, auquel cas **toute la carte** est la cible, pas seulement la valeur.
- **Débordement** : `PeriodSelector` ne déborde jamais — il passe en menu compact sous 360px. Une
  valeur d'indicateur ne déborde pas : elle se tronque avec une infobulle, jamais en débordement.

---

## 7. Accessibilité

- [ ] Contraste ≥ 4.5:1 courant, ≥ 3:1 grands textes
- [ ] Navigation clavier complète, réorganisation comprise
- [ ] Focus visible ; pendant un déplacement au clavier, un `aria-live="assertive"` annonce
      « Indicateur déplacé en position 3 sur 5 » — sans quoi le déplacement est invisible en
      lecture non visuelle
- [ ] `aria-label` sur chaque `MetricCard` : nom de la variable, valeur, unité, statut
- [ ] `aria-live="polite"` sur le `StateBadge` de publication — `brouillon` → `publié` est un
      changement d'état, pas une navigation
- [ ] `RefusalNotice` dans une région `aria-live="assertive"` : un refus de publication doit être
      annoncé, pas seulement affiché
- [ ] `aria-describedby` reliant le bouton « Publier » désactivé **à son motif** — un bouton
      désactivé sans raison accessible est un mur
- [ ] `StateBadge` jamais par la couleur seule
- [ ] Langue `fr`, direction LTR

---

## 8. Données

| Champ          | Type                             | Origine                          | Requis           | Erreur possible                                  |
| -------------- | -------------------------------- | -------------------------------- | ---------------- | ------------------------------------------------ |
| `disposition`  | `{indicateurId, rang, taille}[]` | brouillon local, persisté        | oui              | ordinal incohérent → recalculé, jamais rejeté    |
| `resultats`    | `Resultat[]`                     | exécution réelle, `data:execute` | oui              | `E4`, `E6`, `E7`                                 |
| `periode`      | `Période`                        | choix utilisateur                | oui              | —                                                |
| `filtreCroise` | `Filtre?`                        | choix utilisateur                | non              | ne s'applique pas à tous les indicateurs → `E17` |
| `audience`     | `{utilisateur \| groupe}[]`      | sélection                        | oui pour publier | cible supprimée → `E13`                          |
| `permissions`  | `Action[]`                       | autorisation de l'hôte           | oui              | `view:publish` absent → état lecture seule       |
| `concurrence`  | `{auteur, instant}?`             | service                          | non              | `E1`                                             |

- **Chargement** : un bloc. La grille d'une vue ne se pagine pas.
- **Cache / hors-ligne** : disposition et brouillon persistés en continu. Les **résultats ne sont pas
  mis en cache** : au retour, réexécution et, si le réseau est absent, `status-stale` avec la
  dernière valeur connue et sa date. Une valeur périmée présentée comme fraîche est pire qu'une
  absence.
- **Données sensibles** : la disposition ne contient que des **références** (`B2`) — aucun SQL, aucun
  secret, aucune URL de données (`B25`). L'aperçu est une exécution réelle et obéit aux trois
  contrôles. Le journal de cette exécution est normalisé : ni valeurs filtrées, ni lignes (`B28`).

---

## 9. Traçabilité

| ID    | Origine | Manifestation sur cet écran                                                                                                                                                         |
| ----- | ------- | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `B26` | PRD     | L'ordre déclaré est celui affiché, et le réordonner ne réexécute rien                                                                                                               |
| `B27` | PRD     | **La publication d'une vue sans indicateur est refusée**, avec message explicite                                                                                                    |
| `B5`  | PRD     | Une vue publiée est **immuable** : toute modification travaille sur un brouillon distinct. Ce que l'on modifie ici n'est **pas** ce que les lecteurs voient, et ne l'altère pas     |
| `B6`  | PRD     | La publication crée une **version distincte et identifiable** : changer la disposition d'une vue publiée produit une nouvelle version, l'ancienne reste consultable                 |
| `B12` | PRD     | Un indicateur dont une variable disparaît ou devient interdite passe en « mise à jour requise » — ici, la publication est bloquée tant que ce n'est pas résolu                      |
| `B17` | PRD     | Toute action d'organisation a un **équivalent clavier** : le glisser-déposer a son équivalent bouton, sans quoi l'ordre n'est pas accessible                                        |
| `B22` | PRD     | Changer de période ne mélange pas deux jeux de résultats incohérents : l'état transitoire est marqué `stale`                                                                        |
| `B7`  | PRD     | Le partage est explicite, listé et révocable, et porte **à la fois** sur des personnes nommées et sur des groupes — d'où l'`AudienceSelector` et non une liste d'utilisateurs seuls |
| `B30` | PRD     | Le filtre croisé agit sur **la même vue**, et il est appliqué côté service sous les mêmes droits                                                                                    |
| `E9`  | PRD     | **Publication refusée sans indicateur**, message expliquant, saisie et disposition conservées                                                                                       |
| `E13` | PRD     | Audience invalide signalée, jamais échec silencieux                                                                                                                                 |
| `E1`  | PRD     | Édition concurrente : bandeau non bloquant, **aucun écrasement**, choix explicite                                                                                                   |
| `E2`  | PRD     | Variable disparue → `mise à jour requise`, publication bloquée                                                                                                                      |
| `E12` | PRD     | Disposition persistée en continu, récupérable au retour                                                                                                                             |
| `E18` | PRD     | Hors-ligne : composer reste possible, publier ne l'est pas — et l'écran le dit                                                                                                      |

---

## 10. Checklist de gate

- [x] Les 9 états sont décrits avec un rendu concret
- [x] Chaque élément interactif a un comportement et un feedback
- [x] Le responsive est défini à chaque breakpoint
- [x] La section Anti-générique est cochée et justifiée
- [x] Aucune valeur de design n'est laissée à « à définir »
- [x] Chaque ID `B*` / `E*` de l'écran apparaît en section 9
- [x] Aucun gabarit non résidu
- [x] L'écran reste cohérent avec le design system
- [x] **Test `[P]`** : l'écran n'utilise que des capacités du registre. Le résultat est notable —
      **il est entièrement composable en vue native** : grille, texte, badges, poignées. Un hôte sans
      DOM peut rendre ce parcours sans rien perdre, ce qui est précisément ce que la V1.5 doit
      démontrer.