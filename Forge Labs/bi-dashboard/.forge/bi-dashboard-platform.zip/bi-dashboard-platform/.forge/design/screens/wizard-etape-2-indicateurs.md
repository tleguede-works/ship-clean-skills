---
type: screen
slug: wizard-etape-2-indicateurs
title: Créer une vue — étape 2, indicateurs
module: views
status: approved
generated_at: 2026-09-29
derived_from: 
rule_ids: [B2, B3, B4, B12, B19, B23, B25, B26]
edge_case_ids: [E2, E3, E4, E6, E7, E11, E14, E17]
flow: creation-de-vue
---

# Écran — Créer une vue, étape 2 : indicateurs

> L'écran le plus contraint du produit. C'est ici que l'utilisateur **compose** une vue, donc ici
> que `B25` s'applique : le contrôle d'accès ne porte pas sur la vue, il porte sur **tout chemin
> menant aux données**.

---

## 1. Rôle de l'écran

|                          |                                                                                  |
| ------------------------ | -------------------------------------------------------------------------------- |
| **Archétype d'app**      | `admin_crud` (catalogue + liste sélectionnée) dans un tunnel `transactional_web` |
| **Module**               | `views` — rang 1                                                                 |
| **Route**                | `/views/new/metrics`                                                             |
| **Type**                 | `wizard step` — 2 sur 3                                                          |
| **Utilisateurs**         | auteur de vue, avec `view:write` **et** les droits de données nécessaires        |
| **User stories servies** | `US-3`                                                                           |
| **Règles métier**        | `B2`, `B3`, `B4`, `B12`, `B13`, `B19`, `B23`, `B25`, `B26`                       |
| **Edge cases**           | `E2`, `E3`, `E4`, `E6`, `E7`, `E11`, `E14`, `E17`                                |

**Une phrase** : cet écran permet à l'auteur de choisir des variables métier autorisées et d'en
faire des indicateurs, afin de composer une vue sans écrire de requête.

**Pourquoi au rang 1** : c'est l'étape que l'utilisateur ne connaît pas encore. Le catalogue est
le cœur du besoin, et il est aussi le plus dangereux : c'est là qu'une fuite pourrait se produire.

---

## 2. Direction visuelle de cet écran

|                               |                                                                                                                                                         |
| ----------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------- |
| **Mood**                      | dense, opérationnelle — la densité est ici au service de la comparaison                                                                                 |
| **Densité**                   | **dense** — catalogue en liste dense, indicateurs en lignes. C'est le seul écran où la densité est le bon choix : on compare beaucoup                   |
| **Niveau de contraste**       | fort sur les noms de variables, moyen sur les métadonnées                                                                                               |
| **Surface**                   | `--surface` sur `--background`, catalogue en `surface-raised`                                                                                           |
| **Accent utilisé**            | `--primary` sur la variable sélectionnée et l'indicateur retenu. **Jamais** sur un statut — un statut coloré en `primary` se confond avec une sélection |
| **Traitement photographique** | aucun                                                                                                                                                   |
| **Référence**                 | l'étape 2 d'un assistant de construction de requêtes, pas un formulaire                                                                                 |

### 2.1 Anti-générique

- [x] Pas de blanc pur
- [x] **Pas de carte par variable** — le catalogue est une **liste dense** à bordure, pas une
      mosaïque de cartes. Un catalogue de 200 variables en cartes est impraticable ; en lignes
      denses, il se parcourt
- [x] Pas d'uniformité — variable en `label`/`text-primary`, métadonnées en `caption`/`text-muted`,
      unité en `metric-unit` : trois niveaux
- [x] Pas de gris générique — les neutres viennent des rôles
- [x] Pas de centrage symétrique — catalogue à gauche, indicateurs retenus à droite, en permanence
- [x] Pas d'illustration
- [x] Un seul rapport d'échelle fait la hiérarchie (1.2)

**Choix assumé et non neutre** : le catalogue **montre les variables interdites, grisées et
cliquables-pour-expliquer**, au lieu de les cacher. Un catalogue filtré par les droits semble
protecteur et produit deux dégâts : l'utilisateur ne sait pas que la donnée existe (`B13` : il ne
comprendra pas pourquoi son tableau est vide), et l'interface laisse croire à un bug. Marquer est
plus honnête que cacher.

---

## 3. Anatomie

```
WizardFrame
├── StepIndicator                       2/3, étapes 1 et 3 accessibles          [P]
├── SplitLayout
│   ├── CatalogPanel  (gauche)
│   │   ├── SearchInput                filtre texte sur le libellé
│   │   ├── CatalogList                liste dense
│   │   │   └── CatalogRow × n
│   │   │       ├── VariableName       nom métier résolu              B3
│   │   │       ├── VariableUnit       unité, accolée
│   │   │       ├── StateBadge         · normal  · interdit  · mise à jour requise
│   │   │       └── RowAction          "Ajouter" | "Pourquoi indisponible ?"
│   │   └── EmptyState                 aucune variable ne correspond
│   └── SelectionPanel  (droite)
│       ├── SelectionList              indicateurs retenus, ordre stable      B26
│       │   └── SelectedRow × n
│       │       ├── VariableName
│       │       ├── Aggregation         somme · compte · moyenne · min · max
│       │       ├── FilterRow           filtres par variable               B17
│       │       ├── StateBadge          normal · mise à jour requise · non pris en charge
│       │       ├── ScopeNote           "périmètre : non déterminable" si E
│       │       └── RowActions          monter · descendre · retirer
│       ├── AperçuMetric                rendu de l'indicateur, exécution réelle
│       └── ExecutionStatus            durée · lignes · troncature
└── Actions
    ├── Button (secondaire)  "Retour"
    └── Button (primaire)    "Continuer"  → étape 3 ; exige ≥ 1 indicateur
```

| #   | Composant                      | Rôle                                                    | Source                           |
| --- | ------------------------------ | ------------------------------------------------------- | -------------------------------- |
| 1   | `WizardFrame`, `StepIndicator` | Tunnel, progression                                     | design-system §2.1 `WizardSteps` |
| 2   | `Metric`                       | Aperçu d'un indicateur, valeur réelle                   | design-system §2.1               |
| 3   | `StateBadge`                   | `interdit`, `mise à jour requise`, `non pris en charge` | design-system §2.1               |
| 4   | `FilterChips`                  | Filtre croisé inactif à cette étape                     | design-system §2.1               |
| 5   | `PeriodSelector`               | Période commune de l'aperçu                             | design-system §2.1               |
| 6   | `SearchInput`                  | Filtrer le catalogue                                    | slice-local                      |
| 7   | `CatalogRow`                   | Une variable, avec son état d'accès                     | slice-local                      |
| 8   | `SelectedRow`                  | Un indicateur retenu et son ordre                       | slice-local                      |
| 9   | `ExecutionStatus`              | Durée, lignes, troncature                               | slice-local                      |
| 10  | `RefusalNotice`                | **Explique** un refus ou une indisponibilité            | design-system §2.1               |

> `RefusalNotice` est un composant du design system précisément parce que cet écran en a besoin
> plus que tout autre. Il n'affiche jamais un code : `B13` l'interdit, et un code dans une
> `RefusalNotice` est un signal que la règle a été contournée.

---

## 4. States — les 9, sans exception

| État                         | Déclencheur                                      | Rendu                                                                                                                                                                                        | Feedback utilisateur                                                                      |
| ---------------------------- | ------------------------------------------------ | -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ----------------------------------------------------------------------------------------- |
| **Chargement**               | Ouverture, ou exécution d'un aperçu              | `CatalogList` en lignes squelette de **hauteur fixe**. `SelectionPanel` garde son contenu précédent s'il existe                                                                              | L'aperçu affiche son ancienne valeur avec `status-stale` — jamais de squelette à sa place |
| **Rempli**                   | Catalogue et indicateurs chargés                 | Liste dense, indicateurs ordonnés, aperçu exécuté                                                                                                                                            | Durée et nombre de lignes affichés en `caption`                                           |
| **Vide — jamais visité**     | Première ouverture, aucune variable sélectionnée | `CatalogList` rempli, `SelectionPanel` vide avec **un texte d'action** : « Choisissez une variable à gauche »                                                                                | Pas d'illustration. Un panneau vide qui ne dit rien à faire est un panneau mort           |
| **Vide — aucune donnée**     | Catalogue vide après recherche                   | Message nommant le terme cherché + « Effacer la recherche »                                                                                                                                  | `E3` : si tout est interdit, le message le dit et propose une action                      |
| **Erreur de chargement**     | Catalogue indisponible                           | `status-error` dans le panneau catalogue, liste sélectionnée **conservée**                                                                                                                   | « Réessayer ». On ne perd pas la composition pour un échec de catalogue                   |
| **Erreur de soumission**     | Ajout d'une variable échoue                      | Erreur sur la ligne concernée, pas de toast                                                                                                                                                  | `B13` : message métier, action possible proposée                                          |
| **Succès**                   | Variable ajoutée                                 | La ligne apparaît dans `SelectionPanel`, l'aperçu s'exécute                                                                                                                                  | `StateBadge` `normal` sur l'indicateur                                                    |
| **Hors-ligne / permissions** | Réseau perdu · `data:execute` révoqué            | Hors-ligne : saisie conservée, l'aperçu passe `status-stale` avec « dernière valeur connue ». Droits : le catalogue passe en lecture seule, chaque variable `interdit` garde son explication | `E3`, `E18` : les nouveaux chargements cessent, l'interface **explique**                  |
| **Lecture seule**            | `data:execute` absent, mais catalogue lisible    | Variables visibles, aucune exécution, `RefusalNotice` explicatif sur chaque tentative                                                                                                        | Proposition : « Demander l'accès » si l'hôte l'implémente                                 |

> **`E6` et `E7` ne sont pas des états d'écran mais des états d'aperçu.** Une troncature
> (`E6`) affiche le compte exact — jamais un total silencieux ; un dépassement de durée (`E7`)
> produit un refus avec une alternative plus légère. Les deux sont portés par `Metric` +
> `StateBadge`, pas par une vue d'ensemble.

---

## 5. Interactions

| Élément                            | Événement | Comportement                                                  | Feedback visuel                                           | État résultant   | ID           |
| ---------------------------------- | --------- | ------------------------------------------------------------- | --------------------------------------------------------- | ---------------- | ------------ |
| `SearchInput`                      | `type`    | Filtre le catalogue sur le libellé, côté client               | Liste réduite, compteur « 12 sur 200 »                    | filtré           | `B3`         |
| `CatalogRow`                       | `tap`     | Ajoute la variable aux indicateurs                            | Ligne apparaît en `SelectionPanel`                        | composition      | `B2`         |
| `CatalogRow` (interdite)           | `tap`     | **N'ajoute pas.** Ouvre l'explication                         | `RefusalNotice` : variable, motif métier, action possible | inchangé         | `B13`, `B19` |
| `CatalogRow` (mise à jour requise) | `tap`     | N'ajoute pas, propose la résolution                           | Bandeau sur la variable, publication signalée bloquée     | `E2`             | `E2`         |
| `Aggregation`                      | `change`  | Change l'agrégat, ré-exécute l'aperçu                         | Valeur remplacée, `stale` pendant l'exécution             | recalcul         | `B26`        |
| Monter / descendre                 | `tap`     | Change l'ordre, **sans ré-exécuter**                          | L'ordre est la seule chose qui change                     | ordre stable     | `B26`        |
| Retirer                            | `tap`     | Retire l'indicateur, avec confirmation si dernier             | La ligne disparaît                                        | composition      | —            |
| `FilterRow`                        | `change`  | Ajoute un filtre, **identifie les indicateurs non concernés** | `E17` : les lignes non filtrées portent « non filtré »    | filtrage partiel | `E17`        |
| Aperçu                             | `auto`    | Exécute à l'ajout, à l'agrégat, au changement de période      | `ExecutionStatus` : durée, lignes                         | —                | `B25`        |
| « Continuer »                      | `submit`  | → étape 3 si ≥ 1 indicateur                                   | disabled sinon, avec raison                               | étape 3          | `B27`        |

- **Focus / clavier** : la liste du catalogue est un `listbox` — flèches haut/bas, `Entrée` pour
  ajouter, `Échap` pour désélectionner. Le focus ne **saute pas** du catalogue à la sélection à
  chaque ajout : ce serait un aller-retour pour chaque indicateur. `Tab` passe une fois, `Entrée`
  répète.
- **Gestes** : aucun glissement. L'ordre se change par boutons, pas par drag : le glisser-déposer
  n'a pas de clavier équivalent, et un ordre non accessible est un ordre absent (`B26`).
- **Animations** : `duration-fast` sur l'état d'une ligne. La **réexécution ne s'anime pas** — la
  valeur est remplacée, pas comptée. Compter serait une animation qui porte une information.
- **Retour arrière** : le navigateur, et la composition est conservée (`B16` — un brouillon en cours de
  saisie n'est jamais détruit par un échec).

---

## 6. Responsive

| Breakpoint              | Comportement                                                                             | Ce qui se replie / disparaît                                                                      |
| ----------------------- | ---------------------------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------- |
| **Mobile** (<640px)     | **Un onglet à la fois** : catalogue, puis sélection, avec un compteur « 3 sélectionnés » | Les deux panneaux ne cohabitent pas : 200 variables + une composition dans 360px serait illisible |
| **Tablet** (640–1024px) | Deux colonnes, catalogue 40% / sélection 60%                                             | Unités sur les lignes du catalogue si la largeur manque                                           |
| **Desktop** (>1024px)   | Deux colonnes 50/50, `SelectionPanel` sticky, aperçu sous la liste                       | rien                                                                                              |

- **Cible tactile** : 44 × 44 px. Une ligne de catalogue à 44px sur mobile affiche 8 variables par
  écran ; c'est accepté, la priorité au mobile est la composition, pas la recherche exhaustive.
- **Débordement** : un nom de variable **ne déborde jamais** — il passe sur deux lignes avec
  troncature en fin, jamais en débordement horizontal. Un nom d'indicateur dans une grille de 2
  colonnes sur 360px est le cas le plus probable de débordement du produit.

---

## 7. Accessibilité

- [ ] Contraste ≥ 4.5:1 pour le texte courant, ≥ 3:1 pour les grands textes
- [ ] Navigation clavier complète : `listbox` au catalogue, boutons d'ordre dans la sélection,
      `Tab` unique entre les deux panneaux
- [ ] Focus visible sur chaque ligne actionnable
- [ ] `aria-live="polite"` sur le compteur « 12 sur 200 » et sur l'ajout d'un indicateur
- [ ] `aria-disabled` (et non `disabled`) sur une variable interdite : elle reste focusable, sinon
      un lecteur d'écran ne découvrira jamais l'explication — c'est précisément le cas que `B13`
      veut servir
- [ ] `aria-describedby` reliant chaque variable interdite à son motif
- [ ] `StateBadge` jamais porté par la couleur seule : Always accompanied du texte
- [ ] L'ordre des indicateurs est annoncé (`aria-label="Indicateur 2 sur 3"`) — un ordre visuel non
      annoncé n'est pas un ordre

---

## 8. Données

| Champ                 | Type                 | Origine                                                            | Requis                     | Erreur possible                                    |
| --------------------- | -------------------- | ------------------------------------------------------------------ | -------------------------- | -------------------------------------------------- |
| `catalogue`           | `Variable[]`         | service de données, **filtré par les droits du service**           | oui                        | catalogue indisponible                             |
| `variablesInterdites` | `Variable[]` + motif | même source, non filtrée — **avec motif**                          | oui                        | motif manquant → l'interface ne peut pas expliquer |
| `indicateurs`         | `Indicateur[]`       | brouillon local, persisté                                          | non (min 1 pour continuer) | —                                                  |
| `agregatsDisponibles` | `Aggregation[]`      | hôte — `B4` : seules les agrégations **supportées** sont proposées | oui                        | type devenu non supporté → `E14`                   |
| `resultatApercu`      | `Resultat`           | exécution réelle, `data:execute`                                   | non                        | `E6` troncature, `E7` durée                        |
| `scopeResolu`         | `Périmètre?`         | service                                                            | oui                        | non déterminable → **résultat vide**, jamais tout  |

- **Chargement** : le catalogue en **un bloc** (200 lignes, pas de pagination — un catalogue se
  filtre, il ne se pagine pas). Les indicateurs retenus en liste, sans pagination.
- **Cache / hors-ligne** : le catalogue est mis en cache par session. Les aperçus ne le sont pas :
  une valeur périmée présentée comme fraîche est pire qu'une absence de valeur. Hors-ligne, l'aperçu
  affiche la **dernière valeur connue** avec `status-stale` et sa date.
- **Données sensibles** : `variablesInterdites` ne contient que le **nom** de la variable et le motif
  du refus — **jamais** sa définition, ses valeurs d'exemple ni son schéma. Le fait qu'une variable
  existe est déjà une information, et le motif doit être formulé en termes métier, jamais en code
  de droit (`B13`). Rien de tout cela n'est journalisé au-delà du compte d'exécution normalisé
  (`B28`).

---

## 9. Traçabilité

| ID      | Origine        | Manifestation sur cet écran                                                                                                                                                                                                                                                                                      |
| ------- | -------------- | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `B2`    | PRD            | Un indicateur est une **référence** stable ; l'aperçu exécute, le brouillon ne contient pas de requête                                                                                                                                                                                                           |
| `B3`    | PRD            | Le catalogue ne propose que des **noms de variables métier**, jamais des champs techniques                                                                                                                                                                                                                       |
| `B4`    | PRD            | Seules les agrégations **supportées** par l'hôte sont proposées ; une variable sans agrégat supporté est `non pris en charge`                                                                                                                                                                                    |
| `B12`   | PRD            | Une variable disparue **ou devenue interdite** fait passer l'indicateur en « mise à jour requise » ; la publication est bloquée tant que ce n'est pas résolu                                                                                                                                                     |
| `B19`   | PRD            | L'interface n'affiche **jamais** de nom de table, de champ technique, de code ni de secret — y compris dans le motif d'un refus                                                                                                                                                                                  |
| `US-14` | PRD (critères) | « Les variables sensibles ne sont pas proposées à qui n'a pas le droit de les consulter » et « un aperçu ne contient jamais un champ interdit ». Le catalogue **les montre** mais ne les **propose pas** à l'ajout : masquer une information et interdire une action sont deux choses, et `B13` exige la seconde |
| `B23`   | PRD            | L'auteur est soumis aux **mêmes** restrictions que ses lecteurs : s'il ne peut pas voir la variable, l'aperçu ne s'exécute pas pour lui non plus                                                                                                                                                                 |
| `B25`   | PRD            | Le contrôle d'accès s'applique **à l'aperçu** comme à la consultation. Les trois contrôles **conjointifs** (vue, champ, périmètre de lignes) sont donc exigés ici aussi                                                                                                                                          |
| `B26`   | PRD            | L'ordre est celui déclaré, **stable**, et le réordonner **ne réexécute rien**                                                                                                                                                                                                                                    |
| `E2`    | PRD            | Variable disparue → `mise à jour requise`, publication signalée bloquée                                                                                                                                                                                                                                          |
| `E3`    | PRD            | Variable devenue interdite → les nouveaux chargements cessent, l'interface explique                                                                                                                                                                                                                              |
| `E4`    | PRD            | Un indicateur échoue → son erreur, les autres restent lisibles, « Réessayer »                                                                                                                                                                                                                                    |
| `E6`    | PRD            | Troncature signalée avec le **compte exact**, jamais un total silencieux                                                                                                                                                                                                                                         |
| `E7`    | PRD            | Dépassement de durée → refus explicite et alternative plus légère                                                                                                                                                                                                                                                |
| `E11`   | PRD            | Changement de catalogue pendant l'édition → **aucun indicateur ne pointe silencieusement** vers une autre variable                                                                                                                                                                                               |
| `E14`   | PRD            | Type d'indicateur non supporté → `non pris en charge`, la vue ne casse pas                                                                                                                                                                                                                                       |
| `E17`   | PRD            | Filtre ajouté à la volée → les indicateurs non concernés sont marqués « non filtrés »                                                                                                                                                                                                                            |

---

## 10. Checklist de gate

- [x] Les 9 états sont décrits avec un rendu concret
- [x] Chaque élément interactif a un comportement et un feedback
- [x] Le responsive est défini à chaque breakpoint
- [x] La section Anti-générique est cochée et justifiée
- [x] Aucune valeur de design n'est laissée à « à définir »
- [x] Chaque ID `B*` / `E*` de l'écran apparaît en section 9
- [x] Aucun gabarit non résidu
- [x] L'écran reste cohérent avec le design system
- [x] **Test `[P]`** : `RefusalNotice`, `StateBadge`, `Metric`, `FilterChips`, `PeriodSelector` sont
      des capacités du registre. L'écran est entièrement exprimable chez un hôte sans DOM — ce qui
      est le vrai résultat de cet écran : **il ne dépend d'aucune notion de DOM**.