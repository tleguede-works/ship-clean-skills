---
type: screen
slug: wizard-etape-1-informations
title: Créer une vue — étape 1, informations
module: views
status: approved
generated_at: 2026-09-29
derived_from: 
rule_ids: [B1, B10b, B16, B24]
edge_case_ids: [E9, E12, E18]
flow: creation-de-vue
---

# Écran — Créer une vue, étape 1 : informations

> Source de vérité pour générer cet écran. Le parcours complet est en trois étapes
> (`wizard-etape-1-informations` → `wizard-etape-2-indicateurs` → `wizard-etape-3-disposition`).
> Chaque étape est un écran séparé parce qu'elle a **ses propres états** : la 2 a des cas que la 1
> n'a pas, la 3 a un état vide que ni l'une ni l'autre n'a.

---

## 1. Rôle de l'écran

|                          |                                                          |
| ------------------------ | -------------------------------------------------------- |
| **Archétype d'app**      | `transactional_web` (tunnel) dans un produit `dashboard` |
| **Module**               | `views` — rang 1 dans la navigation (boucle quotidienne) |
| **Route**                | `/views/new`                                             |
| **Type**                 | `wizard step` — 1 sur 3                                  |
| **Utilisateurs**         | auteur de vue, avec `view:write`                         |
| **User stories servies** | `US-2`                                                   |
| **Règles métier**        | `B1`, `B10b`, `B16`, `B24`                               |
| **Edge cases**           | `E9`, `E12`, `E18`                                       |

**Une phrase** : cet écran permet à l'auteur de nommer sa vue et de dire ce qu'elle sert, afin de
pouvoir la retrouver plus tard sans l'ouvrir.

**Pourquoi au rang 1 de la navigation** : il ne l'est pas directement — il est **atteignable depuis**
le rang 1. Le wizard est une exception de la boucle quotidienne, pas une destination.

---

## 2. Direction visuelle de cet écran

|                               |                                                                                                                                     |
| ----------------------------- | ----------------------------------------------------------------------------------------------------------------------------------- |
| **Mood**                      | dense, opérationnelle, digne de confiance                                                                                           |
| **Densité**                   | **normale** — l'exception assumée du produit. C'est un formulaire de trois champs : ici la densité n'aide à rien et coûte la saisie |
| **Niveau de contraste**       | **fort** sur les libellés de champ, moyen ailleurs — la saisie exige de la précision, pas de l'ambiance                             |
| **Surface**                   | `--surface` sur `--background`                                                                                                      |
| **Accent utilisé**            | `--primary` sur le bouton de continuation et le focus. Ailleurs : aucun — un champ de formulaire n'est pas un CTA                   |
| **Traitement photographique** | aucun                                                                                                                               |
| **Référence**                 | l'étape 1 du tunnel, pas la page de vue                                                                                             |

### 2.1 Anti-générique

- [x] Pas de fond blanc pur — `--background: oklch(0.99 0.003 250)`
- [x] **Pas de carte ombrée pour tout** — pas de carte du tout : un formulaire de 3 champs n'a pas
      besoin d'un conteneur. Le fond de page suffit.
- [x] Pas d'uniformité — le titre est en `title` (1.25rem/600), les libellés en `label`, le texte
      d'aide en `caption` : trois niveaux, pas un espacement constant.
- [x] Pas de gris neutre générique — les neutres viennent des rôles `text-secondary` / `text-muted`
- [x] **Pas de mise en page centrée symétrique** — le formulaire est aligné à gauche dans une
      colonne de largeur de lecture. Centré serait un formulaire générique de page de connexion ; or
      celui-ci est le début d'un travail en cours, pas une demande d'accès.
- [x] Pas d'illustration d'appoint
- [x] Pas d'une seule famille de police — le rapport d'échelle 1.2 fait la hiérarchie

**Choix assumé et non neutre** : l'écran **affiche la progression en trois étapes dès la première
page**, et indique que la saisie est conservée si l'on revient en arrière. Un formulaire générique
cache ces deux faits jusqu'au moment où l'utilisateur les découvre — c'est-à-dire trop tard. Ici la
conservation de la saisie (`B16`) est une information d'écran, pas une promesse faite après coup.

---

## 3. Anatomie

```
WizardFrame
├── StepIndicator            progression 1/2/3, étapes visitées conservées   [P]
├── Title                    "Créer une vue"        type: title
├── ViewCard (aperçu)        ce que la carte montrera dans la liste de vues  [P] §2.1
│   └── StateBadge           statut du brouillon : jamais "publié"
├── Field
│   ├── Label                "Nom"        label, requis
│   ├── Input                texte        hauteur 40px, un seul rayon
│   └── Help                 "Ce nom est visible par ceux à qui vous partagez"  caption
├── Field (optionnel)
│   ├── Label                "Description"
│   ├── Textarea             3 lignes
│   └── Toggle               "Description obligatoire"   → configurable par l'hôte (B1)
├── SaveState                "Brouillon enregistré il y a 2 min"  caption
└── Actions
    ├── Button (secondaire)  "Annuler"      → retour à la liste
    └── Button (primaire)    "Continuer"     → étape 2, actif seulement si nom non vide
```

| #   | Composant                      | Rôle                                  | Source                           |
| --- | ------------------------------ | ------------------------------------- | -------------------------------- |
| 1   | `WizardFrame`                  | Conteneur, progression, conservation  | slice-local                      |
| 2   | `StepIndicator`                | Savoir où l'on est et ce qui est fait | design-system §2.1 `WizardSteps` |
| 3   | `ViewCard`                     | Aperçu de ce que la vue sera          | design-system §2.1               |
| 4   | `StateBadge`                   | `brouillon` — jamais `publié`         | design-system §2.1               |
| 5   | `Field` / `Input` / `Textarea` | Saisie du nom et de la description    | slice-local                      |
| 6   | `SaveState`                    | État de sauvegarde, visible et daté   | slice-local                      |
| 7   | `Button`                       | Annuler / Continuer                   | slice-local                      |

> **Aucun composant du design system n'est importé par chemin.** Tous résolvent par le registre
> (ADR-004) — voir `architecture.md` § « shadcn est le défaut, jamais une dépendance ».

---

## 4. States — les 9, sans exception

| État                         | Déclencheur                                             | Rendu                                                                                                                                                     | Feedback utilisateur                                                                                                |
| ---------------------------- | ------------------------------------------------------- | --------------------------------------------------------------------------------------------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------- |
| **Chargement**               | Ouverture, récupération d'un brouillon                  | `StepIndicator` visible, champs en `disabled` avec libellé « chargement »                                                                                 | Le squelette ne clignote pas sur les champs : ils sont là, simplement inactifs                                      |
| **Rempli**                   | Brouillon existant récupéré                             | Champs pré-remplis, `SaveState` daté, `StepIndicator` montre l'étape atteinte                                                                             | « Brouillon enregistré il y a 2 min »                                                                               |
| **Vide — jamais visité**     | Première ouverture, aucun brouillon                     | Champs vides, focus sur le nom, `Continuer` **désactivé**                                                                                                 | Le bouton désactivé **et** une ligne d'aide : « Indiquez un nom pour continuer »                                    |
| **Vide — aucune donnée**     | Sans objet ici                                          | —                                                                                                                                                         | Ce n'est pas un écran de lecture : il n'a pas d'état « aucune donnée ». Le dire vaut mieux que d'inventer une ligne |
| **Erreur de chargement**     | Récupération du brouillon impossible                    | Bandeau `status-error`, champs vides, bouton « Réessayer »                                                                                                | L'utilisateur peut recommencer sans perdre sa session                                                               |
| **Erreur de soumission**     | Nom déjà pris sur cette portée, ou service indisponible | Erreur **au niveau du champ**, pas en toast. `StatusBadge` du champ, message en `text-primary`                                                            | Le focus va au champ fautif. Un toast serait invisible au moment où l'on en a besoin                                |
| **Succès**                   | Passage à l'étape 2                                     | Aucun bandeau : l'**étape 2 est la confirmation**                                                                                                         | `StepIndicator` passe à l'étape 2 active                                                                            |
| **Hors-ligne / permissions** | Réseau perdu · `view:write` révoqué                     | Réseau : `SaveState` passe « sauvegarde en attente », saisie **reste manipulable** (`E18`). Droits : vue en lecture seule, champs désactivés, explication | `E18` : on ne perd pas une saisie valide. Pas de toast qui masquerait le message                                    |
| **Lecture seule**            | L'utilisateur a `view:read` mais pas `view:write`       | Formulaire entièrement désactivé, action principale remplacée par « Dupliquer pour modifier »                                                             | Proposition d'action, pas un mur (`B13`)                                                                            |

> `E12` (navigateur fermé pendant la saisie) n'a pas d'état d'écran : il a une **règle**. Le
> brouillon est persisté en continu, et au retour l'étape 1 propose « Reprendre le brouillon ».
> Un état ne peut pas représenter un événement survenu dans une session précédente.

---

## 5. Interactions

| Élément       | Événement | Comportement                                       | Feedback visuel                         | État résultant    | ID    |
| ------------- | --------- | -------------------------------------------------- | --------------------------------------- | ----------------- | ----- |
| Champ `Nom`   | `submit`  | Si non vide → étape 2 ; sinon rien                 | Le bouton reste désactivé, aide visible | inchangé          | `B1`  |
| Champ `Nom`   | `change`  | Sauvegarde différée du brouillon                   | `SaveState` passe « enregistrement… »   | sauvegardé        | `E12` |
| Toggle descr. | `toggle`  | Rend la description obligatoire dans **cette** vue | Le champ passe en `required`            | validation active | `B1`  |
| « Continuer » | `submit`  | Avance à l'étape 2, saisie conservée               | `StepIndicator` avance                  | étape 2           | `B16` |
| Étape visitée | `tap`     | Retour à l'étape, **saisie conservée**             | Étape marquée visitée, pas courante     | étape revisitée   | `B16` |
| `ViewCard`    | `tap`     | Aperçu du rendu en liste                           | Focus visible                           | —                 | `B1`  |
| « Annuler »   | `tap`     | Demande de confirmation si la saisie a changé      | Dialogue de confirmation                | liste             | `E12` |

- **Focus / clavier** : `Tab` suit l'ordre visuel (nom → description → toggle → actions) ; `Entrée`
  dans le nom équivaut à « Continuer » si valide ; `Échap` ferme le dialogue d'annulation, pas
  l'écran. Anneau de focus visible sur chaque contrôle.
- **Gestes** : aucun. Un glissement serait ambigu avec le retour arrière du navigateur.
- **Animations** : `duration-fast` (120ms) sur focus et survol ; `duration-normal` (200ms) sur
  l'apparition de la ligne d'aide. Aucune animation ne porte d'information (design-system §1.6).
- **Retour arrière** : le navigateur, pas l'écran. `B16` exige que la saisie survive au retour dans
  le tunnel **et** à la sortie de la page — donc persistance en continu, pas à la validation.

---

## 6. Responsive

| Breakpoint              | Comportement                                                                             | Ce qui se replie / disparaît                                                          |
| ----------------------- | ---------------------------------------------------------------------------------------- | ------------------------------------------------------------------------------------- |
| **Mobile** (<640px)     | Une colonne, `StepIndicator` réduit à « 1 / 3 » avec le libellé de l'étape               | `ViewCard` masqué — un aperçu sur mobile coûte un défilement pour une info secondaire |
| **Tablet** (640–1024px) | Une colonne centrée de 480px, aperçu visible sous le formulaire                          | rien                                                                                  |
| **Desktop** (>1024px)   | Deux colonnes : formulaire 480px à gauche, `ViewCard` + `StepIndicator` à droite, sticky | rien                                                                                  |

- **Cible tactile** : 44 × 44 px minimum. Sur cet écran, le champ `Nom` fait 40px de haut et le
  bouton **44px** : un champ de saisie à 44px devient lourd, un bouton à 40px devient imprécis.
- **Débordement** : le `StepIndicator` ne déborde jamais horizontalement — il passe à « 1 / 3 »
  avant 360px. Un titre de vue long s'écrase en `caption` dans la carte d'aperçu, il ne pousse
  rien.

---

## 7. Accessibilité

- [ ] Contraste ≥ 4.5:1 pour le texte courant (libellés en `text-secondary`)
- [ ] Contraste ≥ 3:1 pour les grands textes (titre de vue)
- [ ] Navigation clavier complète, ordre visuel respecté, `Entrée` sur le nom
- [ ] Focus visible sur chaque contrôle (anneau `--border-focus`, jamais supprimé)
- [ ] `aria-invalid` + `aria-describedby` sur le champ nom quand la description obligatoire est
      activée et le champ vide
- [ ] `role="group"` + `aria-label` sur le `StepIndicator`, avec `aria-current="step"` sur l'étape
      courante
- [ ] `SaveState` dans une région `aria-live="polite"` — une sauvegarde silencieuse est
      indiscernable d'une sauvegarde absente pour un non-voyant
- [ ] Message d'erreur relié au champ par `aria-describedby`, et non par un simple `if` — le message
      doit exister dans le DOM avant le focus, sinon le lecteur d'écran l'annonce trop tard
- [ ] Langue `fr`, direction de lecture LTR

---

## 8. Données

| Champ                    | Type       | Origine                                                   | Requis                             | Erreur possible                              |
| ------------------------ | ---------- | --------------------------------------------------------- | ---------------------------------- | -------------------------------------------- |
| `nom`                    | `string`   | brouillon local + API à la validation                     | oui (`B1`)                         | vide, ou collision sur la portée             |
| `description`            | `string?`  | idem                                                      | non, sauf si l'hôte l'exige (`B1`) | —                                            |
| `descriptionObligatoire` | `boolean`  | **configuration de l'hôte**, pas une valeur d'utilisateur | oui                                | l'hôte ne l'expose pas → le toggle disparaît |
| `permissions`            | `Action[]` | système d'autorisation de l'hôte                          | oui                                | `view:write` absent → lecture seule          |
| `brouillonId`            | `string`   | créé à l'ouverture, persisté                              | oui                                | —                                            |

- **Chargement** : un seul bloc, pas de pagination. Un formulaire ne pagine pas.
- **Cache / hors-ligne** : le brouillon est persisté en local à chaque modification, différé de
  quelques secondes. Il est la source de vérité pour la saisie ; l'API ne reçoit que sur
  « Continuer ». `E12`, `E18`.
- **Données sensibles** : aucune. `permissions` est lisible par l'utilisateur de toute façon, mais
  **n'est jamais journalisée** : elle décrit ce qu'il peut faire, pas ce qu'il a fait.

---

## 9. Traçabilité

| ID     | Origine | Manifestation sur cet écran                                                                                                                                         |
| ------ | ------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `B1`   | PRD     | Champ nom requis, description facultative sauf configuration de l'hôte                                                                                              |
| `B10b` | PRD     | Seul le propriétaire peut modifier ; un partageur **ne peut que dupliquer**. C'est l'origine de l'état « lecture seule » et de l'action « Dupliquer pour modifier » |
| `B16`  | PRD     | Un brouillon en cours de saisie n'est **jamais détruit** par un échec — d'où la persistance en continu, pas seulement à la validation                               |
| `B24`  | PRD     | Une version antérieure reste consultable et restaurable : le tunnel travaille sur un brouillon, il ne touche pas à la version publiée                               |
| `E9`   | PRD     | Publication refusée sans indicateur — **pas sur cet écran** : le refus intervient à l'étape 5, et l'étape 1 ne perd pas la saisie                                   |
| `E12`  | PRD     | Brouillon persisté en continu, « Reprendre le brouillon » au retour                                                                                                 |
| `E18`  | PRD     | Réseau perdu → `SaveState` « en attente », saisie manipulable                                                                                                       |

---

## 10. Checklist de gate

- [x] Les 9 états sont décrits avec un rendu concret
- [x] Chaque élément interactif a un comportement et un feedback
- [x] Le responsive est défini à chaque breakpoint du design system
- [x] La section Anti-générique est cochée et justifiée
- [x] Aucune valeur de design n'est laissée à « à définir »
- [x] Chaque ID `B*` / `E*` de l'écran apparaît en section 9
- [x] Aucun gabarit non résidu
- [x] L'écran reste cohérent avec le design system
- [x] **Test `[P]`** : les composants utilisés sont tous des capacités du registre, aucun chemin
      n'est importé. Un hôte sans DOM peut rendre cet écran.