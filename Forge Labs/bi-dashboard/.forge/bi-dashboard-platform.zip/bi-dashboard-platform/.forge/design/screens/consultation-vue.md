---
type: screen
slug: consultation-vue
title: Consulter une vue
module: views
status: approved
generated_at: 2026-09-29
derived_from: 
rule_ids: [B2, B9, B10b, B13, B14, B15, B18, B19, B21, B22, B23, B25, B30]
edge_case_ids: [E3, E4, E5, E6, E7, E15, E16, E17]
flow: null
---

# Écran — Consulter une vue

> **L'écran le plus utilisé du produit.** Toutes les autres heures d'un utilisateur de pilotage se
> passent ici. Il n'y a pas de mode « aperçu » : c'est la vue réelle, telle qu'elle est publiée.
>
> Une spécification d'écran qui n'est pas celle-ci décrit un produit où l'on _compose_. Celui-ci
> décrit un produit où l'on **regarde**. Les contraintes n'ont rien de commun.

---

## 1. Rôle de l'écran

|                          |                                                                                          |
| ------------------------ | ---------------------------------------------------------------------------------------- |
| **Archétype d'app**      | `dashboard` — l'archétype principal du produit                                           |
| **Module**               | `views` — rang 1 dans la navigation                                                      |
| **Route**                | `/views/{id}`                                                                            |
| **Type**                 | `page`                                                                                   |
| **Utilisateurs**         | tout lecteur ayant `view:read` — décideur, lecteur, et **l'auteur lui-même** (`B23`)     |
| **User stories servies** | `US-9`, `US-1`, `US-12`                                                                  |
| **Règles métier**        | `B2`, `B9`, `B10b`, `B13`, `B14`, `B15`, `B18`, `B19`, `B21`, `B22`, `B23`, `B25`, `B30` |
| **Edge cases**           | `E3`, `E4`, `E5`, `E6`, `E7`, `E15`, `E16`, `E17`                                        |

**Une phrase** : cet écran permet à un décideur de lire sa vue et d'ajuster ses paramètres, afin de
poser sa question sans demander un développement.

**Pourquoi au rang 1** : c'est le **usage le plus fréquent du produit** — 5/5. Il n'est pas premier
parce qu'il s'appelle « Accueil » : il est premier parce qu'il ouvre la boucle de travail. Voir
`benchmarks.md` § 1.

---

## 2. Direction visuelle de cet écran

|                               |                                                                                                                                                                      |
| ----------------------------- | -------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| **Mood**                      | dense, opérationnelle, digne de confiance                                                                                                                            |
| **Densité**                   | **dense**, sans réserve — c'est ici que la densité paie le plus : c'est l'écran où l'on **compare** des valeurs                                                      |
| **Niveau de contraste**       | **fort** sur les chiffres, moyen sur les métadonnées. Un chiffre doit être la chose la plus lisible de l'écran                                                       |
| **Surface**                   | `--surface` sur `--background`                                                                                                                                       |
| **Accent utilisé**            | `--primary` **uniquement** sur les éléments interactifs : un filtre actif, le focus. **Jamais** sur un statut — un statut en `primary` se confond avec une sélection |
| **Traitement photographique** | aucun                                                                                                                                                                |
| **Référence**                 | — c'est l'écran de référence                                                                                                                                         |

### 2.1 Anti-générique

- [x] Pas de fond blanc pur — `oklch(0.99 0.003 250)`
- [x] **Pas de carte ombrée pour tout** — une grille, pas une mosaïque. La bordure est le
      séparateur (design-system §1.5)
- [x] Pas d'uniformité — `metric` 1.5rem/500 contre `caption` 0.75rem : un rapport de 2, pas un
      espacement constant
- [x] Pas de gris générique — les neutres viennent des rôles `text-secondary` / `text-muted`
- [x] Pas de mise en page centrée — la grille occupe la largeur, alignée à gauche
- [x] Pas d'illustration
- [x] Un seul rapport d'échelle fait la hiérarchie

**Choix assumé et non neutre** : **la date de calcul de chaque indicateur est visible en permanence,
et pas seulement au survol.** Un tableau de bord dense montre trop de valeurs pour qu'un survol
puisse porter une information — ce qui a été survolé n'a jamais été lu. `B14` exige que le résultat
porte sa date et son état de fraîcheur ; le rendre permanent est la seule façon de tenir cela à une
densité réelle.

---

## 3. Anatomie

```
ViewHeader
├── Title                      nom de la vue
├── VersionBadge               version consultée + sélecteur de versions    B6
├── FreshnessStrip             date de calcul globale, en un seul endroit
├── ParamBar                   paramètres communs : période + filtres de l'auteur
│   ├── PeriodSelector         période, label « temporaire »
│   └── FilterChips × n        un par paramètre commun défini par l'auteur
├── ActiveFilterBar            filtres croisés actifs, avec retrait
│   └── ScopeNote              « ne s'applique pas à 3 indicateurs »
└── MetricGrid
    └── MetricCard × n
        ├── VariableName
        ├── Metric             valeur · unité · delta signé
        ├── CalculatedAt       date de calcul, TOUJOURS visible
        ├── StateBadge         fresh | stale | partial | error
        └── CrossFilterTarget  zone cliquable pour filtrer les autres
```

| #   | Composant                      | Rôle                                                             | Source                     |
| --- | ------------------------------ | ---------------------------------------------------------------- | -------------------------- |
| 1   | `MetricGrid`, `Metric`         | La grille d'indicateurs                                          | design-system §2.1         |
| 2   | `StateBadge`                   | Fraîcheur, troncature, échec                                     | design-system §2.1         |
| 3   | `PeriodSelector`               | Période commune                                                  | design-system §2.1         |
| 4   | `FilterChips`                  | Paramètres communs de l'auteur + filtres croisés                 | design-system §2.1         |
| 5   | `RefusalNotice`                | **Refus d'accès**, et non erreur                                 | design-system §2.1         |
| 6   | `VersionBadge`                 | Version consultée                                                | slice-local                |
| 7   | `FreshnessStrip`               | Date de calcul globale                                           | slice-local                |
| 8   | `CalculatedAt`                 | Date **par indicateur**, permanente                              | slice-local                |
| 9   | `CrossFilterTarget`            | Cible cliquable d'une valeur, `B30`                              | slice-local                |
| 10  | `ActiveFilterBar`, `ScopeNote` | Filtres actifs et leur périmètre, `E17`                          | slice-local                |
| 11  | `ValueTable`                   | **Tableau de valeurs d'un graphique** — jamais un graphique seul | design-system §2.1 (`B18`) |

> **`ValueTable` n'est pas optionnel.** `B18` exige qu'un graphique ait un nom accessible, un résumé et
> un **tableau de valeurs**. Un graphique sans tableau est une information inaccessible et
> inexploitable. Le tableau est donc un panneau de la même grille, pas une annexe.

---

## 4. States — les 9, sans exception

| État                         | Déclencheur                                                                                | Rendu                                                                                                                                                                                                                                                                 | Feedback utilisateur                                                                                                                                    |
| ---------------------------- | ------------------------------------------------------------------------------------------ | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------- |
| **Chargement**               | Ouverture, changement de paramètre, filtre croisé                                          | Les valeurs **restent affichées** avec leur date et `status-stale` pendant le calcul. **Jamais** de squelette : un squelette ferait croire que la valeur n'a jamais existé                                                                                            | `B13` : un rafraîchissement produit un ensemble **cohérent**. On ne recharge jamais indicateur par indicateur — ce qui produirait un mélange incohérent |
| **Rempli**                   | Résultats reçus                                                                            | Grille complète, `FreshnessStrip` daté, `ScopeNote` si filtre partiel                                                                                                                                                                                                 | —                                                                                                                                                       |
| **Vide — jamais visité**     | Aucune vue partagée avec cet utilisateur                                                   | Message d'action : « Aucune vue ne vous a été partagée » + proposition d'en demander une                                                                                                                                                                              | Pas d'illustration. Un écran vide qui n'offre pas d'action est un écran bloqué                                                                          |
| **Vide — aucune donnée**     | Indicateurs présents, **aucune donnée sur la période** (`E5`)                              | Chaque `MetricCard` : « Aucune donnée sur la période active » + **proposition d'élargir la période** si c'est possible. La grille reste lisible                                                                                                                       | `E5` : le message nomme la période. Un « 0 » nu ferait croire à une absence de données dans la source                                                   |
| **Erreur de chargement**     | Service indisponible                                                                       | `RefusalNotice` en tête, valeurs **conservées** avec `stale` et leur date, « Réessayer »                                                                                                                                                                              | `B15` : l'échec d'un indicateur n'affecte pas les autres. Ici l'échec global non plus — on ne vide pas l'écran pour une panne                           |
| **Erreur de soumission**     | Sans objet                                                                                 | —                                                                                                                                                                                                                                                                     | Un écran de consultation n'a pas de soumission. Le dire vaut mieux qu'inventer une ligne                                                                |
| **Succès**                   | Résultats reçus                                                                            | Le changement est **visible par les dates** qui se mettent à jour                                                                                                                                                                                                     | Confirmation par la date, pas par un toast                                                                                                              |
| **Hors-ligne / permissions** | Réseau perdu · `view:read` révoqué en cours de session · variable devenue interdite (`E3`) | Hors-ligne : valeurs conservées, bandeau « dernière mise à jour {date} ». Droits : `RefusalNotice` expliquant ce qui n'est plus accessible, **sans révéler ce qui existe** si sa présence est sensible. `E3` : les nouveaux chargements cessent, l'interface explique | `B19` : jamais de nom de table, de champ technique, de code ni de secret dans le motif                                                                  |
| **Lecture seule**            | `view:read` sans `view:write`                                                              | La vue se consulte normalement. Seules les actions de modification sont absentes. Si l'utilisateur est **partageur** et non propriétaire (`B10b`), une action « Dupliquer pour modifier » est proposée                                                                | La lecture n'est pas un état dégradé : c'est un état normal. Un lecteur n'a pas à être traité en visitor                                                |

> **`E16` — version retirée en cours de consultation.** Si la version affichée est retirée pendant que
> l'utilisateur la regarde, l'écran **ne casse pas** : il bascule sur la version publiée la plus
> récente, affiche un bandeau non bloquant expliquant le changement, et l'utilisateur comprend que la
> vue a bougé sous ses yeux. Passer à un écran d'erreur serait faux : la vue existe toujours.

> **`E6` — troncature.** Le `MetricCard` passe en `status-partial` et affiche le **compte exact**
> (« 1 000 lignes sur 12 480 »). Un total calculé sur un résultat tronqué et présenté sans mention
> serait un **mensonge chiffré** : l'utilisateur prendrait la somme d'un échantillon pour un total.

> **`E7` — dépassement de durée.** Refus explicite et **proposition d'une alternative plus légère**
> (« réduire la période »). `B21` : les limites sont imposées par le service, elles ne sont pas
> négociables — l'interface ne propose donc pas de les contourner.

> **`E15` — sources en retard.** La vue entière passe en `status-partial` dans la `FreshnessStrip`, et
> **la partie manquante est identifiée** par indicateur : « 2 indicateurs sur 9 n'incluent pas la
> source du jour ». C'est ce niveau de détail qui rend la `partial` exploitable.

---

## 5. Interactions

| Élément                       | Événement | Comportement                                             | Feedback visuel                                                     | État résultant     | ID           |
| ----------------------------- | --------- | -------------------------------------------------------- | ------------------------------------------------------------------- | ------------------ | ------------ |
| `PeriodSelector`              | `change`  | Change la période, réexécute **tout** l'ensemble         | Valeurs en `stale` + leurs dates, puis mise à jour simultanée       | résultats nouveaux | `B13`        |
| `FilterChips` (auteur)        | `change`  | Change un paramètre commun défini par l'auteur           | `status-selected` ; `ScopeNote` nomme les indicateurs non concernés | filtrage partiel   | `E17`        |
| `CrossFilterTarget`           | `tap`     | **Filtre les autres indicateurs**, même vue              | `ActiveFilterBar` apparaît avec retrait en un geste                 | vue filtrée        | `B30`        |
| Retrait d'un filtre           | `tap`     | Retire, recalcule                                        | `ActiveFilterBar` se met à jour                                     | retour             | `B30`        |
| `VersionBadge`                | `tap`     | Ouvre les versions publiées de cette vue                 | Liste avec dates ; l'ancienne version reste consultable             | version choisie    | `B6`, `B24`  |
| « Dupliquer pour modifier »   | `tap`     | Crée une copie **indépendante**                          | Nouveau brouillon, aucun droit hérité de l'original                 | brouillon          | `B9`, `B10b` |
| Survole d'une valeur          | `hover`   | **N'affiche rien de nouveau** — la date est déjà visible | —                                                                   | inchangé           | `B14`        |
| Valeur sans filtre applicable | `tap`     | Aucune réaction, et **pas** de zone cliquable            | Pas de curseur trompeur                                             | inchangé           | `B30`        |

- **Focus / clavier** : toute la grille est atteignable au `Tab`, dans l'**ordre de la grille** — qui
  est l'ordre déclaré (`B26`), pas l'ordre du DOM. Un `MetricCard` cliquable est un `button`, pas
  une `div` avec un gestionnaire. `Échap` dans un `ActiveFilterBar` en focus **retire le dernier
  filtre ajouté** — un raccourci que l'utilisateur découvre et qui lui fait gagner le clic.
- **Gestes** : swipe latéral pour changer de période. Il ne doit **jamais** être le seul moyen — la
  même action est disponible au `PeriodSelector`, toujours.
- **Animations** : `duration-fast` sur les changements d'état d'une carte. **Les valeurs ne
  s'animent pas** et ne se comptent pas : sur une grille dense, une valeur qui défile masque les
  voisines. Aucune animation ne porte d'information (design-system §1.6).
- **Retour arrière** : si des filtres croisés sont actifs, le navigateur **revient en arrière dans
  l'historique de la vue**, pas vers une autre page. Un filtre croisé est un changement d'état de la
  vue, donc une entrée d'historique.

---

## 6. Responsive

| Breakpoint              | Comportement                                                                                                             | Ce qui se replie / disparaît                                                                                     |
| ----------------------- | ------------------------------------------------------------------------------------------------------------------------ | ---------------------------------------------------------------------------------------------------------------- |
| **Mobile** (<640px)     | Une colonne. `ParamBar` en deux lignes. `FreshnessStrip` réduite à la date globale, les dates **par indicateur restent** | Le sélecteur de versions devient une icône dans l'en-tête ; `ValueTable` passe sous le graphique, jamais masquée |
| **Tablet** (640–1024px) | 2 colonnes                                                                                                               | Unités sur la ligne de la date si la largeur manque                                                              |
| **Desktop** (>1024px)   | Grille 4–6 KPI puis détail, `ParamBar` sticky en haut                                                                    | rien                                                                                                             |

- **Cible tactile** : 44 × 44 px sur les `CrossFilterTarget`. **Une valeur filtrable a toute sa
  carte en zone tactile**, pas seulement le chiffre : viser un nombre à 24px est un échec d'usage.
  Une valeur **non** filtrable n'a aucun curseur — un curseur qui ne fait rien est pire que pas de
  curseur.
- **Débordement** : `ValueTable` défile **horizontalement dans son propre conteneur**, jamais la
  page. Une valeur ne déborde pas : elle se tronque avec un infobulle. `ActiveFilterBar` défile
  horizontalement s'il y a plus de trois filtres, avec un compteur « +2 ».

> **Le conflit densité / lisibilité, tranché ici.** Sur un écran étroit, dense et lisible entrent en
> concurrence. L'arbitrage retenu : on **ne sacrifie ni l'un ni l'autre** — on passe en une colonne
> et on accepte le défilement vertical. C'est la seule réponse qui ne dégrade pas l'information.
> Le défilement est un coût ; cacher un indicateur est une perte. Ce point était ouvert depuis la
> session 4 ; il est tranché ici, sur le seul écran où la question se pose vraiment.

---

## 7. Accessibilité

- [ ] Contraste ≥ 4.5:1 pour le texte courant, ≥ 3:1 pour les grands textes
- [ ] Navigation clavier complète sur toute la grille, dans l'ordre déclaré
- [ ] Focus visible ; sur un `CrossFilterTarget`, le focus est aussi un **niveau de contraste
      renforcé** — sans couleur, un focus ne se voit pas
- [ ] `aria-live="polite"` sur `FreshnessStrip` — un résultat qui change sans être annoncé est
      invisible pour un non-voyant
- [ ] `aria-live="assertive"` sur `RefusalNotice` : un refus doit être annoncé, pas seulement affiché
- [ ] Chaque `MetricCard` porte un `aria-label` complet : nom, valeur, **unité**, date de calcul,
      état de fraîcheur. L'unité et la date sont des informations, pas du décor
- [ ] `aria-pressed` sur un `CrossFilterTarget` déjà actif — l'état du filtre croisé est un état,
      pas un style
- [ ] Chaque graphique porte un **nom accessible, un résumé et son tableau de valeurs** (`B18`). Le
      tableau n'est pas une option : un graphique sans tableau est une information inaccessible
- [ ] `StateBadge` jamais par la couleur seule
- [ ] Langue `fr`, direction LTR

---

## 8. Données

| Champ             | Type         | Origine                                   | Requis | Erreur possible                         |
| ----------------- | ------------ | ----------------------------------------- | ------ | --------------------------------------- |
| `vue`             | `Vue`        | service, filtré par `view:read`           | oui    | vue retirée → `E16`                     |
| `versionCourante` | `Version`    | service                                   | oui    | retirée en cours de session → `E16`     |
| `resultats`       | `Resultat[]` | exécution réelle, `data:execute` + `B25`  | oui    | `E4`, `E6`, `E7`, `E15`                 |
| `periode`         | `Période`    | choix utilisateur                         | oui    | —                                       |
| `filtresCommuns`  | `Param[]`    | **définis par l'auteur**, nombre non figé | non    | n'affecte aucun indicateur → `E17`      |
| `filtreCroise`    | `Filtre?`    | clic sur une valeur                       | non    | `B30`                                   |
| `permissions`     | `Action[]`   | autorisation de l'hôte                    | oui    | `view:read` révoqué en cours de session |
| `versions`        | `Version[]`  | service                                   | oui    | —                                       |

- **Chargement** : un **bloc unique**, jamais indicateur par indicateur. `B13` impose un ensemble
  cohérent : charger l'un après l'autre produirait un mélange de périodes, ce que `B22` interdit.
  La granularité est un choix d'affichage, jamais une stratégie de chargement.
- **Cache / hors-ligne** : les résultats **ne sont pas mis en cache** hors ligne ; la dernière
  réponse connue reste affichée avec `stale` et sa date. Une valeur périmée présentée comme fraîche
  est **pire** qu'une absence de valeur : elle est fausse, tandis qu'une absence est seulement
  inconfortable.
- **Données sensibles** : ce que l'utilisateur voit est déjà filtré par les trois contrôles
  conjointifs (`B25`). Le journal d'exécution enregistre **qu'une** requête a été exécutée, jamais
  ce qu'elle a retourné (`B28`) : ni valeurs filtrées, ni lignes, ni périmètre. Aucun nom de table,
  champ technique, code ni secret n'apparaît dans l'interface, y compris dans un motif de refus
  (`B19`). Et un périmètre non déterminable produit un résultat **vide**, jamais un résultat complet.

---

## 9. Traçabilité

| ID     | Origine | Manifestation sur cet écran                                                                                                                                                         |
| ------ | ------- | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `B2`   | PRD     | Les indicateurs sont des **références** ; l'écran exécute, il n'interprète rien                                                                                                     |
| `B6`   | PRD     | `VersionBadge` : la version consultée est identifiée, et l'ancienne reste consultable                                                                                               |
| `B9`   | PRD     | « Dupliquer pour modifier » crée une vue **indépendante**, qui n'hérite d'aucun accès de l'original                                                                                 |
| `B10b` | PRD     | Un partageur ne peut que dupliquer — d'où l'action proposée au lieu d'une vue en lecture morte                                                                                      |
| `B13`  | PRD     | Un rafraîchissement produit un ensemble **cohérent** : un seul chargement, jamais indicateur par indicateur                                                                         |
| `B14`  | PRD     | Date de calcul et état de fraîcheur **permanents** sur chaque `MetricCard`, pas au survol                                                                                           |
| `B15`  | PRD     | L'échec d'un indicateur n'affecte ni l'affichage ni le chargement des autres — et l'échec global non plus                                                                           |
| `B17`  | PRD     | Le swipe de période a un équivalent au `PeriodSelector` — toute action a un équivalent clavier                                                                                      |
| `B18`  | PRD     | Chaque graphique a un nom accessible, un résumé et un **tableau de valeurs**                                                                                                        |
| `B19`  | PRD     | Aucun nom de table, champ technique, code ni secret — y compris dans un motif de refus                                                                                              |
| `B21`  | PRD     | Limite de taille, de durée ou de précision dépassée → **refus explicite** avec alternative plus légère                                                                              |
| `B22`  | PRD     | Deux résultats incohérents ne sont jamais mélangés : c'est pourquoi le chargement est en un bloc                                                                                    |
| `B23`  | PRD     | L'auteur voit exactement ce que voient ses lecteurs : même écran, mêmes restrictions, mêmes `StateBadge`                                                                            |
| `B24`  | PRD     | Une version antérieure reste consultable et sélectionnable                                                                                                                          |
| `B25`  | PRD     | Le contrôle s'applique à **tout** chemin vers les données — ici, la consommation elle-même                                                                                          |
| `B26`  | PRD     | L'ordre du `Tab` est l'**ordre déclaré** de la grille, pas l'ordre du DOM                                                                                                           |
| `B30`  | PRD     | Clic sur une valeur → filtre les **autres indicateurs**, même vue ; le filtre est appliqué côté service, sous les mêmes droits, et ne peut donc rien montrer de plus que mes droits |
| `E3`   | PRD     | Variable devenue interdite → les nouveaux chargements cessent, l'interface explique                                                                                                 |
| `E4`   | PRD     | Un indicateur échoue → son erreur, les autres restent lisibles, « Réessayer »                                                                                                       |
| `E5`   | PRD     | Aucune donnée sur la période → message **nommant la période**, avec proposition d'élargir                                                                                           |
| `E6`   | PRD     | Troncature signalée avec le **compte exact** — jamais un total silencieux sur un échantillon                                                                                        |
| `E7`   | PRD     | Dépassement de durée → refus explicite et alternative plus légère                                                                                                                   |
| `E15`  | PRD     | Sources en retard → la partie manquante est **identifiée par indicateur**                                                                                                           |
| `E16`  | PRD     | Version retirée en cours de consultation → bascule sur la plus récente, bandeau explicatif, pas d'écran cassé                                                                       |
| `E17`  | PRD     | Un paramètre commun qui n'affecte pas certains indicateurs → ils sont nommés « non filtrés »                                                                                        |

---

## 10. Checklist de gate

- [x] Les 9 états sont décrits avec un rendu concret
- [x] Chaque élément interactif a un comportement et un feedback
- [x] Le responsive est défini à chaque breakpoint
- [x] La section Anti-générique est cochée et justifiée
- [x] Aucune valeur de design n'est laissée à « à définir »
- [x] Chaque ID `B*` / `E*` de l'écran apparaît en section 9
- [x] Aucun gabarit non résidu
- [x] L'écran reste cohérent avec le design system
- [x] **Chaque `B*` a été comparé à sa définition dans le PRD, pas seulement à son existence** —
      c'est le contrôle que j'avais omis et qui avait laissé passer 8 fausses citations en session 5
- [x] **Test `[P]`** : grille, texte, badges, sélecteurs, cible de filtre — aucune notion de DOM.
      Un hôte sans DOM rend cet écran intégralement, ce qui est la démonstration que la V1.5 devra
      reproduire