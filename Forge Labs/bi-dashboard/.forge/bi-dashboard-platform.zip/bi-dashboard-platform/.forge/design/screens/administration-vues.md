---
type: screen
slug: administration-vues
title: "Administration des vues et journal d'exécution"
module: administration
status: approved
generated_at: 2026-09-29
derived_from: 
rule_ids: [B10, B10b, B28, B29, B31, B32, B33, B34, B35, B36]
edge_case_ids: [E8, E13, E16]
flow: null
---

# Écran — Administration des vues et journal d'exécution

> **Deux fonctions, deux droits, un seul écran.** C'est la conséquence directe d'ADR-006 et des
> règles `B31`–`B35` : désigner une vue par défaut relève de l'administration des vues ; consulter le
> journal relève de `journal:read`, qui **par défaut n'est pas** inclus.
>
> L'écran les présente côte à côte, et **c'est le produit qui les sépare** — pas l'administrateur.
> Quand les deux droits sont réunis (un projet à un seul administrateur, `B32`), les deux panneaux
> sont là sans configuration. Quand ils ne le sont pas, un des deux est **absent**, et son absence
> est expliquée.

---

## 1. Rôle de l'écran

|                          |                                                                                                    |
| ------------------------ | -------------------------------------------------------------------------------------------------- |
| **Archétype d'app**      | `admin_crud` (rattachement) + table de journal, en second rang de navigation                       |
| **Module**               | `administration` — rang 2 dans la navigation                                                       |
| **Route**                | `/admin`                                                                                           |
| **Type**                 | `page`, deux panneaux                                                                              |
| **Utilisateurs**         | administrateur de vues (`view:write` sur le périmètre) ; journal **seulement** avec `journal:read` |
| **User stories servies** | `US-11`                                                                                            |
| **Règles métier**        | `B10`, `B10b`, `B28`, `B29`, `B31`, `B32`, `B33`, `B34`, `B35`, `B36`                              |
| **Edge cases**           | `E8`, `E13`, `E16`                                                                                 |

**Une phrase** : cet écran permet à un administrateur de désigner des vues par défaut et de
consulter les journaux d'exécution, afin que chacun arrive sur l'analyse qui le concerne et qu'une
question d'exploitation obtienne une réponse.

**Pourquoi au rang 2** : fréquence **2/5** pour la plupart. Utile, mais mensuel. Le ranger sous
« Plus » serait excessif — c'est une fonction d'administration réelle, pas un réglage — et le mettre
au rang 1 ferait croire qu'il fait partie de la boucle quotidienne.

---

## 2. Direction visuelle de cet écran

|                               |                                                                                                |
| ----------------------------- | ---------------------------------------------------------------------------------------------- |
| **Mood**                      | dense, opérationnelle, **sobrie** — un journal d'exécution n'est pas un tableau de bord        |
| **Densité**                   | **dense** — journal et listes sont des tables                                                  |
| **Niveau de contraste**       | fort sur l'identifiant de l'événement, moyen sur les métadonnées                               |
| **Surface**                   | `--surface` sur `--background`                                                                 |
| **Accent utilisé**            | `--primary` sur les actions de rattachement. **Jamais** dans le journal, qui n'a aucune action |
| **Traitement photographique** | aucun                                                                                          |
| **Référence**                 | —                                                                                              |

### 2.1 Anti-générique

- [x] Pas de blanc pur
- [x] **Pas de carte par événement de journal.** Un journal se parcourt ; une mosaïque de cartes sur
      500 lignes serait inutilisable
- [x] Pas d'uniformité — identifiant en `text-primary`, horodatage en `caption`/`text-muted`
- [x] Pas de gris générique
- [x] Pas de centrage
- [x] Pas d'illustration
- [x] Un seul rapport d'échelle

**Choix assumé et non neutre** : **le journal ne montre aucun résultat, et l'interface l'assume
visuellement.** Pas de colonne « aperçu », pas de miniature, pas d'infobulle au survol. Un journal
qui laisse croire qu'on pourrait y voir les valeurs serait un piège, et l'infobulle est précisément
l'endroit où l'utilisateur irait chercher. `B28` n'est donc pas seulement une règle de service :
c'est une **décision de mise en page**.

---

## 3. Anatomie

```
AdminShell
├── Panel 1 — Vues par défaut              [si administration des vues]
│   ├── ProfileSelector            quel profil on administre
│   ├── ViewTable                  vues disponibles
│   │   └── DefaultRow × n
│   │       ├── ViewName
│   │       ├── OwnerName
│   │       └── DefaultToggle      désigner / retirer
│   └── ChangeLogNote              « chaque changement est tracé »
└── Panel 2 — Journal d'exécution        [si journal:read]
    ├── RetentionNotice            rétention du projet, fenêtre chaude
    ├── JournalFilters             qui · quand · quelle vue · succès/échec
    └── JournalTable
        └── JournalRow × n
            ├── ActorName          qui
            ├── Timestamp          quand
            ├── ViewName           sur quelle vue
            ├── OutcomeBadge       succès | échec        ← PAS de résultat
            └── ScopeNote          borné au périmètre du titulaire
```

| #   | Composant                    | Rôle                                           | Source             |
| --- | ---------------------------- | ---------------------------------------------- | ------------------ |
| 1   | `StateBadge`                 | `succès` / `échec` — et **jamais** un résultat | design-system §2.1 |
| 2   | `RefusalNotice`              | Absence du panneau journal, avec sa raison     | design-system §2.1 |
| 3   | `Toggle`                     | Désigner / retirer une vue par défaut          | slice-local        |
| 4   | `ProfileSelector`            | Quel profil on administre                      | slice-local        |
| 5   | `RetentionNotice`            | Rétention et fenêtre chaude du projet          | slice-local        |
| 6   | `JournalTable`, `JournalRow` | Le journal, en table dense                     | slice-local        |
| 7   | `ScopeNote`                  | Rappel permanent du périmètre borné            | slice-local        |

---

## 4. States — les 9, sans exception

| État                         | Déclencheur                                                         | Rendu                                                                                                                                                                    | Feedback utilisateur                                                                                              |
| ---------------------------- | ------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------ | ----------------------------------------------------------------------------------------------------------------- |
| **Chargement**               | Ouverture                                                           | Lignes squelette à hauteur fixe. Le `RetentionNotice` et le `ScopeNote` s'affichent **avant** les données : ce sont des faits permanents, pas un contenu à charger       | Un écran de journal qui masque sa rétention pendant le chargement laisse croire que tout est conservé             |
| **Rempli**                   | Chargé                                                              | Les deux panneaux, ou un seul selon les droits                                                                                                                           | —                                                                                                                 |
| **Vide — jamais visité**     | Aucun changement de vue par défaut · aucun événement sur la période | Panneau 1 : message d'action, pas de blâme. Panneau 2 : « Aucune exécution sur cette période », avec la période nommée                                                   | `E16` : un journal **vide** ne doit pas se lire comme un journal qui n'a jamais rien eu                           |
| **Vide — aucune donnée**     | Filtre du journal sans résultat                                     | « Aucun événement ne correspond à ce filtre », avec le filtre nommé et la période                                                                                        | Même exigence : un vide filtré ne doit pas être confondu avec un vide réel                                        |
| **Erreur de chargement**     | Service indisponible                                                | `RefusalNotice` par panneau, **l'autre panneau reste fonctionnel**                                                                                                       | Panneaux indépendants : l'administration des vues ne doit pas tomber parce que le journal est indisponible        |
| **Erreur de soumission**     | Le retrait d'une vue par défaut échoue                              | Erreur sur la ligne, la ligne **revient** à son état précédent                                                                                                           | Un `Toggle` qui reste basculé alors que l'opération a échoué est un état faux affiché comme vrai                  |
| **Succès**                   | Rattachement modifié · journal consulté                             | Panneau 1 : la ligne bascule. Panneau 2 : **aucune confirmation** — un journal se consulte, il ne se félicite pas                                                        | `B35` : la consultation est journalisée **dans** le journal, ce qui est visible sans le dire                      |
| **Hors-ligne / permissions** | Réseau perdu · droit révoqué en cours de session                    | Hors-ligne : rien n'est modifiable, la consultation locale du journal reste possible si elle est déjà chargée. Droits : le panneau concerné disparaît **avec son motif** | `B33`, `B34` : un panneau qui s'évanouit sans explication ressemble à une perte de fonction                       |
| **Lecture seule**            | `journal:read` sans administration des vues                         | Seul le panneau journal s'affiche, et un bandeau indique que le rattachement n'est pas accessible                                                                        | `B32` : si l'hôte a réuni les deux droits, les deux panneaux sont là. Sinon l'absence est **exprimée**, pas subie |

> **`E8` — un journal d'une application dont l'existence est sensible.** L'absence de droit ne doit
> pas répondre « cette application n'existe pas » si ne pas le dire serait un signal. Le socle ne
> connaît pas la sensibilité d'une ressource ; **l'hôte la déclare**, et l'interface répond alors
> uniformément. Le journal ne se dégrade jamais en « rien à afficher » silencieux.

> **`E13` — une cible d'audience ou un profil disparaît.** Le panneau journal signale un périmètre
> invalide au lieu d'échouer en silence ; un rattachement vers un profil inexistant est signalé, et
> jamais interpreté comme « aucun rattachement ».

---

## 5. Interactions

| Élément                 | Événement                | Comportement                                                               | Feedback visuel                                                              | État résultant        | ID     |
| ----------------------- | ------------------------ | -------------------------------------------------------------------------- | ---------------------------------------------------------------------------- | --------------------- | ------ |
| `ProfileSelector`       | `change`                 | Change le profil administré                                                | Panneau 1 rechargé                                                           | autre périmètre       | `B10`  |
| `DefaultToggle`         | `tap`                    | Désigne ou retire une vue par défaut                                       | Bascule immédiate, **retour à l'état précédent** si échec                    | rattachement          | `B10`  |
| `DefaultToggle`         | `tap` (membre du profil) | **Ne bascule pas.** L'action est « Dupliquer »                             | `RefusalNotice` : un membre ne modifie pas la vue par défaut, il la duplique | inchangé              | `B10b` |
| `JournalFilters`        | `change`                 | Filtre le journal : qui, quand, vue, issue                                 | Compteur d'événements                                                        | filtré                | `B29`  |
| `JournalRow`            | `tap`                    | Ouvre le **détail de l'événement** : identifiant, action normalisée, durée | —                                                                            | détail                | `B28`  |
| Consultation du journal | `auto`                   | Est elle-même journalisée                                                  | Visible dans le journal au prochain rafraîchissement                         | —                     | `B35`  |
| Hors fenêtre chaude     | `tap`                    | Demande une **restauration explicite**                                     | Message indiquant la période couverte et la demande                          | restauration demandée | `B29`  |

- **Focus / clavier** : `DefaultToggle` est une `checkbox` avec `aria-checked`, atteignable au `Tab`.
  La consultation d'un journal est une **lecture** : elle ne doit pas déclencher de modification par
  la seule navigation au clavier.
- **Gestes** : aucun. Le journal se parcourt, il ne se balaye pas.
- **Animations** : `duration-fast` sur la bascule du `Toggle`. **Le journal ne s'anime pas** : un
  journal qui défile donne l'impression que les événements arrivent, alors qu'ils sont figés.
- **Retour arrière** : le navigateur. Les filtres du journal sont **dans l'URL** : un fil de
  « qui a consulté la vue X la semaine dernière » doit pouvoir être transmis.

---

## 6. Responsive

| Breakpoint              | Comportement                                      | Ce qui se replie / disparaît                                                             |
| ----------------------- | ------------------------------------------------- | ---------------------------------------------------------------------------------------- |
| **Mobile** (<640px)     | Panneaux empilés, journal en liste compacte       | La colonne « qui » devient une initiale + nom abrégé ; la rétention passe sous le filtre |
| **Tablet** (640–1024px) | Panneaux empilés, journal en table 4 colonnes     | Colonne « sur quelle vue » tronquée                                                      |
| **Desktop** (>1024px)   | Deux panneaux côte à côte, journal paginé par 100 | rien                                                                                     |

- **Cible tactile** : 44 × 44 px sur les `Toggle` et les filtres.
- **Débordement** : **jamais** de débordement horizontal sur le journal. Un horodatage ISO complet
  ne se tronque pas : il passe en format localisé court, la valeur exacte restant en `title` et dans
  le détail de l'événement.

---

## 7. Accessibilité

- [ ] Contraste ≥ 4.5:1 courant, ≥ 3:1 grands textes
- [ ] Navigation clavier complète sur les deux panneaux
- [ ] Focus visible
- [ ] `aria-checked` sur chaque `DefaultToggle`, avec le nom de la vue dans son `aria-label`
- [ ] `aria-live="polite"` sur le compteur d'événements filtrés
- [ ] `aria-live="polite"` sur la confirmation de rattachement : c'est un changement d'état
- [ ] `StateBadge` jamais par la couleur seule
- [ ] `RetentionNotice` dans une région non interactive lue au début : `aria-describedby` sur le
      filtre de période, pour qu'un lecteur d'écran sache **ce qui est conservé** avant de filtrer
- [ ] Le journal est une **tableau sémantique** avec `caption` et en-têtes de colonnes : il est lu,
      pas décoré
- [ ] `B28` ne s'applique pas qu'aux données : l'écran ne propose **aucune** action qui.révèle un
      résultat, donc aucune donnée n'est dans le DOM, pour personne
- [ ] Langue `fr`, direction LTR

---

## 8. Données

| Champ           | Type                                      | Origine                                | Requis | Erreur possible                        |
| --------------- | ----------------------------------------- | -------------------------------------- | ------ | -------------------------------------- |
| `profils`       | `Profil[]`                                | autorisation de l'hôte                 | oui    | profil supprimé → `E13`                |
| `vuesParDefaut` | `Vue[]` par profil                        | service                                | non    | —                                      |
| `permissions`   | `Action[]`                                | autorisation de l'hôte                 | oui    | `journal:read` absent → panneau absent |
| `journal`       | `Evenement[]`                             | service, journal **en écriture seule** | non    | indisponible, ou hors fenêtre chaude   |
| `retention`     | `{ conservationMois, fenetreChaudeMois }` | **configuration de l'hôte** (`B29`)    | oui    | —                                      |
| `scope`         | `Périmètre`                               | borne du titulaire (`B34`)             | oui    | jamais élargi silencieusement          |

- **Chargement** : le journal par pages de 100. Un journal n'a pas de « fin » : le dire
  (« 100 sur 1 284 sur la période ») est une information ; un défilement infini qui ne dit pas où
  l'on est, non.
- **Cache / hors-ligne** : **aucun cache du journal.** Un journal mis en cache est un journal
  potentiellement périmé sur des événements de sécurité, et il n'est pas modifiable — donc pas
  invalidable. Le journal se relit à chaque consultation.
- **Données sensibles** : c'est la donnée la plus sensible de l'écran, et la règle est stricte :
  **ni valeurs filtrées, ni lignes retournées, ni périmètre, ni donnée sensible** (`B28`). Un
  journal ne montre **qu'une** requête a été exécutée — qui, quand, sur quelle vue, et si elle a
  réussi ou échoué. La **consultation** du journal est elle-même journalisée (`B35`) : un
  administrateur qui lit un journal apparaît dans ce journal. Aucun nom de table, champ technique,
  code ni secret (`B19`).

---

## 9. Traçabilité

| ID     | Origine | Manifestation sur cet écran                                                                                                                                                                    |
| ------ | ------- | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `B10`  | PRD     | Désigner une vue par défaut est un **changement de rattachement** : le journal et la vue ne sont pas modifiés                                                                                  |
| `B10b` | PRD     | Un membre du profil ne peut pas modifier la vue par défaut, **seulement la dupliquer** — l'action proposée est donc « Dupliquer », pas un `Toggle` désactivé                                   |
| `B28`  | PRD     | Le journal montre **qu'une** requête a été exécutée, **jamais** ce qu'elle a retourné. Aucun aperçu, aucune infobulle, aucune miniature — la contrainte est aussi une décision de mise en page |
| `B29`  | PRD     | Rétention affichée en permanence (12 mois conservés, 3 en fenêtre chaude par défaut). Hors fenêtre chaude : **restauration explicite**                                                         |
| `B31`  | PRD     | `journal:read` est une action **distincte**, déléguable séparément                                                                                                                             |
| `B32`  | PRD     | Un hôte peut réunir les deux droits : les deux panneaux sont alors présents, sans configuration ni contournement                                                                               |
| `B33`  | PRD     | **Par défaut**, les deux sont distincts : un administrateur d'application ne lit pas le journal d'une autre application                                                                        |
| `B34`  | PRD     | La portée est **bornée au périmètre du titulaire**, rappelé par un `ScopeNote` permanent. L'élargir exige un autre droit, pas une option d'interface                                           |
| `B35`  | PRD     | La consultation est **elle-même journalisée** : un administrateur qui lit un journal y apparaît                                                                                                |
| `B36`  | PRD     | Les trois opérations d'écriture forment une seule action `view:write` — donc le panneau apparaît d'un bloc, jamais en partie                                                                   |
| `E8`   | PRD     | L'absence de droit ne doit pas révéler l'existence d'une ressource si sa présence est sensible : la réponse est uniforme, l'hôte déclare la sensibilité                                        |
| `E13`  | PRD     | Profil ou audience disparu → périmètre invalide **signalé**, jamais interprété comme « aucun rattachement »                                                                                    |
| `E16`  | PRD     | Entrée de journal vide → message nommant la période, avec restauration explicite hors fenêtre chaude : **un journal absent ne se lit jamais comme un journal qui n'a jamais rien eu**          |

---

## 10. Checklist de gate

- [x] Les 9 états sont décrits avec un rendu concret
- [x] Chaque élément interactif a un comportement et un feedback
- [x] Le responsive est défini à chaque breakpoint
- [x] La section Anti-générique est cochée et justifiée
- [x] Aucune valeur de design n'est laissée à « à définir »
- [x] Chaque ID `B*` / `E*` de l'écran apparaît en section 9
- [x] Aucun gabarit non résidu
- [x] L'écran reste cohérent avec le design system
- [x] Chaque `B*` comparé à sa **définition** dans le PRD
- [x] **Test `[P]`** : tables, badges, bascules, texte — aucune notion de DOM. Un hôte sans DOM rend
      cet écran ; et c'est l'écran où la séparation des droits (`B31`–`B35`) est **visible à
      l'écran**, donc vérifiable sans infrastructurer un audit