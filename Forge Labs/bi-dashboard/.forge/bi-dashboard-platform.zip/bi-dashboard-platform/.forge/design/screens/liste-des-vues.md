---
type: screen
slug: liste-des-vues
title: Liste des vues
module: views
status: approved
generated_at: 2026-09-29
derived_from: 
rule_ids: [B1, B9, B10, B10b, B14, B19, B23, B36]
edge_case_ids: [E10, E12, E16]
flow: null
---

# Écran — Liste des vues

> La porte d'entrée de la boucle quotidienne. Elle répond à une seule question : **qu'est-ce que je
> peux ouvrir, et qu'est-ce qui a changé depuis la dernière fois ?**

---

## 1. Rôle de l'écran

|                          |                                                       |
| ------------------------ | ----------------------------------------------------- |
| **Archétype d'app**      | `admin_crud` — liste dense, tri, filtre, recherche    |
| **Module**               | `views` — rang 1 dans la navigation                   |
| **Route**                | `/views`                                              |
| **Type**                 | `page`                                                |
| **Utilisateurs**         | tout utilisateur ayant au moins `view:read`           |
| **User stories servies** | `US-1`                                                |
| **Règles métier**        | `B1`, `B9`, `B10`, `B10b`, `B14`, `B19`, `B23`, `B36` |
| **Edge cases**           | `E10`, `E12`, `E16`                                   |

**Une phrase** : cet écran permet à un utilisateur de retrouver ses vues et de les ouvrir, afin de
voir ses chiffres sans manipulation préalable.

**Pourquoi au rang 1** : c'est la destination de la première entrée de navigation. Elle ouvre la
boucle, la consultation la poursuit.

---

## 2. Direction visuelle de cet écran

|                               |                                                                                                                                       |
| ----------------------------- | ------------------------------------------------------------------------------------------------------------------------------------- |
| **Mood**                      | dense, opérationnelle                                                                                                                 |
| **Densité**                   | **dense** — une liste, pas des cartes. C'est le deuxième écran où la densité paie : on compare des noms, des propriétaires, des dates |
| **Niveau de contraste**       | fort sur le nom de la vue, moyen sur les métadonnées                                                                                  |
| **Surface**                   | `--surface` sur `--background`                                                                                                        |
| **Accent utilisé**            | `--primary` sur la ligne survolée et le focus. **Jamais** sur un statut                                                               |
| **Traitement photographique** | aucun                                                                                                                                 |
| **Référence**                 | —                                                                                                                                     |

### 2.1 Anti-générique

- [x] Pas de blanc pur
- [x] **Pas de carte par vue.** Une mosaïque de cartes pour 40 vues serait illisible et impraticable :
      on ne compare pas une propriétaire et une date de mise à jour dans une grille de tuiles. **Table
      dense**, à bordures
- [x] Pas d'uniformité — nom en `text-primary`, métadonnées en `caption`/`text-muted`
- [x] Pas de gris générique
- [x] Pas de centrage — la table occupe la largeur
- [x] Pas d'illustration
- [x] Un seul rapport d'échelle

**Choix assumé et non neutre** : la **propriétaire et la dernière mise à jour sont dans la ligne**,
et non dans un panneau latéral ou un infobulle. Une liste sert à comparer ; ce qui est caché derrière
un survol ne se compare pas. C'est aussi ce qui permet de distinguer « mes vues » de « celles qu'on
m'a partagées » sans lire un groupe dans la barre latérale.

---

## 3. Anatomie

```
ViewsHeader
├── Title            "Mes vues"  + compteur
├── SearchInput      filtre texte : nom, description, propriétaire
├── FilterRow
│   ├── SegmentedControl   Toutes | Mes vues | Partagées | Par défaut
│   └── SortSelect         nom · description · propriétaire · mise à jour · statut
└── ViewTable
    └── ViewRow × n
        ├── ViewName        B1 : nom obligatoire
        ├── Description     facultative, B1
        ├── OwnerName       propriétaire, B10b
        ├── UpdatedAt       dernière mise à jour, B14
        ├── StateBadge      publié | brouillon | par défaut
        └── RowAction       Ouvrir · Dupliquer
```

| #   | Composant          | Rôle                                                     | Source             |
| --- | ------------------ | -------------------------------------------------------- | ------------------ |
| 1   | `ViewCard`         | Une ligne de vue, avec son état                          | design-system §2.1 |
| 2   | `StateBadge`       | `brouillon` / `publié` / `par défaut`                    | design-system §2.1 |
| 3   | `SearchInput`      | Filtrer                                                  | slice-local        |
| 4   | `SegmentedControl` | Filtres d'appartenance                                   | slice-local        |
| 5   | `SortSelect`       | Les 5 tris exigés                                        | slice-local        |
| 6   | `ViewTable`        | La table dense, structure porteuse de l'ordre de lecture | slice-local        |

> La ligne porte **tout** ce dont `US-1` a besoin, sans qu'aucune métadonnée soit accessible
> uniquement au survol ni par un panneau. Un panneau latéral serait un second endroit où chercher.

---

## 4. States — les 9, sans exception

| État                         | Déclencheur                        | Rendu                                                                                                                                                         | Feedback utilisateur                                                                                                            |
| ---------------------------- | ---------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------- |
| **Chargement**               | Ouverture de la liste              | Lignes squelette à **hauteur et largeur fixes**, sans texte                                                                                                   | `E12` : le filtre saisi est conservé et **réappliqué** au retour, jamais perdu                                                  |
| **Rempli**                   | Liste chargée                      | Table dense, tri appliqué, compteur « 24 vues »                                                                                                               | —                                                                                                                               |
| **Vide — jamais visité**     | Aucune vue accessible              | Message **nommant les trois actions possibles** : « Aucune vue pour le moment. Demandez-en une, ou créez la vôtre si vous avez le droit »                     | `B36` : si `view:write` est absent, le bouton « Créer » **n'est pas** proposé. Un CTA impossible est un mensonge                |
| **Vide — aucune donnée**     | Filtre ou recherche sans résultat  | Message **nommant le filtre** : « Aucune vue ne correspond à « {recherche} » » + « Effacer la recherche »                                                     | Ne jamais montrer un vide générique alors qu'un filtre est actif : l'utilisateur croit avoir perdu ses vues                     |
| **Erreur de chargement**     | Service indisponible               | `RefusalNotice` en tête, liste **conservée** si elle existait, « Réessayer »                                                                                  | On ne vide pas une liste pour une panne de service                                                                              |
| **Erreur de soumission**     | `Dupliquer` échoue                 | Erreur au niveau de la ligne concernée                                                                                                                        | La liste n'est pas reconstruite : une erreur sur une ligne ne doit pas faire clignoter les 24 autres                            |
| **Succès**                   | `Ouvrir`                           | Navigation vers la vue                                                                                                                                        | Aucun toast : la vue est la confirmation                                                                                        |
| **Hors-ligne / permissions** | Réseau perdu · `view:read` révoqué | Hors-ligne : liste en cache avec bandeau « dernière mise à jour {date} ». Droits : la liste se **réduit** à ce qui est encore accessible, et l'écran explique | `B23` : la réduction doit être **expliquée**, pas silencieuse — une vue qui disparaît sans mot ressemble à une perte de données |
| **Lecture seule**            | `view:read` seul                   | Liste complète. Ni « Créer », ni actions d'édition. `Dupliquer` reste **présent** si l'utilisateur a `view:write` sur une vue dupliquée                       | `B10b` : un partageur ne peut **que dupliquer**. C'est une action, pas une absence d'action                                     |

> **`E10` — deux vues portent le même nom.** Autorisé (`B1` n'impose pas d'unicité), donc la ligne
> doit **désambiguïser** : la propriétaire et la date de mise à jour sont dans la ligne précisément
> pour que deux « Synthèse mensuelle » soient distinguables. Si les deux lignes sont identiques sur
> tous les champs affichés, un discriminant supplémentaire est ajouté — jamais de renumérotation
> automatique du nom, qui mentirait sur le contenu.

> **`E16` — la version publiée d'une vue disparaît entre deux ouvertures de la liste.** La ligne
> passe en `StateBadge` « retraitée », la vue reste listable et la consultation expliquera le
> basculement. La retirer de la liste ferait croire à une suppression.

---

## 5. Interactions

| Élément            | Événement      | Comportement                                                                                        | Feedback visuel                            | État résultant | ID           |
| ------------------ | -------------- | --------------------------------------------------------------------------------------------------- | ------------------------------------------ | -------------- | ------------ |
| `SearchInput`      | `type`         | Filtre sur nom, description, propriétaire                                                           | Compteur « 6 sur 24 », lignes réduites     | filtré         | `US-1`       |
| `SegmentedControl` | `tap`          | Filtre d'appartenance                                                                               | Segment actif en `status-selected`         | filtré         | `B10`        |
| `SortSelect`       | `change`       | Trie par nom, description, propriétaire, mise à jour ou statut                                      | Indication de direction sur la colonne     | trié           | `US-1`       |
| Ligne              | `click`        | Ouvre la vue                                                                                        | Navigation                                 | consultation   | —            |
| Ligne              | `Entrée`       | Ouvre la vue — la ligne est un `link`, pas une `div`                                                | Navigation                                 | consultation   | `B17`        |
| `Dupliquer`        | `tap`          | Crée une copie **indépendante**, sans accès hérité                                                  | Nouveau brouillon, toast nommant la source | brouillon créé | `B9`, `B10b` |
| `CreateButton`     | `tap`          | → wizard étape 1                                                                                    | —                                          | création       | `B11`        |
| Row                | `context menu` | Aucun — le menu contextuel est le modèle « dense » par défaut et il est **inaccessible au clavier** | —                                          | —              | `B17`        |

- **Focus / clavier** : chaque ligne est un `link` ; `Tab` parcourt les lignes, `Entrée` ouvre.
  Le menu contextuel est **remplacé** par des actions visibles en fin de ligne, qui apparaissent au
  focus clavier comme au survol. Un panneau qui n'apparaît qu'au survol souris est inaccessible à
  qui n'a pas de souris.
- **Gestes** : aucun. Le balayage horizontal sur une liste est ambigu avec le retour arrière.
- **Animations** : `duration-fast` sur le survol d'une ligne. Le **tri ne s'anime pas** : réordonner
  24 lignes en les faisant glisser dirait « ceci bouge » alors que seule la position a changé.
- **Retour arrière** : le navigateur. Le filtre et le tri sont dans l'URL, donc un lien vers cette
  liste est partageable tel quel.

---

## 6. Responsive

| Breakpoint              | Comportement                                                                                                                   | Ce qui se replie / disparaît                                       |
| ----------------------- | ------------------------------------------------------------------------------------------------------------------------------ | ------------------------------------------------------------------ |
| **Mobile** (<640px)     | **Une colonne, liste empilée** — pas une table à défilement horizontal. Chaque ligne devient un bloc : nom, propriétaire, date | Description, `StateBadge` : le statut passe en pastille sur le nom |
| **Tablet** (640–1024px) | Table, colonne `Description` masquée                                                                                           | Actions de ligne en icône unique ouvrant une feuille               |
| **Desktop** (>1024px)   | Table complète 5 colonnes + actions                                                                                            | rien                                                               |

- **Cible tactile** : 44 × 44 px sur la zone cliquable de la ligne et sur chaque action.
- **Débordement** : un nom de vue long est **tronqué en fin de ligne**, jamais en débordement
  horizontal. `Description` tronquée à une ligne. Le tri et le filtre ne débordent pas : `FilterRow`
  passe sur deux lignes sous 360px.

> **La table ne défile pas horizontalement sur mobile.** Une table BI qui exige un défilement
> horizontal sur téléphone n'est pas une table dense : c'est un document mal présenté. D'où le
> passage en liste empilée, qui reste dense — la densité est le nombre d'informations par regard,
> pas la présence de colonnes.

---

## 7. Accessibilité

- [ ] Contraste ≥ 4.5:1 courant, ≥ 3:1 grands textes
- [ ] Navigation clavier complète, `Tab` sur les lignes, `Entrée` pour ouvrir
- [ ] Focus visible ; les actions de ligne apparaissent **au focus comme au survol**
- [ ] `aria-sort` sur la colonne triée, `aria-label` sur chaque en-tête de colonne
- [ ] `aria-live="polite"` sur le compteur « 6 sur 24 » — un filtre silencieux est un filtre dont
      l'utilisateur ignore l'effet
- [ ] `SegmentedControl` en `role="tablist"` ou groupe de boutons avec `aria-pressed`
- [ ] `StateBadge` jamais par la couleur seule : le texte accompagne toujours
- [ ] `E10` : quand deux lignes portent le même nom, chacune porte un `aria-label` distinct
      (« Synthèse mensuelle, proposée par X, mise à jour le … ») — sinon deux liens identiques
      sont indistinguables au lecteur d'écran
- [ ] Langue `fr`, direction LTR

---

## 8. Données

| Champ           | Type                | Origine                               | Requis | Erreur possible                            |
| --------------- | ------------------- | ------------------------------------- | ------ | ------------------------------------------ |
| `vues`          | `Vue[]`             | service, filtré par `view:read`       | oui    | service indisponible                       |
| `profil`        | `Profil`            | autorisation de l'hôte                | oui    | —                                          |
| `permissions`   | `Action[]`          | autorisation de l'hôte                | oui    | `view:write` absent → pas de CTA « Créer » |
| `vuesParDefaut` | `Vue[]`             | rattachement de profil (`B10`)        | non    | —                                          |
| `tri`           | `Champ` + direction | **URL**, donc partageable             | oui    | —                                          |
| `filtreTexte`   | `string`            | **URL**, donc partageable et restauré | non    | —                                          |

- **Chargement** : la liste **entière** en un bloc. Une liste de vues se parcourt, elle ne se pagine
  pas : un compteur « 24 vues » sur 24 lignes est une information, un paginateur ne l'est pas.
- **Cache / hors-ligne** : la **liste** est mise en cache — c'est de la métadonnée, pas de la donnée,
  et un cache de valeurs serait lui-même une fuite. Les valeurs ne le sont pas : la consultation
  réexécute. Bandeau « dernière mise à jour {date} » dès que le cache sert.
- **Données sensibles** : une vue **partagée** n'expose que ce que le partage a autorisé
  (`B7` ne confère aucun droit d'accès aux données supplémentaire). La liste ne montre ni nom de
  champ technique, ni code, ni secret (`B19`) — y compris dans une description rédigée par un
  auteur, qui est du contenu utilisateur traité comme non fiable. Le propriétaire est affiché parce
  qu'il est nécessaire à `E10` ; ce n'est pas une donnée métier.

---

## 9. Traçabilité

| ID     | Origine | Manifestation sur cet écran                                                                                                          |
| ------ | ------- | ------------------------------------------------------------------------------------------------------------------------------------ |
| `B1`   | PRD     | Le nom est obligatoire ; la description est **facultative** et n'occupe jamais une colonne obligatoire                               |
| `B9`   | PRD     | `Dupliquer` crée une vue **indépendante** qui n'hérite d'aucun accès de l'original                                                   |
| `B10`  | PRD     | Un changement de vue par défaut est un **changement de rattachement** : le segment « Par défaut » filtre, il ne modifie rien         |
| `B10b` | PRD     | Seul le propriétaire modifie ; un partageur **ne peut que dupliquer** — d'où `Dupliquer` toujours disponible, et l'absence d'édition |
| `B14`  | PRD     | La dernière mise à jour est **dans la ligne**, pas au survol : à cette densité, un survol ne porte pas d'information                 |
| `B17`  | PRD     | Le menu contextuel — le modèle « dense » par défaut — est **remplacé** par des actions au focus clavier                              |
| `B19`  | PRD     | Aucun nom de table, champ technique, code ni secret — la description est du contenu utilisateur non fiable                           |
| `B23`  | PRD     | La liste ne montre que ce que l'utilisateur peut **consulter**. Une réduction de droits est expliquée, jamais silencieuse            |
| `B36`  | PRD     | Le bouton « Créer » n'apparaît que si `view:write` existe : les trois opérations d'écriture sont **une** action                      |
| `E10`  | PRD     | Deux vues de même nom sont autorisées et **désambiguïsées** par propriétaire et date, jamais renumérotées                            |
| `E12`  | PRD     | Filtre et recherche sont dans l'**URL** : un lien vers cette liste est partageable, et le filtre survit au retour                    |
| `E16`  | PRD     | Version retirée → la ligne passe « retraitée », reste listable ; retirer la ligne ferait croire à une suppression                    |

---

## 10. Checklist de gate

- [x] Les 9 états sont décrits avec un rendu concret
- [x] Chaque élément interactif a un comportement et un feedback
- [x] Le responsive est défini à chaque breakpoint
- [x] La section Anti-générique est cochée et justifiée
- [x] Aucune valeur de design n'est laissée à « à définir »
- [x] Chaque ID `B*` / `E*` de l'écran apparaît en section 9
- [x] Aucun gabarit non résidu
- [x] L'écran reste cohérent avec le design system
- [x] Chaque `B*` comparé à sa **définition** dans le PRD
- [x] **Test `[P]`** : table dense, texte, badges, segments, actions — aucune notion de DOM