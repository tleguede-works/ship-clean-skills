---
type: architecture
status: draft
generated_at: 2026-09-29
derived_from: .forge/prd.md
---


# Architecture — Plateforme BI configurable

> Ce document définit **comment** le produit est structuré. Il transforme le PRD en modules,
> fondations, modèles et contrats.
>
> **Granularité** : toute entité, tout champ, tout contrat est documenté — pas résumé, pas
> échantillonné. Une architecture qu'on résume est une architecture qu'on invente à l'implémentation.

---

## 1. Vue d'ensemble

### 1.1 Stack technique

| Domaine             | Choix                               | Version      | Justification                                                                                  |
| ------------------- | ----------------------------------- | ------------ | ---------------------------------------------------------------------------------------------- |
| Langage             | TypeScript `strict`                 | ^5           | `no any`, `unknown` + gardes de type. Un socle dont le contrat est flou ne peut pas être testé |
| Framework (hôte)    | Next.js App Router                  | ^16.3        | Un des deux hôtes visés ; **adapter optionnel**, jamais dépendance du noyau                    |
| Base de données     | **Aucune imposée**                  | —            | `C1` — le package ne persiste rien. La persistance est un port implémenté par l'hôte           |
| ORM / query builder | **Aucun dans le noyau**             | —            | ADR-007 : adaptateur, pas dépendance. Un registre de moteurs est refusé                        |
| State management    | **Reducer pur dans `src/core`**     | ADR-010      | Le brouillon porte des règles, pas des états d'interface. Testable sans DOM                    |
| Validation          | Zod                                 | ^4.6         | Schémas runtime + types inférés + conversion JSON Schema pour l'outillage                      |
| HTTP client         | **Aucun dans le noyau**             | —            | `C1`, `C2` — le noyau ne fait aucun appel réseau ; il définit un port d'exécution              |
| Styling             | CSS custom properties + utilitaires | —            | Le thème passe par `:root` / `.dark`, donc le socle n'est lié à aucun moteur de style          |
| Composants UI       | **shadcn, défaut et remplaçable**   | ADR-005      | Distribution par copie de code, jamais une dépendance. Registre de capacités                   |
| Tests unitaires     | Vitest                              | ADR-011      | Couverture en **règles testées**, pas en lignes                                                |
| Tests de contrat    | Vitest + suite publiée par le socle | ADR-011      | Les trois contrôles (`NFR §7.2`) et `B25` ; un adaptateur d'hôte doit la passer                |
| Tests E2E           | Playwright                          | ^1.63        | Un spec par parcours de bout en bout                                                           |
| Lint / Format       | ESLint flat / Prettier              | ^9.39 / ^3.9 | Standards du projet, **pas** hérités de l'app de référence (ADR-008)                           |
| Package manager     | **bun**                             | ADR-008      | Un seul gestionnaire du développement à `bun pm pack`                                          |
| Runtime             | Node épinglé                        | ADR-008      | `.node-version`, lu par `fnm`                                                                  |

### 1.2 Structure de dossiers cible

```
bi-dashboard-platform/
├── .forge/                      pilotage (hors runtime)
├── .opencode/rules/             règles de comportement de l'agent
├── tooling/                     outillage dépôt (scan Unicode)
├── src/
│   ├── core/                    LE NOYAU — ni React, ni DOM, ni réseau
│   │   ├── config/              schéma de configuration versionné (ADR-003)
│   │   ├── disposition/         présentation : layout, colonnes (ADR-014)
│   │   ├── draft/               reducer de brouillon, PUR (ADR-010)
│   │   ├── query/               construction d'une spécification de requête
│   │   ├── catalog/             résolution des variables métier
│   │   ├── permissions/         vérification des ACTIONS, jamais des rôles (§ 4.1 PRD)
│   │   ├── journal/             format du journal expurgé (B28)
│   │   └── types/               contrats publics : ports, résultats, erreurs
│   ├── react/                   liant React, sans rendu imposé
│   │   ├── hooks/               useView, useDraft, useCrossFilter
│   │   └── context/             fournisseurs de ports
│   ├── ui/                      implémentation visuelle par défaut (shadcn)
│   │   ├── MetricGrid/  FilterChips/  StateBadge/  RefusalNotice/  PeriodSelector/
│   │   └── registry/            résolution par CAPACITÉ (ADR-005)
│   ├── next/                    adaptateur Next.js optionnel
│   └── (extensions hôte)         routes, server actions — chaque hôte ajoute les siennes
└── pilot/                       application de référence (ADR-001, ADR-006)
    ├── app/                     /views, /views/new, /views/new/metrics, /admin
    ├── adapters/                implémentations de référence des ports
    │   ├── InMemoryViewRepository.ts
    │   ├── StaticCatalogProvider.ts
    │   └── QueryCacheAdapter.ts  (TanStack Query — ici seulement)
    └── e2e/
```

> **`src/core` ne doit importer rien de ce qui est en dessous de lui.** Ni `react`, ni `ui`, ni
> `next`, ni `pilot`. C'est la frontière qui rend le noyau testable sans DOM (ADR-010) et
> réutilisable chez Elora (`C6`).

---

## 2. Fondations

| Fondation     | Responsabilité                                                        | Dépend de               | Dépendue par                    |
| ------------- | --------------------------------------------------------------------- | ----------------------- | ------------------------------- |
| `config`      | Schéma de la configuration d'une vue, versionné, sans code exécutable | —                       | `draft`, `query`, toutes slices |
| `disposition` | Présentation : layout, colonnes. Schéma strict et **fermé** (ADR-014) | —                       | `draft`                         |
| `permissions` | Vérification d'une **action** sur un sujet, jamais d'un rôle          | —                       | toutes slices                   |
| `query`       | Construction d'une spécification de requête à partir d'une config     | `config`                | consultation, aperçu            |
| `draft`       | Reducer du brouillon, **composition de `ViewDocument`** (ADR-014)     | `config`, `disposition` | wizard, `publication`           |
| `journal`     | Format du journal d'exécution, expurgé                                | —                       | administration                  |
| `ports`       | Déclarations des ports : exécution, catalogue, persistance, cache     | —                       | tout adaptateur d'hôte          |

### 2.1 `config` — le format d'une vue

> **Deux clés voisines, deux propriétaires, un compositeur** (ADR-014). Cette section décrit
> `config` **seule**. La présentation vit dans `disposition`, et `draft` compose les deux :
>
> ```ts
> type ViewDocument = { config: ViewConfig; disposition: Disposition };
> ```
>
> Ni `config` ni `disposition` n'importe l'autre. `draft` est **le seul** module qui connaît les
> deux, et il valide chaque partie avec le schéma de son propriétaire.
>
> **Pourquoi la racine reste fermée.** `.catchall` ou `.passthrough` rendrait négociable la garantie
> d'`ADR-003` — « aucun champ non déclaré n'entre dans une configuration » — qui est la propriété
> sur laquelle repose `B19`. Une garantie qu'un champ du schéma peut suspendre n'est plus une
> garantie. La frontière suit les règles : `B26` (ordre déclaré) est du **contenu**, le `layout` est
> du **rendu**, donc une évolution du rendu ne touche jamais le contenu.

**Ce que le format contient** — et c'est tout. Chaque champ est une **référence**, jamais une
définition de requête (ADR-003, `B2`).

| Champ               | Type             | Contrainte                                                                                                                                                                            |
| ------------------- | ---------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `version`           | `1`              | **Obligatoire**, propriétaire `config`. La migration appartient à la slice `format-migration`, qui naîtra avec un format v2 (ADR-014)                                                 |
| `id`                | `string`         | Stable, jamais réutilisé                                                                                                                                                              |
| `name`              | `string`         | Obligatoire (`B1`)                                                                                                                                                                    |
| `description`       | `string \| null` | Facultatif **par configuration de l'hôte** (`B1`, ADR-012)                                                                                                                            |
| `indicators`        | `Indicator[]`    | ≥ 1 pour publier (`B27`) ; référence stable, jamais une requête                                                                                                                       |
| `params`            | `Param[]`        | Nombre **non figé** (US-9) — période et filtres de l'auteur. `kind` est une **déclaration** (« période » / « filtre ») ; sa **sémantique d'exécution** appartient à `query` (ADR-014) |
| `indicators[].rank` | `number`         | Ordre **stable** (`B26`) ; le rang ne bouge pas au reflow                                                                                                                             |
| `audience`          | `Audience`       | Nominative **et** groupes (`B7`)                                                                                                                                                      |

**Ce que le format ne contient jamais** : du code exécutable, une expression, un secret, une URL
d'accès direct aux données, un nom de table, un nom de champ technique (`B3`, `B19`, `B25`).
L'absence est une **propriété du schéma**, vérifiable par un test, pas une recommandation.

**Migration** : une configuration de version antérieure est **lue** par le noyau, convertie en
memoire, et **réécrite** seulement à l'enregistrement. Un refus de migration doit nommer le champ et
la règle incompatibles — jamais `erreur de format`.

### 2.2 `ports` — les contrats

```ts
// L'ADAPTATEUR, jamais la dépendance (ADR-007).
type ExecutionAdapter = (input: {
  spec: QuerySpec; // construite par src/core/query, jamais par l'hôte
  identity: IdentityContext; // l'hôte résout le périmètre ; le noyau ne le calcule pas
  parameters: ParamValues;
}) => Promise<ExecutionOutcome>; // ADR-009 : l'issue, pas seulement les lignes
```

`QuerySpec` est construite par le noyau à partir de la configuration et des paramètres. **L'hôte ne
redige pas la requête** : il reçoit une spécification, il l'exécute. C'est ce qui rend `B2` tenable —
un indicateur est une référence, et une référence ne devient une requête qu'ici.

`ExecutionOutcome` rend `scopeState` et `totalRows` **même quand `rows` est vide** (ADR-009) : sans
cela, le noyau ne peut pas distinguer « aucune donnée sur la période » de « périmètre non résolu »,
et affiche le mauvais des deux messages.

### 2.3 `permissions` — des actions, pas des rôles

```ts
type Action =
  | "view:read"
  | "view:write"
  | "view:publish"
  | "view:share"
  | "view:set-default"
  | "data:execute"
  | "journal:read"
  | "export:create";
```

Le noyau vérifie des **actions**. Le mapping vers les droits réels est fait par l'hôte (`C2`). Un
`PermissionChecker` reçoit l'action et le sujet, jamais un rôle.

---

## 3. Modules

> **Les slices sont l'objet de la Phase 5.** Ce document fixe les **modules** et la frontière entre
> eux ; le découpage en unités de travail livrables vient ensuite, avec ses dépendances.

| Module           | Responsabilité                                                                  | US               | Règles                                         |
| ---------------- | ------------------------------------------------------------------------------- | ---------------- | ---------------------------------------------- |
| `config`         | Contenu : identité, indicateurs, paramètres, audience                           | US-2, US-5       | `B1`, `B2`, `B19`, `B26`, `B27`                |
| `disposition`    | Présentation : layout, colonnes (ADR-014)                                       | US-4             | `B17`, `B26`                                   |
| `catalog`        | Variables métier, droits d'accès sur chacune                                    | US-3, US-14      | `B3`, `B4`, `B12`, `B23`, `B25`                |
| `draft`          | Reducer du brouillon, **composition de `ViewDocument`**, cycle de vie (ADR-014) | US-2 → US-5      | `B5`, `B6`, `B10b`, `B12`, `B16`, `B24`, `B26` |
| `publication`    | Publication, partage, audience                                                  | US-5, US-7, US-8 | `B7`, `B8`, `B9`, `B13`                        |
| `consumption`    | Exécution d'une vue, fraîcheur, filtre croisé                                   | US-9             | `B14`, `B15`, `B18`, `B21`, `B22`, `B30`       |
| `administration` | Vues par défaut, journal d'exécution                                            | US-11            | `B10`, `B28` → `B35`                           |
| `integration`    | Détection et branchement chez un hôte                                           | US-10            | `B24`, ADR-006                                 |

**Frontières entre modules** : `consumption` ne connaît que `config` et `ports`. Il ne connaît ni
`draft`, ni `publication` — une vue publiée est un **fait**, pas un brouillon. Un module qui connaît
le brouillon d'une autre personne est un module qui peut l'altérer, et `B5` devient intenable.

---

## 4. Modèles de données

### 4.1 Entités du socle

| Entité         | Champs                                                                                    | Particularité                                                    |
| -------------- | ----------------------------------------------------------------------------------------- | ---------------------------------------------------------------- |
| `ViewConfig`   | `version`, `id`, `name`, `description`, `indicators`, `params`, `disposition`, `audience` | **Jamais** de requête ; références seules                        |
| `Indicator`    | `id`, `variableRef`, `aggregation`, `filters`, `rank`                                     | `variableRef` pointe le catalogue, jamais un champ brut (`B3`)   |
| `Param`        | `id`, `kind` (`period` \| `filter`), `default`, `appliesTo`                               | `appliesTo` vide = tous ; sinon certains (`E17`)                 |
| `Version`      | `id`, `configHash`, `publishedAt`, `retiredAt`                                            | `retiredAt` non nul = retirée (`E16`)                            |
| `JournalEvent` | `id`, `actorId`, `at`, `action`, `viewId`, `outcome`                                      | **Aucun résultat** (`B28`) — ni valeurs, ni lignes, ni périmètre |
| `AuditRead`    | `actorId`, `at`, `windowStart`, `windowEnd`, `scope`                                      | La **consultation** du journal est elle-même journalisée (`B35`) |

**Relations** : `ViewConfig 1—N Indicator` · `ViewConfig 1—N Version` ·
`ViewConfig 1—N Param` · `JournalEvent N—1 ViewConfig` (par `viewId`, jamais par cascade : un
journal ne se supprime pas avec une vue — `B28` le rend en écriture seule).

> **Aucune de ces entités n'est persistée par le socle** (`C1`). Le tableau décrit le **contrat**
> que tout hôte doit respecter, pas un schéma de base de données.

### 4.2 Ce que le noyau ne modélise pas

Les comptes, les groupes, les rôles, les identités : ils appartiennent à l'hôte (`C2`). Le noyau ne
reçoit qu'un `IdentityContext` opaque et ne le décompose jamais — un noyau qui connaît le modèle
d'identité d'un hôte est un noyau lié à cet hôte.

---

## 5. Contrats d'API

> **Le socle ne définit aucun endpoint.** C'est une bibliothèque, pas un service. Les endpoints
> appartiennent à l'hôte ; ce que le socle fixe, c'est ce qu'un endpoint **doit** garantir.

| Contrat imposé par le socle | Exigence                                                                                      |
| --------------------------- | --------------------------------------------------------------------------------------------- |
| Réponse d'exécution         | rend `scopeState` et `totalRows`, **même quand `rows` est vide** (ADR-009)                    |
| Périmètre non déterminable  | résultat **vide**, jamais un résultat complet (`NFR §7.2`) — pas une erreur                   |
| Limite dépassée             | refus **explicite** avec alternative plus légère (`B21`, `E7`) — jamais un total silencieux   |
| Troncature                  | `truncated: true` **et** `totalRows` exact (`E6`)                                             |
| Refus d'accès               | formulé en langage **métier**, sans code technique ni nom de champ (`B13`, `B19`)             |
| Absence de droit            | ne révèle pas l'existence de la ressource si sa présence est sensible (`E8`)                  |
| Journal                     | en écriture seule, jamais de résultat (`B28`), et la **consultation** est journalisée (`B35`) |

**Les codes d'erreur HTTP ne sont pas imposés** : ils dépendent du serveur de l'hôte. Ce qui est
imposé, c'est que le client puisse distinguer `erreur` de `refus` — `StateBadge` a deux rôles
séparés pour cette raison, et les confondre rendrait l'impossibilité de comprendre un refus
(`B13`).

---

## 6. Graphe de dépendances

### 6.1 Ordre d'implémentation

```
Vague 0 — fondations (aucune dépendance entre elles) :
  ├── config        contenu d'une vue        (B1, B2, B19, B26, B27)
  ├── disposition   présentation             (ADR-014)
  ├── permissions   actions, pas rôles       (C2, B31–B35)
  ├── journal       format expurgé           (B28)
  └── ports         déclarations             (ADR-007, ADR-009)

Vague 1 — dépend de la vague 0 :
  ├── query         spécification de requête  (dépend de config, ports)
  └── draft         reducer + COMPOSITION de ViewDocument (dépend de config, disposition)

Vague 2 — dépend de la vague 1 :
  ├── catalog      résolution des variables (dépend de query, ports)
  ├── consumption  exécution + fraîcheur     (dépend de query, ports, catalog)
  └── views-index  liste des vues           (dépend de catalog, permissions)

Vague 3 :
  ├── publication  publier / partager       (dépend de draft, permissions)
  └── administration  vues par défaut + journal (dépend de permissions, journal)
```

> **`draft` est le seul module qui connaît `config` ET `disposition`** (ADR-014). Il compose
> `{ config, disposition }` et valide chaque partie avec le schéma de son propriétaire. Aucun autre
> module n'importe les deux — c'est ce qui maintient les deux racines **fermées** sans rendre
> `ViewConfig` extensible.

**Aucun cycle.** `consumption` ne connaît pas `draft` ni `publication` : une vue publiée est un
fait. Si `consumption` devait lire le brouillon, `B5` (immuabilité) deviendrait intenable par
construction.

### 6.2 Parallélisme

| Vague | Parallélisable                                                      |
| ----- | ------------------------------------------------------------------- |
| 0     | `config`, `disposition`, `permissions`, `journal`, `ports` — **aucune dépendance entre elles** |
| 1     | `query` et `draft`                                                  |
| 2     | `catalog`, `consumption`, `views-index`                             |
| 3     | `publication` et `administration`                                   |

---

## 7. Décisions d'architecture

| ID          | Décision                                       | Choix                                                      | Conséquence principale                                                     |
| ----------- | ---------------------------------------------- | ---------------------------------------------------------- | -------------------------------------------------------------------------- |
| ADR-001     | Monolithe modulaire d'abord                    | `src/**` + `pilot/` ici                                    | Extraction en package seulement après deux consommateurs                   |
| ADR-002     | Le client n'est jamais la frontière            | Décision serveur, trois contrôles conjointifs              | `PermissionChecker` vérifie des **actions**                                |
| ADR-003     | Aucun code exécutable en configuration         | Références seules                                          | Le schéma est testable : l'absence est une propriété                       |
| ADR-005     | shadcn défaut, jamais dépendance               | Registre de capacités                                      | Un hôte sans DOM rend le parcours (`C6`)                                   |
| ADR-006     | `ace3i` est le pilote, exception documentaire  | `read_only: true` conservé                                 | Autorisation **réelle** pour éprouver les trois contrôles                  |
| ADR-007     | Moteur de requêtes = adaptateur                | Port, pas registre                                         | Une dépendance de moteur se découvre à l'intégration, donc trop tard       |
| ADR-008     | `bun`, Node épinglé                            | Un seul gestionnaire                                       | « Ce qui est testé » reste « ce qui est publié »                           |
| **ADR-009** | **Le port rend l'issue, pas les lignes**       | `scopeState` + `totalRows` toujours                        | `E5`/`E6` et la règle de périmètre deviennent implémentables dans le noyau |
| **ADR-010** | **Reducer de brouillon dans `src/core`**       | Fonction pure                                              | Les règles de business sont testables sans DOM                             |
| **ADR-011** | **Couverture en règles, pas en lignes**        | Chaque `B*` a un test cité                                 | Un seuil de lignes se choisit pour ne pas échouer                          |
| **ADR-012** | **Wizard contrôlé, sans bibliothèque**         | `ValidationResult` maison                                  | `B1` rend l'obligation **configurable à l'exécution**                      |
| **ADR-013** | **Le cache n'est pas l'autorité de fraîcheur** | Fraîcheur du service, cache mémoire, vidé à la déconnexion | `B14` ne peut pas être contredit par un cache                              |
| **ADR-014** | **`ViewConfig` est une clé voisine de `disposition`** | `ViewDocument = { config, disposition }`, deux racines fermées, `draft` compose | Une évolution du rendu ne touche jamais le contenu, et `ADR-003` reste une garantie et non une convention |

---

## 8. Risques architecturaux

| Risque                                                 | Prob.  | Impact | Mitigation                                                                                                                       |
| ------------------------------------------------------ | ------ | ------ | -------------------------------------------------------------------------------------------------------------------------------- |
| Le noyau glisse vers le web (import React)             | MOYEN  | ÉLEVÉ  | Frontière vérifiée **par une commande**, pas par intention. Test de la vague 0 sans DOM                                          |
| Un adaptateur d'hôte rend `rows` sans `scopeState`     | ÉLEVÉ  | ÉLEVÉ  | Le test de contrat (ADR-011) échoue sur un rendu vide. Un rendu vide sans `scopeState` est ** invalide**, pas accepté par défaut |
| La configuration gagne un champ exécutable             | FAIBLE | ÉLEVÉ  | Test de schéma : l'absence de code est une propriété vérifiée, pas une règle lue                                                 |
| Le port d'exécution devient un registre de moteurs     | MOYEN  | ÉLEVÉ  | ADR-007 : l'adaptateur est **un** port. Un second adaptateur n'est pas un registre                                               |
| Le cache survit à une déconnexion                      | MOYEN  | ÉLEVÉ  | ADR-013 règle 3 : vidé sans exception ni configuration                                                                           |
| `E6` non testé (taille jamais dépassée dans les tests) | ÉLEVÉ  | MOYEN  | ADR-011 règle 4 : test d'injection de faute, pas de chemin nominal                                                               |

---

## Checklist de gate

**Ce qui est vérifiable maintenant**

- [x] La stack cible est entièrement spécifiée (state ADR-010, cache ADR-013, formulaires ADR-012,
      tests ADR-011). Restent ouvertes : les **commandes**, re-datées en Phase 5
- [x] Chaque module a une responsabilité nommable en une phrase
- [x] Les fondations sont identifiées et **isolées** des modules métier
- [x] Les entités du socle sont définies champ par champ
- [x] Le graphe de dépendances est **sans cycle**, et le motif est donné
- [x] L'ordre d'implémentation est cohérent avec les dépendances
- [x] Les décisions non triviales sont documentées en ADR (001 → 013)
- [x] Le socle **ne définit aucun endpoint**, et les contrats qu'il impose sont listés explicitement

**Ce qui ne l'est pas — et pourquoi**

- [ ] Chaque user story a une **slice** correspondante. — **Phase 5.** Une slice est une unité de
      travail livrable ; la définir ici serait la deviner.
- [ ] Le graphe de dépendances est vérifié par `dependency-check.js`. — **Phase 5.** Le contrôle
      porte sur des slices ; il n'a rien à vérifier tant qu'elles n'existent pas. C'est
      `consistency-check: screens_have_slices` (INC-007) qui le signale aujourd'hui.
- [ ] Les commandes sont **fonctionnelles**. — **Phase 5.** Le squelette n'existe pas ; une commande
      documentée et non exécutée est une promesse.
- [ ] La frontière d'import est vérifiée par une commande. — **Phase 5.** La règle est écrite
      (`architecture.md` § Frontières), le contrôle la vérifiera quand il y aura des fichiers à
      contrôler.

## Points laissés ouverts pour la Phase 5

1. **Le découpage en slices** et leurs dépendances réelles — l'objet même de la Phase 5.
2. **La commande de vérification de la frontière d'import** : un script qui échoue si `src/core`
   importe React, le DOM ou le réseau. C'est un livrable, pas une décision.
3. **Le squelette du projet** : `package.json`, `.node-version` (ADR-008), arborescence `src/**` et
   `pilot/`. Puis les commandes deviennent exécutables.
4. **La version exacte de chaque dépendance** : le manifeste est la source de vérité
   (`forge-guard: version_pins_agree`), pas ce tableau.