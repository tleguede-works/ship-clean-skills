---
type: prd
status: approved
generated_at: 2026-09-29
version: 1
---

# Product Requirements Document — Plateforme de vues BI configurables

> Ce document décrit **ce que le produit fait, pour qui, et pourquoi**.
> Il ne décrit pas **comment** il sera implémenté. Les choix techniques sont dans
> `.forge/conventions.md`, la décomposition en `.forge/architecture.md`.
>
> Toute règle métier, tout cas limite et toute contrainte porte un identifiant stable
> (`B*`, `E*`, `C*`) qui sert de colonne vertébrale à toute la traçabilité du projet :
> PRD → architecture → plan de slice → test.
>
> **Résultat de la recherche de Phase 1.5 : 4 règles ajoutées après coup** — `B23` à `B26` ne
> figuraient pas dans la première rédaction. Elles viennent de la comparaison à trois produits de
> référence existants, consignée dans `.forge/benchmarks.md` § 3 et § 8. Une spécification écrite
> sans comparaison à ce qui existe déjà réinvente les erreurs des autres.

---

## 1. Résumé exécutif

### 1.1 Problème

Dans plusieurs applications de l'entreprise, les tableaux de bord sont écrits à la main, écran
par écran. Chaque nouveau besoin d'analyse — un indicateur, un filtre, une répartition, un
croisement — devient une demande de développement. Les profils métier qui devraient pouvoir
répondre seuls à leurs questions ne le peuvent pas : ils dépendent d'une équipe technique, avec
un délai et un coût par question.

### 1.2 Solution

Une plateforme qui permet à un utilisateur autorisé de **composer lui-même une vue** — un
ensemble d'indicateurs, de tableaux et de graphiques — à partir de variables métier
pré-autorisées, de la **configurer**, de la **disposer**, de la **publier**, de la **partager**,
puis de la **consulter** et de la retrouver à chaque ouverture avec ses données à jour.

La proposition de valeur tient en une phrase : **un besoin d'analyse courant se résout par la
configuration, sans développement**.

### 1.3 Utilisateurs cibles

Sept profils, dont cinq sont les utilisateurs finaux :

- **Analyste métier** — construit et maintient ses propres vues (le cœur de cible).
- **Décideur** — consulte, duplique, ne construit pas.
- **Contributeur métier** — propose des vues, sans les publier.
- **Administrateur de vues** — publie les vues par défaut, gère les audiences et les
  autorisations.
- **Responsable de données** — décide de ce qui est exposable, et à qui.
- **Intégrateur** — installe et configure le socle dans son application.
- **Mainteneur de la plateforme** — fait évoluer le socle pour tous.

### 1.4 Différenciation

La plupart des outils de business intelligence existants sont soit **rigides** (un développeur
code chaque indicateur), soit **abandonnants** (un outil généraliste que personne n'arrive à
prendre en main, et qui ne s'intègre pas au produit). La proposition tient le milieu : une
intégration **native** dans l'application, une expérience **non technique**, et une
souveraineté totale sur **quelles données** sont exposées.

---

## 2. Utilisateurs et personas

| Persona                     | Rôle                                   | Contexte                                          | Niveau technique | Besoin principal                               | Fréquence   |
| --------------------------- | -------------------------------------- | ------------------------------------------------- | ---------------- | ---------------------------------------------- | ----------- |
| Analyste métier             | Crée, configure, publie ses vues       | Bureau, plusieurs fois par semaine                | Non technique    | Répondre à une question sans attendre un dev   | Élevée      |
| Décideur                    | Consulte, duplique                     | Réunion, préparation, contrôle                    | Non technique    | Voir ses chiffres à jour sans manipulation     | Quotidienne |
| Contributeur métier         | Propose une vue                        | Idem, sans droit de publication                   | Non technique    | Partager une analyse sans la rendre officielle | Ponctuelle  |
| Administrateur de vues      | Publie, cible, autorise                | Récurrent, mensuel                                | Faible           | Contrôler ce qui est publié et pour qui        | Mensuelle   |
| Responsable de données      | Enregistre les variables exposées      | Ponctuel, lors d'une évolution de modèle          | Élevé            | Maîtriser ce qui devient consultable           | Ponctuelle  |
| Intégrateur                 | Installe le socle dans son application | Au démarrage d'un projet, puis à chaque évolution | Élevé            | Configurer vite sans réécrire l'application    | Projet      |
| Mainteneur de la plateforme | Fait évoluer le socle                  | Continu                                           | Élevé            | Ne pas casser les projets consommateurs        | Continue    |

---

## 3. User stories

<!-- Priorité : P1 (doit avoir) · P2 (devrait avoir) · P3 (pourrait avoir) · P4 (pas maintenant) -->

### US-1 : Consulter ses vues

- **En tant que** décideur
- **Je veux** retrouver mes vues et les ouvrir avec leurs données déjà chargées
- **Afin de** voir mes chiffres sans manipulation préalable

**Priorité** : P1 · **Dépendances** : US-9, US-12
**Critères d'acceptation** :

- [ ] La liste distingue mes vues, celles qui m'ont été partagées et, si applicable, celles
      par défaut de mon profil.
- [ ] À l'ouverture d'une vue, les indicateurs s'affichent automatiquement.
- [ ] Je vois pour chaque vue son nom, sa description, son propriétaire, sa dernière mise à jour
      et sa version publiée.
- [ ] Le tri par nom, description, propriétaire, date et statut est disponible.

### US-2 : Créer une vue — étape 1, informations

- **En tant que** analyste métier
- **Je veux** nommer et décrire ma vue et choisir qui peut la voir
- **Afin de** qu'elle soit identifiable et accessible aux bonnes personnes

**Priorité** : P1 · **Dépendances** : aucune
**Critères d'acceptation** :

- [ ] Le nom est obligatoire ; la description est facultative par défaut.
- [ ] Les valeurs saisies sont conservées si je reviens en arrière.
- [ ] Les cibles d'accès que je peux proposer dépendent de mon propre niveau d'autorisation.
- [ ] Une vue ne peut pas être enregistrée sans nom ni description valides.

### US-3 : Créer une vue — étape 2, indicateurs

- **En tant que** analyste métier
- **Je veux** ajouter des indicateurs et les configurer avec des choix proposés
- **Afin de** construire mon analyse sans connaître le modèle de données

**Priorité** : P1 · **Dépendances** : US-2
**Critères d'acceptation** :

- [ ] Je choisis un type d'indicateur parmi la liste proposée.
- [ ] Je choisis une variable métier parmi celles autorisées pour moi, avec des libellés
      compréhensibles.
- [ ] Je peux croiser, filtrer et choisir une période, uniquement parmi les choix autorisés.
- [ ] Aucun nom de table, de colonne, de champ technique ou de code n'est affiché.
- [ ] Chaque indicateur affiche un aperçu de données réelles ou de données de démonstration
      identifiées comme telles.
- [ ] L'assistant comporte exactement trois étapes, quel que soit le type d'indicateur.

### US-4 : Créer une vue — étape 3, disposition

- **En tant que** analyste métier
- **Je veux** organiser mes indicateurs à l'écran
- **Afin de** obtenir une vue lisible

**Priorité** : P1 · **Dépendances** : US-3
**Critères d'acceptation** :

- [ ] Je peux déplacer, redimensionner et réordonner chaque indicateur.
- [ ] Chaque action d'organisation est réalisable au clavier, sans souris.
- [ ] La disposition est conservée et restituée à la réouverture.
- [ ] La disposition s'adapte aux petites largeurs sans perte d'information.

### US-5 : Publier une vue

- **En tant que** analyste métier
- **Je veux** enregistrer un brouillon puis le publier
- **Afin de** figer une analyse que d'autres consommeront

**Priorité** : P1 · **Dépendances** : US-4
**Critères d'acceptation** :

- [ ] Je peux enregistrer un brouillon sans le publier, et le reprendre plus tard.
- [ ] La publication crée une version distincte ; la version précédente reste inchangée.
- [ ] Je ne peux pas publier une vue contenant un indicateur invalide, sauf si j'ai
      explicitement retiré cet indicateur.
- [ ] Un échec d'enregistrement ne détruit jamais ce que j'ai saisi.

### US-6 : Modifier une vue sans casser la version publiée

- **En tant que** analyste métier
- **Je veux** modifier une vue déjà publiée
- **Afin de** l'améliorer sans changer ce que les autres voient avant validation

**Priorité** : P1 · **Dépendances** : US-5
**Critères d'acceptation** :

- [ ] Seul le propriétaire peut modifier sa vue ; un tiers qui l'a seulement partagée ou qui la
      reçoit comme vue par défaut ne peut que la dupliquer.
- [ ] La modification travaille sur un brouillon, jamais sur la version publiée.
- [ ] Je vois si mon brouillon diffère de la version publiée.
- [ ] Je peux consulter l'historique des versions, en sélectionner une pour la comparer, et
      restaurer une version antérieure.
- [ ] Si quelqu'un a modifié le même brouillon entre-temps, je ne perds pas mon travail et on
      me propose de recharger, de garder ma version ou d'annuler.

### US-7 : Partager une vue

- **En tant que** propriétaire d'une vue
- **Je veux** donner accès à des personnes ou à des groupes
- **Afin de** faire consommer mon analyse

**Priorité** : P1 · **Dépendances** : US-5
**Critères d'acceptation** :

- [ ] Le partage porte **à la fois** sur des personnes nommées et sur des groupes, profils ou
      rôles : les deux modes sont coexistants, pas alternatifs.
- [ ] Je ne peux partager qu'avec des cibles que je suis moi-même autorisé à viser.
- [ ] Le partage est explicite, listé et révocable.
- [ ] Donner accès à une vue ne donne aucun accès supplémentaire aux données : le destinataire
      ne voit que ce qu'il pouvait déjà voir.
- [ ] Le destinataire ne peut pas modifier une vue qu'il n'a que pour lecture ; il ne peut que
      la dupliquer.
- [ ] Le partage et sa révocation sont tracés.

### US-8 : Dupliquer une vue

- **En tant que** décideur
- **Je veux** dupliquer une vue dont je n'ai que l'accès en lecture
- **Afin de** l'adapter sans risquer de casser l'original

**Priorité** : P1 · **Dépendances** : US-7
**Critères d'acceptation** :

- [ ] La copie m'appartient et n'hérite d'aucun accès de l'original.
- [ ] Modifier la copie ne modifie jamais l'original.

### US-9 : Consommer une vue publiée

- **En tant que** décideur
- **Je veux** consulter une vue et ajuster ses paramètres
- **Afin de** poser ma question sans demander un développement

**Priorité** : P1 · **Dépendances** : US-1, US-5
**Critères d'acceptation** :

- [ ] Je vois la version que je consulte, et je peux en choisir une autre parmi les versions
      publiées de cette vue.
- [ ] Une vue peut définir **plusieurs paramètres communs** (période, et autres filtres
      discretionnaires définis par l'auteur) ; le nombre n'est pas figé par le produit.
- [ ] Je sais quels indicateurs un paramètre donné affecte, et lesquels il ne concerne pas.
- [ ] Je peux changer un paramètre commun, et je vois que ce changement est temporaire, pas
      enregistré.
- [ ] Je vois la date à laquelle les données de chaque indicateur ont été calculées.
- [ ] Si un indicateur échoue, les autres restent lisibles.
- [ ] **Je peux cliquer sur une valeur d'un indicateur pour filtrer les autres indicateurs de la
      vue** : je reste sur la même vue, les indicateurs concernés se recalculent, et je vois
      clairement le filtre appliqué et comment l'enlever.
- [ ] Le filtre croisé ne peut jamais me faire voir plus que ce que mes droits et mon périmètre
      de lignes autorisent déjà.
- [ ] Un filtre croisé n'ouvre **pas** d'autre jeu de données : la descente vers le détail d'une
      valeur n'existe pas en V1 (cf. § 9).

### US-10 : Être guidé par un assistant d'installation

- **En tant qu'** intégrateur
- **Je veux** qu'un assistant analyse mon projet et me propose une configuration
- **Afin de** ne pas devoir découvrir seul comment brancher le socle

**Priorité** : P2 · **Dépendances** : aucune
**Critères d'acceptation** :

- [ ] L'assistant détecte mon application, son mode de rendu, ma gestion des droits et mes
      tests, et me le confirme.
- [ ] Il me demande les choix qui changent la sécurité ou l'accès, plutôt que de les
      inventer.
- [ ] Il génère une configuration et un catalogue relus avant usage.
- [ ] Il signale ce qu'il n'a pas pu détecter au lieu de laisser une valeur par défaut muette.
- [ ] Il ne produit jamais de secret, de code d'accès direct aux données, ni de contournement
      des autorisations.

### US-11 : Administrer les vues par défaut

- **En tant qu'** administrateur de vues
- **Je veux** désigner les vues par défaut et consulter les journaux d'exécution
- **Afin que** chacun arrive sur l'analyse qui le concerne, et que je puisse répondre à une
  question d'exploitation

**Priorité** : P2 · **Dépendances** : US-5, US-7
**Critères d'acceptation** :

- [ ] Je désigne et retire une vue par défaut, et l'opération est tracée.
- [ ] Les membres du profil concerné ne peuvent pas modifier la vue par défaut, seulement la
      dupliquer (`B10b`).
- [ ] Changer une vue par défaut ne modifie pas la vue elle-même.
- [ ] Je consulte le journal des exécutions des autres : qui, quand, sur quelle vue, et si
      l'exécution a réussi ou échoué.
- [ ] Voir qu'une requête a été exécutée **ne me donne pas accès à son résultat** : le journal
      ne contient ni les valeurs filtrées, ni les lignes retournées, ni les données sensibles
      (`B28`).
- [ ] La conservation du journal est celle définie par le projet : 12 mois conservés dont 3
      immédiatement consultables par défaut, réglable entre 3 et 12 mois (`B29`).
- [ ] Au-delà de la fenêtre chaude, la consultation demande une restauration explicite : un
      journal absent ne doit jamais se lire comme un journal qui n'a jamais rien eu.
- [ ] Par défaut, `journal:read` n'est pas inclus dans mon droit d'administration des vues : un
      administrateur d'application ne lit pas le journal de l'exécution qui ne relève pas de son
      périmètre (`B31`, `B33`, `B34`).
- [ ] Ma consultation du journal est elle-même journalisée : un administrateur qui lit un journal
      apparaît dans ce journal (`B35`).
- [ ] Un projet hôte qui réunit les deux droits dans un seul rôle le peut, sans contournement
      (`B32`).

### US-12 : Comprendre l'origine et la fraîcheur des chiffres

- **En tant que** décideur
- **Je veux** savoir quand mes chiffres ont été calculés et si quelque chose manque
- **Afin de** ne pas prendre une décision sur un chiffre incomplet

**Priorité** : P1 · **Dépendances** : US-9
**Critères d'acceptation** :

- [ ] Chaque indicateur affiche sa date de calcul.
- [ ] Un résultat partiellement disponible est signalé comme tel, et j'apprends qu'elle
      partie manque.
- [ ] Un résultat qui dépasse une limite est signalé comme tronqué, jamais présenté comme
      complet.
- [ ] Un résultat dont la cohérence temporelle n'est pas garantie est signalé.

### US-13 : Recevoir un refus compréhensible

- **En tant qu'** utilisateur
- **Je veux** comprendre pourquoi une action n'est pas possible
- **Afin de** savoir quoi faire

**Priorité** : P1 · **Dépendances** : US-3, US-7
**Critères d'acceptation** :

- [ ] Un refus d'accès est formulé en termes métier, sans code technique.
- [ ] Une variable non autorisée pour moi n'est pas proposée, et si elle l'a été, on m'explique
      pourquoi elle ne convient plus.
- [ ] Un message d'erreur propose une action possible quand il en existe une.

### US-14 : Ne rien voir d'interdit, même dans l'interface

- **En tant que** responsable de la sécurité
- **Je veux** que les données sensibles n'apparaissent ni dans les choix, ni dans les aperçus,
  ni dans les résultats
- **Afin de** qu'aucune fuite ne soit possible par un simple regard sur l'écran

**Priorité** : P1 · **Dépendances** : US-3
**Critères d'acceptation** :

- [ ] Les variables sensibles ne sont pas proposées à qui n'a pas le droit de les consulter.
- [ ] Un aperçu ne contient jamais un champ interdit.
- [ ] Les résultats respects le périmètre de lignes de chaque personne.
- [ ] Un périmètre non déterminable ne renvoie rien plutôt que tout.

---

## 4. Règles métier

### 4.1 Vocabulaire d'actions

Le produit ne définit **aucun nom de droit** : chaque projet hôte a son propre système
d'autorisation, avec ses propres rôles, et l'imposer créerait un travail de migration chez tous
(`C2`). En revanche, le produit définit le **vocabulaire d'actions** qu'un projet doit savoir
exprimer, parce qu'une capacité qui n'a pas de nom ne peut pas être déléguée séparément.

| Action             | Signification                         | Séparable ?                         |
| ------------------ | ------------------------------------- | ----------------------------------- |
| `view:list`        | Voir la liste des vues accessibles    | oui                                 |
| `view:read`        | Consulter une vue et ses versions     | oui                                 |
| `view:write`       | Créer, modifier ou supprimer une vue  | oui — **absorbe les trois** (`B36`) |
| `view:publish`     | Publier une version                   | oui — transition de visibilité      |
| `view:duplicate`   | Dupliquer une vue                     | **non** — implique `read` + `write` |
| `view:share`       | Partager une vue                      | oui — délègue à un tiers            |
| `view:set-default` | Définir la vue par défaut d'un profil | oui                                 |
| `data:execute`     | Exécuter une requête d'indicateur     | oui                                 |
| `export:create`    | Exporter le résultat d'une vue        |
| `journal:read`     | Consulter le journal des exécutions   |

Le mapping vers les droits réels est fait par le projet hôte. Le socle ne dit pas « quel rôle
possède quelle action » — il dit **quelles actions existent et doivent pouvoir être déléguées
séparément**.

**Critère de séparation.** Une action n'est distincte d'une autre que si elle peut être accordée
**sans** elle. Appliqué aux opérations d'écriture :

- **Créer** une vue, c'est écrire une vue qui n'existe pas encore. Une restriction qui
  accorderait l'édition sans la création serait sans objet : il n'existe aucune vue accessible
  que personne n'ait déjà écrite.
- **Supprimer** une vue, c'est écrire son état. La suppression est un changement d'état, pas une
  opération d'une autre nature — d'autant que la version précédente reste consultable et
  restaurable : c'est un remplacement, pas une destruction.
- **Dupliquer** une vue, ce sont deux actions déjà séparables : lire la source, écrire la copie.
  Elle est nommée pour la lisibilité du journal, pas parce qu'elle ajouterait un pouvoir.

D'où une seule action d'écriture, `view:write`, et non trois. Une permission d'édition qui
n'autoriserait pas la création décrirait un pouvoir que personne ne sait exiger.

Restent distinctes, parce qu'elles ne se déduisent d'aucune autre :

| Action             | Pourquoi elle reste séparée                                            |
| ------------------ | ---------------------------------------------------------------------- |
| `view:publish`     | Rend visible par d'autres : un effet sur autrui que l'écriture n'a pas |
| `view:share`       | Délègue l'accès à un tiers : encore un effet sur autrui                |
| `view:set-default` | Change ce que verra un groupe, sans changer la vue                     |
| `journal:read`     | Ne dérive d'aucune autre ; voir § 12                                   |

**Correction d'un raisonnement.** L'argument « si je peux éditer, la précédente est supprimée »
est juste pour l'**état courant** et faux pour l'**historique** : la version antérieure n'est
pas détruite, elle est remplacée et reste restaurable. La fusion repose sur la suppression
d'avoir deux pouvoirs d'écriture, pas sur une destruction de version — qui aurait rendu
incompatible la restauration déjà décidée.

**Coût assumé.** Un projet qui veut qu'un gestionnaire corrige une vue officielle sans pouvoir en
créer de nouvelle ne peut plus l'exprimer par un droit unique : il passe par la propriété
(`B17`) ou par `view:publish`, qui sont les axes de granularité que la gouvernance exprime
réellement.

### 4.2 Règles

<!-- Une ligne par règle. IDs B1, B2… jamais réutilisés. -->

| ID   | Règle                                                                                                                                | US liée      | Notes                                                                                                                                                               |
| ---- | ------------------------------------------------------------------------------------------------------------------------------------ | ------------ | ------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| B1   | Une vue porte un nom obligatoire ; sa description est facultative par défaut et peut être rendue obligatoire par un projet hôte      | US-2         | Décision produit : la description n'est pas obligatoire par défaut                                                                                                  |
| B2   | Une vue est composée d'indicateurs identifiés par une référence stable et versionnée                                                 | US-3         | Jamais de code exécutable dans la configuration                                                                                                                     |
| B3   | Un indicateur référence des variables métier déclarées, jamais des champs techniques                                                 | US-3         | Les libellés sont résolus à l'affichage, jamais stockés comme source                                                                                                |
| B4   | L'assistant ne propose que des choix autorisés **et** supportés                                                                      | US-3         | Une option indisponible n'apparaît pas                                                                                                                              |
| B5   | Une vue publiée est immuable ; toute modification travaille sur un brouillon distinct                                                | US-6         |                                                                                                                                                                     |
| B6   | La publication crée une version distincte et identifiable                                                                            | US-5         | Un changement de version est tracé                                                                                                                                  |
| B7   | Le partage est explicite, listé et révocable ; il porte à la fois sur des personnes nommées et sur des groupes ou profils            | US-7         | Les deux modes coexistent, ils ne sont pas alternatifs                                                                                                              |
| B8   | Le partage ne confère aucun droit d'accès aux données supplémentaire                                                                 | US-7         | Intersection avec le périmètre du destinataire                                                                                                                      |
| B9   | La duplication crée une vue indépendante qui n'hérite d'aucun accès de l'original                                                    | US-8         |                                                                                                                                                                     |
| B10  | Un changement de vue par défaut est un changement de rattachement, jamais une édition                                                | US-11        |                                                                                                                                                                     |
| B10b | Seul le propriétaire d'une vue peut la modifier ; un membre du profil ou un partageur ne peut que la dupliquer                       | US-6/7/8/11  | La duplication (B9) est l'unique voie de personnalisation par un tiers                                                                                              |
| B11  | L'assistant comporte exactement trois étapes : informations, indicateurs, disposition                                                | US-2/3/4     |                                                                                                                                                                     |
| B12  | Un indicateur dont une variable disparaît ou devient interdite passe en « mise à jour requise »                                      | US-6         | Jamais de substitution silencieuse vers une autre variable                                                                                                          |
| B13  | Un rafraîchissement d'une vue produit un ensemble de résultats cohérent entre eux                                                    | US-9         | En cas d'impossibilité, l'état est signalé plutôt que masqué                                                                                                        |
| B14  | Chaque résultat porte sa date de calcul et son état de fraîcheur                                                                     | US-12        | Un résultat périmé est signalé, jamais présenté comme actuel                                                                                                        |
| B15  | L'échec d'un indicateur n'affecte ni l'affichage ni le chargement des autres                                                         | US-9         |                                                                                                                                                                     |
| B16  | Un brouillon en cours de saisie n'est jamais détruit par un échec                                                                    | US-6         | Échec d'enregistrement, conflit de version ou erreur de validation                                                                                                  |
| B17  | Toute action d'organisation a un équivalent clavier                                                                                  | US-4         | Le glisser-déposer est un complément, jamais l'unique moyen                                                                                                         |
| B18  | Un graphique dispose d'un nom accessible, d'un résumé et d'un tableau de valeurs                                                     | US-9         |                                                                                                                                                                     |
| B19  | L'interface n'affiche jamais de nom de table, de champ technique, de code ni de secret                                               | US-3         |                                                                                                                                                                     |
| B20  | Les limites d'exécution sont imposées par le service et ne sont pas négociables                                                      | US-3/12      | Le dépassement produit un refus explicite, jamais une troncature muette                                                                                             |
| B21  | Une limite de taille, de durée ou de précision dépassée produit un refus explicite                                                   | US-12        |                                                                                                                                                                     |
| B22  | Les résultats d'une même vue ne sont jamais mélangés si leur cohérence n'est pas garantie                                            | US-12        |                                                                                                                                                                     |
| B23  | L'auteur d'une vue est soumis aux mêmes restrictions de données que ses lecteurs                                                     | US-3/14      | Il ne peut pas composer un indicateur qu'il ne pourrait pas consulter lui-même                                                                                      |
| B24  | Une version antérieure reste consultable, sélectionnable et restaurable                                                              | US-6/9       | L'immuabilité n'a de raison d'être que si le retour arrière existe                                                                                                  |
| B25  | Le contrôle d'accès aux données s'applique à **tout** chemin qui y mène, et pas seulement à la consultation d'une vue                | US-14        | Un même jeu de données atteignable par un autre chemin n'est plus protégé par la restriction de lignes                                                              |
| B26  | L'ordre des indicateurs et la déduplication des requêtes sont stables et totaux                                                      | US-9         | Deux ouvertures de la même vue produisent le même résultat                                                                                                          |
| B27  | Une vue ne peut pas être publiée tant qu'elle ne contient aucun indicateur                                                           | US-5         | La publication est refusée avec un message explicite ; le brouillon est conservé                                                                                    |
| B28  | Le journal d'exécution montre **qu'une** requête a été exécutée, jamais **ce qu'elle a retourné**                                    | US-11        | L'administrateur voit qui, quoi, quand et le succès ; ni valeurs filtrées, ni lignes, ni données sensibles                                                          |
| B29  | La conservation du journal d'exécution est réglée par projet hôte, entre 3 et 12 mois, avec une fenêtre « chaude » de 1 à 3 mois     | US-11        | Défaut : **12 mois conservés, 3 mois immédiatement consultables** — aligné sur PCI DSS 4.0.1 §10.5.1, sans l'imposer aux projets hors périmètre                     |
| B30  | Une valeur d'un indicateur peut être cliquée pour **filtrer les autres indicateurs de la même vue**                                  | US-9         | Le filtre est appliqué côté service, sous les mêmes droits : `B7` et `B25` continuent de tenir                                                                      |
| B31  | `journal:read` est une action **distincte** de l'administration des vues : elle se délègue séparément                                | US-11        | Une capacité sans nom ne peut pas être déléguée séparément ; le socle nomme l'action, l'hôte choisit le rôle (§ 4.1)                                                |
| B32  | Un projet hôte **peut** réunir `journal:read` et l'administration des vues dans un même rôle ; le socle ne l'interdit pas            | US-11        | Un projet à un seul administrateur n'a aucun bénéfice à la séparation ; ce n'est pas au socle de l'imposer (`C2`)                                                   |
| B33  | Par défaut, pour un nouveau projet, les deux sont **distincts**                                                                      | US-11        | Le socle ne connaît pas le contexte : le moindre privilège est le seul défaut qui ne puisse pas se révéler trop large. Rouvrir = une ligne de configuration         |
| B34  | La portée de `journal:read` est **bornée par le périmètre** auquel son titulaire est déjà soumis ; l'élargir exige un droit distinct | US-11, US-12 | « Administrateur de l'application A » ne lit pas le journal de l'application B. Un droit plus large est un rôle d'audit, pas une extension du rôle d'administration |
| B35  | La consultation du journal est **elle-même journalisée** : qui lit quoi, quand, et sur quelle période                                | US-11        | Un journal non consultable est déjà une trace ; un journal consultable sans trace laisse l'auto-espionnage hors de portée (PCI DSS 10.2.x)                          |
| B36  | Créer, modifier et supprimer une vue relèvent d'une **action unique** `view:write`, non déléguable en trois                          | US-2, US-3   | Créer, c'est écrire une vue absente ; supprimer, c'est écrire son état. Un droit d'édition sans création serait un pouvoir que personne n'exige                     |
| B37  | Écrire une vue **remplace** son état courant et ne détruit pas ses versions antérieures, qui restent consultables et restaurables    | US-5         | Distingue « remplacé » de « supprimé » : la restauration déjà décidée deviendrait impossible si l'écriture détruisait l'historique                                  |

---

## 5. Contraintes

<!-- Une ligne par contrainte. IDs C1, C2… -->

| ID  | Contrainte                                                                                     | Type      | Impact                                                         |
| --- | ---------------------------------------------------------------------------------------------- | --------- | -------------------------------------------------------------- |
| C1  | Le socle ne doit imposer ni modèle de données, ni base de données, ni mécanisme de persistance | technique | Chaque application hôte choisit son stockage                   |
| C2  | Le socle ne doit imposer aucun mécanisme d'authentification                                    | technique | Le socle s'intègre dans l'existant, il ne le remplace pas      |
| C3  | Le socle ne doit imposer aucune bibliothèque d'interface ni aucun style visuel                 | technique | Cohérence visuelle assurée par l'hôte                          |
| C4  | Le socle ne doit effectuer aucun accès réseau direct                                           | technique | Le cœur reste testable sans service de données                 |
| C5  | La traduction des textes est fournie par l'application hôte, dans au moins deux langues        | technique | Aucune langue unique imposée                                   |
| C6  | La réutilisation doit être démontrée par au moins deux applications hôtes distinctes           | technique | Voir l'explication de `C6` ci-dessous                          |
| C7  | L'analyse en temps réel est hors périmètre de la première version                              | métier    | Le rafraîchissement périodique est accepté                     |
| C8  | Le partage public, anonyme ou intégré dans un autre site est interdit                          | légal     | Pas de surface d'exposition externe                            |
| C9  | Un besoin d'analyse courant doit pouvoir être satisfait sans développement                     | métier    | C'est la promesse principale ; elle doit être mesurée          |
| C10 | Les délais de réponse ne peuvent être promise qu'après mesure sur des volumes réels            | métier    | Un chiffre annoncé sans mesure est une promesse non vérifiable |
| C11 | Le socle reste utilisable par des personnes non techniques pour la partie authoring            | métier    | Une interface technique n'est pas livrable                     |
| C12 | Le socle ne doit pas imposer de mécanisme de cache ni de bibliothèque de requête               | technique | L'hôte choisit sa stratégie de performance                     |

---

### Explication de `C6` — ce qu'est un « second projet hôte »

Un **projet hôte** est une application qui utilise le socle. L'application SMS Banking est le
premier. Un **second projet hôte** en est un **autre**, qui consomme le même socle pour un
autre métier, avec ses propres données, ses propres droits et sa propre apparence.

**Pourquoi c'est une condition, pas un formalisme.** Un socle peut fonctionner parfaitement dans
la seule application qui l'a vu naître, et n'être malgré tout **irréutilisable** : cela arrive
chaque fois qu'une dépendance s'est glissée dans le cœur sans qu'on la voie — un vocabulaire
métier, un droit, un format, une dépendance technique. Le second projet hôte est le seul
moyen mécanique de **révéler** ces.glissements : on ne découvre pas qu'une règle est figée sur
un seul métier que le jour où un autre métier essaie de s'en servir.

Sans lui, l'affirmation « c'est réutilisable » reste une hypothèse non testée. C'est exactement
le genre d'affirmation que ce projet refuse de laisser passer sans preuve — voir `C10` pour la
même discipline appliquée aux délais de réponse.

Le second projet n'a pas besoin d'être aussi gros que le premier. Il lui faut un **catalogue de
variables différent**, une **autre gestion des droits** et **une autre apparence** : c'est la
variété qui prouve la réversibilité. Une seconde application qui partage le même métier ne
prouverait rien.

---

## 6. Cas limites

<!-- Une ligne par cas limite. IDs E1, E2… -->

| ID  | Cas                                                         | Déclencheur                              | Comportement attendu                                                                                                              | Sévérité |
| --- | ----------------------------------------------------------- | ---------------------------------------- | --------------------------------------------------------------------------------------------------------------------------------- | -------- |
| E1  | Deux éditeurs modifient le même brouillon                   | Édition concurrente                      | Aucun écrasement ; proposer recharger, garder sa copie, ou annuler ; le travail est préservé                                      | high     |
| E2  | Une variable du catalogue disparaît                         | Mise à jour du catalogue                 | L'indicateur passe en « mise à jour requise » ; la publication est bloquée tant que non résolu                                    | high     |
| E3  | Une variable devient interdite                              | Révocation de droits en cours de session | Les nouveaux chargements cessent ; l'interface explique ce qui n'est plus accessible                                              | high     |
| E4  | Un indicateur échoue au chargement                          | Erreur de service                        | L'indicateur affiche son erreur ; les autres restent lisibles ; une action « Réessayer » est proposée                             | medium   |
| E5  | Aucune donnée sur la période                                | Filtre ou période sans résultat          | Message expliquant la période active et proposition d'élargir la période si c'est possible                                        | medium   |
| E6  | Le résultat dépasse la limite de lignes                     | Gros volume                              | Résultat signalé comme tronqué, avec le compte exact et non un total silencieux                                                   | high     |
| E7  | La requête dépasse la durée maximale                        | Requête coûteuse                         | Refus explicite et proposition d'une alternative plus légère                                                                      | high     |
| E8  | L'utilisateur n'a aucun accès                               | Adresse devinée                          | Réponse qui ne révèle pas l'existence de la ressource si sa présence est sensible                                                 | high     |
| E9  | Publication d'une vue sans indicateur                       | Cas limite du wizard                     | Publication refusée avec un message expliquant qu'au moins un indicateur est requis ; la saisie et la disposition sont conservées | medium   |
| E10 | Deux vues portent le même nom                               | Noms libres                              | Autorisé, mais la liste distingue clairement propriétaire et date                                                                 | low      |
| E11 | Le catalogue change pendant l'édition                       | Mise à jour concurrente                  | Aucun indicateur ne pointe silencieusement vers une autre variable                                                                | high     |
| E12 | Le navigateur se ferme pendant la saisie                    | Fermeture ou coupure                     | Le brouillon récupérable est proposé au retour ; aucune saisie valide n'est perdue sans prévenir                                  | high     |
| E13 | Une cible d'audience est supprimée                          | Réorganisation des groupes ou profils    | La vue signale une audience invalide au lieu d'échouer silencieusement                                                            | medium   |
| E14 | Un type d'indicateur n'est plus disponible                  | Mise à jour de l'application hôte        | L'indicateur inconnu s'affiche en état « non pris en charge », sans casser la vue                                                 | medium   |
| E15 | Certaines sources sont en retard                            | Ingestion partielle                      | L'état partiel est signalé et la partie manquante est identifiée                                                                  | high     |
| E16 | Une version précédemment publiée est retirée                | Révocation                               | La consommation s'arrête proprement avec une explication, sans écran cassé                                                        | medium   |
| E17 | Un paramètre global ne s'applique qu'à certains indicateurs | Filtre ajouté à la volée                 | Les indicateurs non concernés sont identifiés comme non filtrés                                                                   | medium   |
| E18 | Perte de connexion pendant la saisie                        | Réseau instable                          | L'état local reste manipulable ; l'avertissement de sauvegarde en attente reste visible                                           | medium   |

---

## 7. Exigences non fonctionnelles

### 7.1 Performance

- Le chargement d'une vue standard doit être mesuré sur des volumes réels, avant tout
  engagement chiffré (cf. C10).
- Un changement de filtre ou de période doit être perçu immédiatement, même si le résultat
  arrive ensuite.
- Un rafraîchissement global ne doit pas multiplier la charge de façon incontrôlée.
- Un tableau ne doit jamais charger un volume complet pour afficher sa première page.
- Un changement de disposition ne doit jamais recharger les données.
- Les indicateurs hors écran ne doivent pas être chargés avant d'être utiles.

### 7.2 Sécurité

- L'autorité de décision est le service qui fournit les données, jamais l'interface.
- Trois contrôles sont **conjointifs** : accès à la vue, accès aux données, périmètre de
  lignes. Tous doivent être vrais.
- Un périmètre non déterminable produit un résultat **vide**, jamais un résultat complet.
- La configuration d'une vue ne contient aucun code exécutable, aucun secret et aucune URL
  d'accès direct aux données.
- Les textes saisis par les utilisateurs sont traités comme des données non fiables.
- Les refus sont formulés en termes métier, sans code technique ni détail interne.
- Les actions sur les vues et les exécutions sont journalisées en écriture seule.
- **La lecture du journal est elle-même journalisée** (`B35`) : un journal consultable sans
  trace laisserait l'auto-espionnage hors de portée.
- Le socle nomme les **actions** qu'un projet doit savoir déléguer séparément (§ 4.1), jamais les
  **rôles** : le mapping appartient à l'hôte (`C2`). Le défaut est le moindre privilège, pas la
  réunion (`B31`–`B34`).
- Une action n'est distincte que si elle est accordable sans les autres ; l'écriture est donc
  **une** capacité, pas trois (`B36`), et elle remplace l'état courant sans détruire
  l'historique (`B37`).
- Les valeurs sensibles n'apparaissent pas dans les journaux, les traces techniques ou les
  événements de mesure.

### 7.3 Accessibilité

- Cible : **zéro** manquement grave sur les parcours principaux.
- Tout parcours est intégralement opérable au clavier, y compris le déplacement et le
  redimensionnement des indicateurs.
- Aucune information n'est portée par la couleur seule.
- Tout graphique a une alternative textuelle et un tableau de valeurs.
- Le filtrage croisé (`B30`) a un équivalent clavier et se retire au clavier ; le filtre actif
  est annoncé et visible dans un tableau, pas seulement signalé par la couleur des segments.
- Le parcours reste utilisable sur écran étroit, avec agrandissement du texte et zoom élevé.
- Les animations non essentielles respectent le réglage de réduction des animations du système.
- Les messages d'erreur sont annoncés de façon utile, sans répétition ni retard.

### 7.4 Internationalisation

- Tous les textes de l'interface sont fournis par l'application hôte (C5).
- Les libellés métier sont résolus au moment de l'affichage, jamais figés dans la vue.
- Les formats de date, de nombre et de devise suivent les conventions de l'application hôte.
- La langue d'affichage n'affecte jamais le contenu d'une donnée.

### 7.5 Disponibilité et résilience

- L'indépendance des indicateurs est une règle : la perte d'un service de données ne doit pas
  rendre la vue inutilisable.
- Une erreur d'un indicateur est récupérable sans rechargement complet.
- Une coupure de réseau en cours de saisie ne détruit pas le travail.
- Le socle peut être désactivé par l'application hôte sans perte de données.

---

## 8. Risques et inconnues

| Risque                                                        | Probabilité | Impact | Mitigation                                                                    |
| ------------------------------------------------------------- | ----------- | ------ | ----------------------------------------------------------------------------- |
| L'interface reste trop technique et n'est pas adoptée         | Moyenne     | Élevé  | Limiter les choix proposés ; tester la compréhension avec des non-techniciens |
| Le périmètre de lignes n'est pas disponible côté service      | Élevée      | Élevé  | Traitement en échec fermé ; documenter explicitement la limite                |
| Le socle devient couplé à sa première application hôte        | Moyenne     | Élevé  | Frontières d'import imposées ; second hôte obligatoire (C6)                   |
| La surface de configuration devient une surface d'attaque     | Moyenne     | Élevé  | Modèle fermé ; aucune requête libre ; limites imposées par le service         |
| La performance s'effondre sur les volumes réels               | Moyenne     | Élevé  | Mesurer avant d'annoncer (C10) ; limites et pagination par défaut             |
| Le catalogue de variables devient ingérable                   | Moyenne     | Moyen  | Responsable de données nommé par jeu de variables ; catalogue versionné       |
| Un besoin non couvert par le catalogue est demandé en urgence | Élevée      | Moyen  | Mesurer le taux de demandes satisfaites par configuration (C9)                |
| Le second hôte de validation n'est jamais trouvé              | Moyenne     | Élevé  | Condition de sortie explicite : sans lui, pas d'extraction (C6)               |

### Inconnues

- ⚠️ Le nombre exact de variables par jeu de données, et donc la lisibilité du catalogue, n'est
  pas mesuré.
- ⚠️ Le délai nécessaire à un non-technique pour construire sa première vue n'est pas mesuré.
- ⚠️ Les volumes réels de données par projet ne sont pas connus, donc aucun délai de réponse
  ne peut être promis (C10).

---

## 9. Hors périmètre (explicite)

- Requête en langage libre, script ou expression arbitraire — raison : surface d'attaque et
  difficulté de performance.
- Jointure libre entre plusieurs jeux de données — raison : le croisement se fait par des
  variables déclarées, pas par un graphe de relations.
- Connexion à une source de données choisie par l'utilisateur — raison : les identifiants ne
  quittent jamais le service.
- Analyse en temps réel — raison : rafraîchissement périodique accepté (C7).
- Partage public ou anonyme — raison : surface d'exposition (C8).
- Export de données — raison : hors du besoin de pilotage initial, à réévaluer.
- Alertes, rapports programmés, envoi périodique — raison : cycles de vie à vie longue, non
  nécessaires au premier besoin.
- Génération de code ou de configuration par intelligence artificielle exécutant du code non
  revu — raison : l'assistant propose et fait relire, il n'exécute pas.
- **Descente en détail** : cliquer sur une valeur pour ouvrir un _autre_ jeu de données qui
  explique ce total — raison : c'est une capacité d'exécution supplémentaire, avec ses propres
  règles d'accès, qui transforme une vue d'observation en vue d'investigation. Le **filtrage
  croisé** au sein de la même vue (`B30`) est, lui, inclus en V1 — il supprime le même
  anti-pattern pour un coût bien moindre.
- Réécriture automatique des tableaux de bord existants dans les applications consommatrices —
  raison : chaque application décide de son calendrier.

---

## 10. Critères de succès

- Un utilisateur non technique crée, enregistre, publie et rouvre une vue valide sans
  intervention de développeur.
- Un utilisateur consulte une vue partagée et duplicate une vue qu'il n'a qu'en lecture, sans
  altérer l'original.
- Le taux de demandes d'analyse courantes satisfaites **par configuration** est mesuré et
  suivi — c'est le principal indicateur de la promesse (C9).
- Aucun résultat n'est affiché à une personne qui n'a pas le droit de le voir, ni en
  consultation, ni en aperçu, ni dans les choix proposés.
- Aucune version publiée n'est modifiée en place.
- Un deuxième projet adopte le socle sans adaptation du cœur de métier — preuve que le produit
  est réutilisable et non un habillage du premier projet (C6).
- Aucun délai de réponse n'est annoncé sans mesure sur volumes réels (C10).

---

## 11. Glossaire

| Terme               | Définition                                                                |
| ------------------- | ------------------------------------------------------------------------- |
| Vue                 | Tableau de bord composé d'indicateurs, que l'on crée, publie et consulte  |
| Indicateur          | Élément affichable d'une vue (valeur unique, graphique ou tableau)        |
| Brouillon           | Version de travail modifiable d'une vue                                   |
| Version publiée     | Version figée d'une vue, immuable, que l'on peut consulter                |
| Version par défaut  | Vue qu'une application ouvre d'elle-même pour un profil donné             |
| Variable métier     | Dimension, mesure, date ou statut exposée par un jeu de données           |
| Catalogue           | Ensemble des variables exposées, avec leur libellé et leurs droits        |
| Cible               | Entité qui porte un accès : personne, groupe, profil, rôle ou périmètre   |
| Audience            | Ensemble des cibles autorisées à consulter une vue                        |
| Périmètre de lignes | Restriction serveur sur les lignes visibles pour une personne             |
| Fraîcheur           | Date à laquelle un résultat a été calculé, et son état de périmésion      |
| Jeu de données      | Ensemble de variables exposées comme une unité de catalogue               |
| Souveraineté        | Droit de l'application hôte sur ses données, ses droits et son appearance |

---

## 12. Points à clarifier

À trancher avant la Phase 4 (architecture). Aucun de ces points ne doit être décidé
implicitement pendant l'implémentation.

### Décisions prises (2026-09-29)

| Point                                              | Décision                                                                                                                       | Règle       |
| -------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------ | ----------- |
| Description obligatoire ?                          | Non par défaut ; un projet hôte peut la rendre obligatoire                                                                     | `B1`        |
| Publier une vue sans indicateur ?                  | Non — la publication est refusée, le brouillon est conservé                                                                    | `B27`, `E9` |
| Partage nominatif ?                                | Les deux : personnes nommées **et** groupes / profils, en coexistence                                                          | `B7`        |
| Édition d'une vue par un tiers ?                   | Non — seul le propriétaire édite ; les autres ne peuvent que dupliquer                                                         | `B10b`      |
| Consulter une version publiée antérieure ?         | Oui, sélectionnable et restaurable                                                                                             | `B24`       |
| Nombre de paramètres communs d'une vue ?           | Plusieurs, non figés par le produit                                                                                            | `US-9`      |
| L'administrateur voit-il les journaux des autres ? | Oui, mais **jamais les résultats** — voir la distinction `B28`                                                                 | `B28`       |
| Second projet hôte (`C6`)                          | **Elora** (application mobile) — voir l'explication ci-dessous                                                                 | `C6`        |
| Durée de conservation du journal (`B28`)           | **Option C** : réglage par projet, 3 à 12 mois, fenêtre chaude de 1 à 3 mois ; défaut **12 / 3**, aligné PCI DSS 4.0.1 §10.5.1 | `B29`       |
| Drill-down                                         | **Filtrage croisé en V1** ; **descente en détail repoussée** hors périmètre (§ 9)                                              | `B30`       |

### Décision sur `C6` — le second projet hôte est **Elora**

`C6` est retenue sur : **`Elora`** — application mobile, présentée dans le dossier de travail de
l'entreprise.

**Pourquoi celui-là, et pas un autre.** Sur les projets présents, c'est le seul qui cumule les
trois conditions qui rendent la preuve utile :

| Condition              | SMS Banking (premier hôte)  | Elora (second hôte)                                               |
| ---------------------- | --------------------------- | ----------------------------------------------------------------- |
| Même langage           | TypeScript / React          | TypeScript / React — le cœur est consommable tel quel             |
| **Modèle d'affichage** | Web, grille, navigateur     | **Mobile natif, sans DOM** — ni CSS, ni grille, ni composants web |
| Données                | Base interne, tables métier | **API de boutique en ligne**, schéma totalement différent         |
| Droits                 | Profils, rôles, périmètres  | **Aucun profil ni rôle** — grand public                           |
| Cache / requêtes       | À mettre en place           | Utilise déjà un cache de requêtes côté client                     |

La ligne **« modèle d'affichage »** est la plus importante : Elora ne peut pas exécuter une
grille web. Si le socle n'y est pas adaptatif, il le prouve immédiatement — c'est exactement le
test qui manquait, et il est gratuit. De même, l'absence de profils et de rôles chez Elora
prouve que les cibles d'accès sont bien définies par l'hôte, et non figées dans le produit
(cf. `B7`).

**Ce que cette preuve ne démontre pas — à assumer explicitement.** Elora est une application
grand public, pas un outil de pilotage interne. Elle prouve la **réutilisabilité technique**, pas
l'**adoption métier** : rien ne garantira qu'un responsable de domaine y ait un jour besoin de
composer des vues. C'est pourquoi la preuve métier reste un objectif distinct, à mener plus
tard avec une deuxième application interne.

**Pourquoi Elora n'est pas déclaré « projet de référence ».** Un projet de référence est une
source **en lecture seule** que Forge analyse. Un projet hôte est un **consommateur** de ce que
nous construisons. Elora ne sera pas lu, il sera intégré : le déclarer comme référence
confondrait deux rôles et justifierait à tort une interdiction d'écriture. Il est documenté ici
comme cible d'intégration, rien de plus.

**Ce que `C6` bloque, et ce qu'elle ne bloque pas.** `C6` bloque l'**extraction en
bibliothèque** — tant qu'aucun second hôte n'a consommé le socle, « c'est réutilisable » reste
une hypothèse. Elle ne bloque **pas** la construction du pilote dans ce dépôt, qui est
précisément le moyen de rendre `C6` vérifiable. Ne pas confondre la porte de sortie avec la
porte d'entrée.

### Points tranchés

Les 11 points de cette section sont tranchés. Le onzième l'a été après approbation : il a produit
une modification du PRD, parce que la réponse à « faut-il séparer ? » supposait un vocabulaire
d'actions qui n'existait pas encore.

**Droit de lecture du journal d'exécution — tranché, en cinq règles.** La réponse n'est pas
« oui » ou « non » mais **« le socle nomme, l'hôte répartit, le défaut protège »** :

| Règle | Ce qu'elle dit                                                                        | Pourquoi                                                                                                      |
| ----- | ------------------------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------- |
| `B31` | `journal:read` est une action distincte et déléguable séparément                      | Une capacité sans nom ne peut pas être déléguée séparément                                                    |
| `B32` | Un hôte **peut** réunir les deux dans un même rôle                                    | Un projet à un seul administrateur n'a rien à y gagner ; ce n'est pas au socle de l'imposer                   |
| `B33` | Par défaut, ils sont **distincts**                                                    | Le socle ignore le contexte : le moindre privilège est le seul défaut qui ne puisse pas se révéler trop large |
| `B34` | La portée est **bornée par le périmètre** du titulaire ; l'élargir est un autre droit | « Administrateur de A » ne lit pas le journal de B                                                            |
| `B35` | La consultation est **elle-même journalisée**                                         | Sans cela, l'auto-espionnage du journal est hors de portée (PCI DSS 10.2.x)                                   |

Le point de vigilance : `B32` et `B33` sont volontairement contradictoires à première lecture.
Ce ne sont pas des règles en conflit — `B32` décrit ce que l'hôte **peut** configurer, `B33`
décrit ce qu'il obtient **sans rien configurer**. Une règle qui autorise et une règle qui
présument ne s'annulent pas ; si elles semblaient contradictoires, c'est qu'un mot
manquerait entre les deux.

**Raison d'être de l'enrichissement.** Le PRD ne nommait aucune action : il parlait de « droits »
en prose. La question « faut-il séparer deux droits ? » était donc littéralement **inposable** :
sans nom, pas de séparation exprimable. Le § 4.1 a été ajouté pour rendre la réponse possible,
et il sert désormais à toutes les questions de délégation, pas seulement à celle-ci.

---

## Checklist de gate

- [x] Le problème est défini de manière concrète, pas en jargon.
- [x] Tous les types d'utilisateurs sont identifiés, y compris administrateur et mainteneur.
- [x] Chaque user story a des critères d'acceptation vérifiables.
- [x] Chaque règle métier a un ID stable (`B1`–`B37`), sans doublon ni trou.
- [x] Chaque cas limite identifié a un ID stable (`E1`–`E18`), sans doublon ni trou.
- [x] Chaque contrainte a un ID stable (`C1`–`C12`), sans doublon ni trou.
- [x] Les exigences non fonctionnelles couvrent performance, sécurité et accessibilité.
- [x] Les risques et inconnues sont listés.
- [x] Le hors périmètre est explicite.
- [x] Le PRD a été comparé à au moins deux produits de référence existants
      (`.forge/benchmarks.md`), et 4 règles en sont issues.
- [x] § 12 : **11 points, 11 tranchés.** Le onzième (`journal:read`) a produit le § 4.1 et les
      règles `B31`–`B35` ; il a été tranché après approbation, ce qui a modifié le PRD.

> **Le statut de ce document ne se lit pas ici.** Il vit dans `.forge/state.json`, qui est
> l'autorité, et dans le front matter ci-dessus, qui en est le miroir. Un statut écrit dans le
> corps deviendrait faux dès la première mise à jour : deux représentations du même fait, aucune
> ne réconciliée.