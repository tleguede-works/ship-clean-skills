---
type: audit-report
status: open
generated_at: 2026-09-29
---

# Rapport de test — agents Forge v2 (`quality-analyst`, `red-team`)

> Test des **4 corrections** du contrat d'agent, sur le premier artefact où elles weren't en jeu :
> `.forge/plans/slice-config.md` (v3), tentative 3.
>
> Version corrigée : `%TEMP%\forge-agents-fix\*.v2.md` — **hors dépôt**, rien n'est commité tant
> que la correction n'est pas validée.
>
> Périmètre volontairement inchangé : le PRD **n'a pas** été fourni. C'est le protocole actuel du
> skill, et c'est incorrect (INC-010). Le but du test est de mesurer ce que ce protocole ne voit pas.

---

## 1. Verdict brut

| Agent                | Verdict   | Findings                                     | `unreadable_without` non vide | `prior_critical_resolved` |
| -------------------- | --------- | -------------------------------------------- | ----------------------------- | ------------------------- |
| `quality-analyst` v2 | **BLOCK** | 4 major · 10 minor                           | **oui**                       | —                         |
| `red-team` v2        | **BLOCK** | **1 critical** · 6 major · 11 minor · 3 info | **oui**                       | **`true`**                |

**Les deux plans n'ont pas passé.** Mais la question posée n'était pas « le plan passe-t-il » —
c'était « les validateurs corrigés fonctionnent-ils ». La réponse est **oui**, sur les quatre points.

---

## 2. Correction 3 — `unreadable_without` non vide ⇒ `BLOCK`

**Fonctionne.** Preuve : les deux agents ont rendu `BLOCK` **sans finding `critical` chez
`quality-analyst`**, et en motivationnant par l'absence de périmètre :

> _« Les trois décisions de réduction de périmètre du § 12 reposent sur des affirmations
> **négatives** sur le contenu du PRD — "`columns` n'est borné par aucune règle", "le comportement
> d'un `filter` n'est défini nulle part", "`B13` l'exige et rien ne dit où ça s'implémente".
> **Si l'une est fausse, la slice a du comportement spécifié silencieusement retiré.** C'est
> l'incapacité centrale de cette revue. »_

**Pourquoi c'est le résultat le plus utile du test.** Il ne dit pas seulement « je n'ai pas pu
lire ». Il **énonce ce que sa cécité lui fait perdre** — et ce que je perdais en asserting trois
négativités sans les vérifier. La v1 des agents aurait rendu un `REVISE` de qualité sur des
références invérifiables, et l'aurait fait sans le dire.

**Gain secondaire, non prévu :** les deux agents ont explicitement **séparé** ce que le PRD aurait
attrapé de ce qui est faux indépendamment. `quality-analyst` :

> _« Les 4 `major` ci-dessus sont internes à l'artefact et donc **indépendants** de la withholding
> du PRD : ils se corrigeraient en un tour. »_

Cette ligne rend le rapport exploitable au lieu de paralysant : elle dit que le PRD aurait attrapé
**zéro** de ces défauts, et que le plan est donc indépendamment non conforme.

---

## 3. Correction 4 — `severity: info` pour un constat de résolution

**Fonctionne.** `red-team` v2 a vérifié le `critical` de la tentative 2 et l'a rendu **sans le
repromouvoir en `critical`** :

```json
{
  "severity": "info",
  "problem": "Le `critical` de la tentative 2 est mort : plus aucun bloc de code ne contient
  `migrate`, `MIGRATION_STEPS`, `MIN_VERSION` ni `validateStrict`. Aucune branche de migration
  ne subsiste.",
  "required_change": "Aucune. Constat de résolution, consigné ici et non promu en `critical`.",
  "prior_critical_resolved": true
}
```

**Preuve que ça change quelque chose.** Sans cette correction, ce constat aurait été un `critical`
— et le tour se serait soldé par un `BLOCK` sur un bug **déjà corrigé**. C'est exactement ce qui
s'est passé en v2 : un `critical` dont le texte disait « aucune correction requise ». Le format ne
supportait ni la confirmation ni le défaut pour le même champ. Le champ `prior_critical_resolved`
est un ajout propre : il rend la résolution **lisible sans être lisible comme un défaut**.

---

## 4. Corrections 1 et 2 — périmètre fourni par l'appelant

**Non testés comme tels, et c'est une limite de ce test.** Pour que la correction soit
éprouvable, il faudrait fournir `derived_from` résolu — mais on"Thenait àReproduire le protocole
actuel pour mesurer son angle mort. **Verdict : le test a validé 3 et 4 ; 1 et 2 restent à
éprouver** quand le périmètre sera effectivement fourni.

Ce que l'on sait déjà, parce que c'est mesurable sans agent : `state.json → slices.config` ne
contient pas de champ `derived_from` (INC-010, action 2). Donc même en appliquant la règle de
`fast-track.md`, l'agent n'a aujourd'hui **aucun moyen mécanique** de connaître son périmètre.

---

## 5. Ce que les v2 ont trouvé que les v1 n'auraient pas trouvé

Indépendamment du périmètre, la v2 a trouvé **1 `critical` neuf** que ni `quality-analyst` ni les
deux tours précédents n'avait vu. Il est interne à l'artefact — le PRD n'aurait rien|Apporté.

> **Les messages interpolent un `id` fourni par l'utilisateur, et `ID_PATTERN` accepte les cinq
> jetons que l'invariant `B13` interdit.** `{ params: [{ id: "sql", appliesTo: ["inconnu"] }] }` est
> une configuration **valide**, et produit « le paramètre **sql** vise un indicateur inconnu ».

C'est-à-dire : **le code du plan viole la seconde moitié de `B13` que je venais d'écrire, et
l'interdit dans un test situé à 40 lignes de là.** Le test d'invariant adversarial que la v2
recommande aurait attrapé exactement cela. C'est la démonstration la plus nette qu'un validateur
qui **lit** le plan bat un validateur qui **le parcourt**.

Deux autres défauts confirmés par les **deux** agents indépendamment — la convergence reste le
meilleur signal de fiabilité :

| Défaut                                                                                                                                                                                                           | Trouvé par |
| ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ---------- |
| `REGLE_PAR_CHEMIN[issue.path[0]]` ne lit que le segment **racine** : `rank: 60` résout vers `B27` au lieu de `B19`. La table que j'ai écrite pour remplacer un placeholder **ne produit pas ses propres lignes** | les deux   |
| `messageEnMetier` spécifié « par code d'issue » alors que la table est indexée par **chemin** — les deux clés sont incompatibles, donc l'algorithme le plus central de `B13` n'est pas implémentable             | les deux   |
| `label` décrit comme `scalarSchema` en § 6.1 alors que le code dit `z.string().max(120)`                                                                                                                         | les deux   |
| Le § 11.7 grep ne matche pas `…` (U+2026) — et le critère § 10 utilise `{ sql: "…" }` comme fixture, **non exécutable**                                                                                          | les deux   |

> **Les `…` et `<…>` de ce rapport sont volontaires** : ce sont les marqueurs que je traque, cités
> pour montrer ce qu'ils ressemblent. Un contrôle large appliqué ici les signale — c'est attendu, et
> c'est la démonstration que le motif doit être jugé ligne à ligne, pas compté.

> **Contrôle appliquée à ce rapport, et il a trouvé 3 occurrences.** Toutes supprimées sauf deux,
> volontairement conservées et signalées ci-dessus. Un rapport de test qui ne s'applique pas son
> propre contrôle n'est pas un rapport de test.

---

## 6. Le trou que la réduction de périmètre a ouvert

`red-team` a trouvé une contradiction de propriété que **je n'avais pas vue** et qui est
structurelle :

> `config` déclare une **racine `.strict()`** — donc un ensemble de champs **fermé**. § 11.1 affirme
> qu'un `layout` / `columns` doit être **rejeté**. Mais § 12 confie `layout` et `columns` à
> `slice disposition`, qui devra porter ces champs **dans le même `ViewConfig`**. Le plan ne dit
> nulle part comment une slice peut étendre un schéma qu'une autre déclare fermé, ni **à qui
> appartient `ViewConfig`** après cette extension.

Aggravant : § 4.3 nomme `wizard-etape-3-disposition` comme consommateur — **l'étape dont les
données viennent d'être retirées**.

C'est un défaut créé par la décision de réduire le périmètre, pas par le plan précédent. Il n'est
**corrigeable ni par le PRD ni par les validateurs** : c'est une décision d'architecture.
`ViewConfig` doit avoir un propriétaire explicite, et la racine doit être soit fermée avec
`disposition` dans une clé voisine (`{ config, disposition }`), soit extensible de façon contrôlée.

Le même genre de trou existe sur `version: z.literal(CURRENT_VERSION)` : champ **requis**, **aucun
test**, **aucun propriétaire**, alors que `B5`/`B6`/`B24` sont déclarés hors périmètre avec
propriétaire `publication`. `config` fige la version ; `publication` possède le versionnement.

---

## 7. Conclusion du test

| Correction                               | Verdict                                                                                  |
| ---------------------------------------- | ---------------------------------------------------------------------------------------- |
| 1 — périmètre par `derived_from` résolu  | **non éprouvé** (dépend de l'action 2 d'INC-010)                                         |
| 2 — périmètre fourni par l'appelant      | **non éprouvé**, mais la lacune est confirmée : `state.json` ne porte pas `derived_from` |
| 3 — `unreadable_without` ⇒ `BLOCK`       | **fonctionne**, preuve § 2                                                               |
| 4 — `severity: info` pour une résolution | **fonctionne**, preuve § 3                                                               |

**Recommandation : appliquer 3 et 4 au skill.** Elles sont éprouvées, elles ne dépendent d'aucune
autre action, et 4 a prevented un faux `BLOCK` sur ce test même.

**1 et 2 : appliquer en même temps que l'action 2 d'INC-010** (propager `derived_from` dans
`state.json` à l'enregistrement). Les énoncer sans le support mécanique reproduirait exactement le
défaut qu'on cherche à corriger — une règle qu'un agent ne peut pas appliquer mécaniquement.

**Ne pas appliquer 3 et 4 sur ce projet seul.** Elles ont été éprouvées sur **un** artefact, avec
**un** jeu de findings. Elles doivent être vérifiées sur les 10 slices restantes avant d'être jugées
fiables — sinon nousünk aurions généralisé sur un échantillon de 1, ce qui est exactement le genre
de conclusion que ce projet a passé la session à éviter.
