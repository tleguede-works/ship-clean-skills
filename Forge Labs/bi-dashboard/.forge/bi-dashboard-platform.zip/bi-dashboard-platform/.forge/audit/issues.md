---
type: audit-issues
status: open
generated_at: 2026-09-29
---

# Journal d'incidents — Plateforme BI configurable

> Ce fichier est le **journal de bord des problèmes rencontrés pendant l'exécution de Forge**.
> Il est destiné à être lu, pas juste archivé.
>
> Deux usages :
>
> 1. **Pendant le projet** — comprendre et corriger un blocage en cours de route.
> 2. **Après le projet** — alimenter l'amélioration du skill lui-même. `scripts/audit-report.js`
>    agrège ces incidents et les journaux d'audit de plusieurs projets pour faire apparaître
>    les **récurrences**.
>
> Un incident qui n'est pas écrit n'a pas eu lieu. C'est la seule donnée qui permet
> d'améliorer Forge au fil des projets.

---

## Convention

| Champ       | Valeurs                                                                                                        |
| ----------- | -------------------------------------------------------------------------------------------------------------- |
| **Gravité** | `bloquant` (a empêché d'avancer) · `majeur` (a coûté du temps ou du contournement) · `mineur`                  |
| **Origine** | `forge` (faiblesse du skill) · `projet` (spécification insuffisante) · `environnement` (outil, réseau, modèle) |
| **Phase**   | `0` … `8`                                                                                                      |

**L'origine est le champ le plus important.** C'est lui qui distingue « Forge a mal guidé » de « le PRD était ambigu ». Un skill qui s'améliore est un skill qui sait compter ses propres échecs.

---

## Incidents

<!-- Un bloc par incident, du plus récent au plus ancien. -->

### INC-010 — Le validateur Fast Track est privé du PRD, et deux fichiers du skill se contredisent

- **Date** : 2026-09-29T15:40:00Z
- **Gravité** : majeur
- **Origine** : forge
- **Phase** : 5
- **Symptôme** : les deux validateurs ont rendu `unreadable_without` listant `.forge/prd.md`,
  `.forge/architecture.md` et `.forge/conventions.md`. Ils ne pouvaient pas vérifier qu'un `B*` cité
  disait bien ce que le plan affirmait. Or c'est **le** mode de défaillance récurrent du projet : 8
  citations fausses en session 5, 4 de plus en session 6.
- **Cause racine — une contradiction interne au skill, pas une erreur d'invocation :**
  - `references/fast-track.md` L176, tableau des limites : « Lecture d'un validateur | **l'artefact +
    son `derived_from`** ».
  - `agents/quality-analyst.md` § Inputs : « tu lis UNIQUEMENT ceci : `<artifact>`,
    `.forge/state.json` », et le PRD **seulement en Phase 6**.
  - `agents/red-team.md` § Inputs : même liste, PLUS « en cas de doute sur un ID (B*, E*, C*), lis
    le PRD **uniquement pour ces IDs** ».
- Les trois règles sont incompatibles. `red-team` a la permission la plus large (le PRD, pour les
  IDs) ; `quality-analyst` a la plus étroite (pas de PRD avant la Phase 6) ; et la limite de
  `fast-track.md` les contredit tous les deux. **Le validateur applique la règle la plus étroite qu'il
  connaît** — c'est-à-dire se priver du document dont il a le plus besoin.
- **Aggravant, et c'est ce qui rend le défaut invisible :** le plan porte bien un front matter
  `derived_from:` listant les trois fichiers, et `forge-guard` valide ce front matter. Mais
  `state.json → slices.config` **ne contient que `path`, `type`, `status`, `content_hash`,
  `updated_at`, `slice`** — aucun `derived_from`. Donc même en appliquant la règle de
  `fast-track.md`, l'agent n'a **aucun moyen mécanique** de découvrir quels fichiers lire : il doit
  deviner, ou lire le plan et hope. Un contrat qui dépend d'une lecture humaine du document qu'il
  doit valider n'est pas un contrat outillé.
- **Contournement appliqué** : passer explicitement le PRD **et** l'architecture dans le prompt de
  chaque validateur. C'est un contournement : la consigne du skill reste identique à celle que je
  donne, donc le validateur ne peut pas distinguer « j'ai le droit » de « on m'a dit que
  j'avais le droit ».
- **Action corrective** (session dédiée) :
  1. **Arbitrer la contradiction** dans un seul sens. Recommandation : lire l'artefact, son
     `derived_from` **résolu**, et `state.json`. C'est la seule règle qui serve le propos — un
     validateur qui ne peut pas lire la règle qu'il valide ne valide pas la règle.
  2. **Propager `derived_from` dans `state.json`** à l'enregistrement, sous forme de chemins déjà
     résolus. Sans cela, « son `derived_from` » est une notion que l'agent doit reconstruire.
  3. **Rendre `unreadable_without` bloquant** quand le validateur déclare ne pas avoir pu lire un
     fichier listé dans son propre périmètre : aujourd'hui il le signale et continue, donc un
     validateur aveugle rend un verdict quand même. C'est ce qui a produit un `REVISE` de qualité
     sur un plan dont la moitié des références n'étaient pas vérifiables.
  4. Aligner `red-team` et `quality-analyst` sur la même liste. La divergence actuelle est
     probablement le reliquat d'une version antérieure où le PRD n'était lu qu'en Phase 6.
- **Statut** : ouvert — contourné par consigne explicite, à corriger dans le skill

---

### INC-009 — Un `BLOCK` Fast Track sur le premier plan, et deux validateurs qui ont trouvé la même chose

- **Date** : 2026-09-29T15:05:00Z
- **Gravité** : majeur
- **Origine** : projet
- **Phase** : 5
- **Symptôme** : premier artefact validé sous Fast Track, `.forge/plans/slice-config.md`.
  `quality-analyst` → `REVISE` (9 major, 3 minor). `red-team` → **`BLOCK`** (1 critical, 8 major,
  3 minor). Le protocole impose de prendre le verdict le plus grave et **de ne pas trancher seul**.
- **Le `critical`** : l'algorithme `migrate` fait `while v < targetVersion: v = migrateStep(input, v)`
  en ne réécrivant **jamais** `input.version`. Le `parse_strict(input)` final échoue donc toujours
  sur `z.literal(1)`. **La migration est un no-op** : elle ne peut produire aucun document valide.
  Et le test « version 0 → refus » exige une branche qui n'existe pas dans l'algorithme.
- **La convergence est le fait important.** Les deux validateurs, avec des angles morts
  différents, ont trouvé **indépendamment** les mêmes défauts : `B2` tracé vers un champ `version`
  inexistant, `ConfigPolicy.maxIndicators` / `maxDescriptionLength` morts (bornes en dur dans le
  schéma), `variableRefSchema` avec une longueur minimale de 2 caractères, absence d'unicité sur
  `indicators[].id`, `z.unknown()` qui laisse passer un objet imbriqué, `B13`/`B16`/`E17` cités sans
  ligne en § 6. **Six défauts trouvés deux fois, par deux angles opposés.** Ce n'est pas du bruit :
  c'est la confirmation empirique de la règle du skill (« ils ne sont pas redondants »).
- **Cause racine** : le plan a été écrit comme une **description** de ce que le code fait, et non
  comme du code. Trois conséquences prévisibles : `.strict()` décrit en § 3 mais absent du § 2.1 ;
  `ValidationResult` cité en § 4.4 mais jamais défini ; `ConfigPolicy` déclaré configurable mais
  jamais consommé. **Un contrat écrit en prose ne se compile pas** — or le gabarit exige du code
  réel précisément pour cela.
- **Contournement** : Fast Track s'arrête, le mode revient à `guided`, escalade humaine. Journalisé
  (`fast_track_block`, `fast_track_escape`). `run.fast_track.blocked_on` conserve la position.
- **Action corrective** :
  1. Réécrire `migrate` : produire un nouvel objet portant `version = v`, ajouter
     `Number.isInteger(v)` avant toute comparaison, ajouter la branche `v < 1`.
  2. Ajouter `.strict()` **dans le § 2.1 lui-même**, pas seulement en prose.
  3. Définir `ValidationResult` en § 2.2 et l'utiliser comme type de retour explicite de
     `validateForPublication`, `config` toujours présente même en cas de refus (`B16`).
  4. Consommer `policy.maxIndicators` / `policy.maxDescriptionLength` dans l'algorithme, ou les
     supprimer du type. Un champ déclaré et jamais lu est pire qu'un champ absent.
  5. Remplacer `z.unknown()` par une **union discriminée** sur `op` (`eq` scalaire, `in` tableau
     non vide, `between` tuple de 2) et par un schéma JSON borné et récursif pour les valeurs.
  6. Ajouter l'unicité sur `indicators[].id` et `params[].id`.
  7. Trancher `B2` : soit versionner réellement la référence d'indicateur, soit corriger la ligne
     § 6.1 pour ne revendiquer que la partie « stable ».
  8. Ajouter `B3`, `B4`, `B13`, `B16`, `E17` au périmètre et à § 6, avec implémentation.
- **Statut** : ouvert — le plan doit être corrigé, puis revalidé (tentative 2/2)

---

### INC-008 — `register` est à sens unique : aucune commande pour retirer une entrée

- **Date** : 2026-09-29T15:10:00Z
- **Gravité** : mineur
- **Origine** : forge
- **Phase** : 5
- **Symptôme** : en déclarant les slices, une clé de test a été enregistrée par erreur
  (`register <root> slice probe ...`). Il n'existe **aucune commande** pour la retirer : ni
  `unregister`, ni `remove`, ni `delete`. Les 24 commandes de `state.js` ont été lues — aucune ne
  supprime une entrée de `slices`, `screens`, `foundations` ou `deliverables`.
- **Cause racine** : `cmdRegister` n'a pas de contrepartie. Le cycle de vie d'une entrée est
  asymétrique : création et mise à jour sont outillées, destruction ne l'est pas. Or
  `consistency-check: screens_have_slices` **exige** de déclarer des slices, et toute déclaration
  erronée est donc définitive.
- **Contournement** : édition manuelle de `state.json` par script Node (lecture, suppression de la
  clé, réécriture UTF-8 sans BOM). **C'est aussi une violation de la règle** « ne jamais éditer
  `state.json` à la main » — mais c'est la seule voie disponible, et une violation justifiée est
  préférable à une entrée fantôme dans l'autorité. Consigné dans `LEARNINGS.md`.
- **Coût** : faible sur le moment, mais la règle « ne pas éditer `state.json` » perd une exception
  non documentée. Une règle sans exception connue est une règle qu'on enfreint en silence.
- **Action corrective** (session dédiée) :
  1. Ajouter `state.js unregister <root> <kind> <key>`, qui refuse par défaut si la clé a des
     dépendances (une slice dont dépend une autre ne se retire pas) et journalise l'événement
     `unregister` dans `run-log.jsonl`.
  2. Refuser `register` sur une clé existante avec un chemin différent, au lieu d'écraser
     silencieusement.
  3. Faire dire à `register` ce qu'il a fait : à l'image de `set-nav`, qui **rejette silencieusement**
     les champs qu'il ne connaît pas (constaté en session 7), une commande qui écrit moins que ce
     qu'on lui demande doit le dire.
- **Note** : troisième encounters du même motif — `coverage-check` qui reconnaît mal (INC-006),
  `screens_have_slices` appliqué trop tôt (INC-007), `set-nav` qui ignore en silence. Le motif
  commun : **un contrôle ou une commande qui ne dit pas pourquoi il fait ce qu'il fait**.
- **Statut** : ouvert — contourné par édition manuelle, documentée

---

### INC-007 — `consistency-check` exige une slice pour chaque écran, mais les slices arrivent en Phase 5

- **Date** : 2026-09-29T13:50:00Z
- **Gravité** : mineur
- **Origine** : forge
- **Phase** : 3
- **Symptôme** : `consistency-check.js all` passe à `pass: false` dès le premier écran de design
  enregistré. `screens_have_slices: fail`, avec la liste des écrans sans slice. Le même contrôle
  **saute** six autres vérifications en annonçant honnêtement « Phase 4/5 non atteinte ».
- **Cause racine** : la règle est juste — _« un écran de design sans slice ne sera jamais
  implémenté, c'est le trou de la décomposition »_ — mais elle est appliquée **au moment de
  concevoir** l'écran, alors qu'une slice ne peut exister qu'en Phase 5. Le contrôle a la bonne
  exigence et la mauvaise fenêtre de temps.
- **Aggravant** : l'incohérence est interne au contrôle. Six vérifications reconnaissent que leur
  moment n'est pas arrivé et **`skip`** ; `screens_have_slices` ne le fait pas et échoue. Un agent qui
  ne lit pas le code en déduit que les écrans de design exigent des slices en Phase 3 — et pourrait
  être tenté d'en inventer une.
- **Contournement** : concevoir les écrans normalement, sans leur attacher de slice. Vérifier à la
  **Phase 5** que chaque écran de design est bien couvert par une slice — c'est là que la règle
  devient applicable et-production. Le contrôle ne doit pas être contourné en Phase 3 mais respecté
  en Phase 5 ; ne pas le « faire passer » en déclarant des slices vides.
- **Action corrective** (session dédiée) :
  1. **Conditionner la vérification à l'existence de slices** : s'il n'y a aucune slice déclarée,
     `skip('screens_have_slices', 'aucune slice déclarée (Phase 5 non atteinte)')` — exactement ce que
     font déjà les six autres.
  2. À défaut de condition, distinguer deux états : _aucun écran sans slice parce qu'il n'y a pas
     encore de slices_ (neutre) et _des écrans sans slice alors que des slices existent_ (échec
     réel). Le second est un trou de décomposition ; le premier n'est pas une faute.
  3. Le correctif rejoint celui d'INC-006 : faire dire au contrôle **pourquoi** il attend au lieu
     d'échouer en silence.
- **Statut** : ouvert — non corrigé, contourné par abstinence (règle reportée à la Phase 5)

---

### INC-006 — `coverage-check prd` cherche des sections anglaises dans un PRD francophone

- **Date** : 2026-09-29T13:40:00Z
- **Gravité** : majeur
- **Origine** : forge
- **Phase** : 3
- **Symptôme** : `coverage-check.js prd <racine>` renvoie `pass: false` avec deux échecs :
  - `section_edge_cases: fail` — « Section "Edge cases" MISSING from PRD »
  - `section_hors_scope: fail` — « Section "Hors scope" MISSING from PRD »
    Le PRD contient **les deux sections**, complètes : `## 6. Cas limites` (18 lignes `E1`–`E18`) et
    `## 9. Hors périmètre (explicite)` (10 exclusions argumentées). Rien ne manque.
- **Cause racine** : `coverage-check.js:166-167` teste des littéraux anglais (`'Edge cases'`,
  `'Hors scope'`) contre un document dont les titres sont en français. Le contrôle ne distingue pas
  « section absente » de « section présente sous un autre nom ».
- **Aggravant** : même famille qu'INC-004, mais **plus grave**, parce que le résultat est un `fail`
  et non un `0` trompeur. Un `pass: false` invites à **corriger le PRD** — donc à ajouter des
  sections anglaises en doublon, ou à croire le document incomplet. Le contrôle pousse à la
  mauvaise correction. `consistency-check` et `forge-guard` passent, eux, ce qui rend l'échec d'autant
  plus déroutant.
- **Contournement** : ne pas ajouter de section anglaise au PRD. Vérifier manuellement que `## 6. Cas
limites` et `## 9. Hors périmètre` existent, et **ignorer** le verdict de ce contrôle tant qu'il
  n'est pas corrigé. Le PRD est correct ; c'est le contrôle qui est faux.
- **Action corrective** (session dédiée) :
  1. **Accepter les libellés français** : `Edge cases|Cas limites`, `Hors scope|Hors périmètre`.
  2. **Rendre l'échec informatif plutôt que bloquant** quand une section est trouvée sous un nom
     différent : « section `## 6. Cas limites` présente, libellé attendu `## Edge cases` non
     reconnu ». C'est le même correctif que le point 3 d'INC-005, et les deux contrôles devraient le
     partager.
  3. Distinguer les deux intentions : « cette section manque-t-elle vraiment ? » doit être
     distingué de « cette section est-elle reconnue sous ce libellé ? ». Les confondre produit un
     échec sur un document correct — c'est-à-dire un **faux positif présenté comme un défaut**.
- **Note** : troisième membre de la même famille (`INC-003` contrôle muet, `INC-004` compteur faux,
  `INC-006` verdict faux). Le motif commun : un contrôle qui ne dit pas **pourquoi** il échoue
  oblige à décider si le défaut est dans l'outil ou dans le document, et le doute se paie à chaque
  fois.
- **Statut** : ouvert — non corrigé, contourné par abstinence (verdict ignoré, PRD inchangé)

---

### INC-005 — `read_only` n'est pas modifiable, et il protège plus qu'il ne le paraît

- **Date** : 2026-09-29T12:10:00Z
- **Gravité** : majeur
- **Origine** : forge
- **Phase** : 4 (découvert en Phase 2, arbitré en Phase 4)
- **Symptôme** : l'ADR-006 devait ouvrir une exception d'écriture sur `ace3i-bankingsms-ui` (pilote du MVP). Deux obstacles :
  1. `state.js:303` écrit `read_only: true` en dur dans `reference_projects` à l'`init`, et **aucune commande** ne permet de le basculer ensuite. Le seul moyen de l'ouvrir est donc d'éditer `state.json` à la main — ce qu'interdit `AGENTS.md`.
  2. `forge-guard.js:130-131` utilise `reference_projects` pour **ignorer** tout livrable Forge trouvé dans une référence (`ignored_in_reference_projects`). Passer `read_only: false` déterrait ce garde-fou : un `.md` de Forge déposé par accident dans `ace3i-bankingsms-ui` cesserait d'être signalé.
- **Cause racine** : `read_only` n'est pas qu'un **libellé**, c'est un **donnée de contrôle** consommée par `forge-guard`. Le nom suggère un simple marqueur documentaire ; il pilote en réalité un comportement de vérification. Aucune commande ne permet de distinguer « référence en lecture seule » de « référence modifiée sous exception », parce que le modèle n'a qu'un booléen là où il faudrait trois états.
- **Contournement** : exception **documentaire** (ADR-006) — `state.json` reste `read_only: true`, l'exemption est écrite dans `AGENTS.md`, `DECISIONS.md`, `conventions.md` et `SESSION_LOG.md`. La protection de `forge-guard` reste armée.
- **Coût** : l'exception n'est pas dans la machine. Un agent qui ne lit que `state.json` croira `ace3i` intouchable ; un agent qui ne lit pas l'ADR-006 croira le contraire. **Les deux lectures sont incomplètes**, et c'est le prix explicite du choix.
- **Action corrective** (session dédiée) :
  1. **Ajouter une commande** `state.js unprotect <root> <ref>` qui bascule `read_only` enjournalant qui l'a demandé et quand, et qui **prévient** que `ignored_in_reference_projects` sera désactivé pour cette référence.
  2. **Remplacer le booléen par un statut** : `read_only` → `mode: "readonly" | "protected" | "writable"`, où `protected` signifie « écriture autorisée sous exception nommée, garde-fou de livrables conservé ». C'est l'état qui manque.
  3. **Faire remonter le risque dans la sortie** : quand une référence est `writable`, `forge-guard` devrait signaler qu'il n'ignore plus ses livrables, au lieu de le faire silencieusement.
- **Note** : même famille qu'INC-003. Un contrôle qui agit sans prévenir n'est pas un contrôle, c'est un effet de bord ; ici il **désarme** la protection au lieu de l'exercer.
- **Statut** : ouvert — non corrigé, contourné par une exception documentaire (ADR-006)

---

### INC-004 — `state.js` lit la mémoire du projet en anglais, le projet l'écrit en français

- **Date** : 2026-09-29T11:05:00Z
- **Gravité** : majeur
- **Origine** : forge
- **Phase** : 0
- **Symptôme** : `state.js start` rapporte `dod_items: 0`, `escalation: false` et `learnings: 0`, alors que `AGENTS.md` contient une Définition de Done structurée, une section Escalade, et que `LEARNINGS.md` contient **5 corrections réelles**. Aucune alerte n'accompagne ces zéros : la sortie a l'air d'une mesure, pas d'un échec de lecture.
- **Cause racine** : `scripts/state.js` cherche des ancres **anglaises** dans des documents projet.
  - L. 861 — `agents.match(/## Definition of Done([\s\S]*?)\n## /)` vs `## Définition de Done`
  - L. 862 — le décompte des items DoD dépend de cette ancre, donc reste à 0
  - L. 863 — `agents.match(/## Escalation Rules([\s\S]*?)\n## /)` vs `## Escalade`
  - L. 884 — `learnings.match(/^- \d{4}-\d{2}-\d{2}\s*:/gm)` exige un **deux-points** après la date ; le format réel est `- AAAA-MM-JJ — …` (tiret cadratin), imposé par `LEARNINGS.md` lui-même
  - L. 888 — `learnings_placeholder` ne peut donc jamais signaler un store vide, sa condition n'est jamais remplie
- **Aggravant** : `LEARNINGS.md` § Format impose `- AAAA-MM-JJ — …`, format que `state.js` ne sait pas lire. Le fichier et son parseur se contredisent **à l'intérieur du même skill** — ce n'est donc pas seulement un défaut d'accent.
- **Coût** : un `dod_items: 0` cité comme un fait dans `DECISIONS.md` ADR-004, sans vérification. J'ai conclu que la mémoire du projet était vide alors qu'elle est pleine. Risque le plus élevé de l'incident : **un compteur faux qui se lit comme une mesure** détruit la confiance dans tous les autres chiffres de la même sortie, y compris les vrais.
- **Contournement** : aucun — le skill n'est **pas** modifié (décision utilisateur : le skill est un actif partagé, à améliorer dans une session dédiée). Les compteurs `state.js start` sont donc à considerer comme non fiables sur ce dépôt, et toute citation issue d'eux doit être vérifiée par lecture directe du fichier.
- **Action corrective** (session dédiée, hors de ce projet) :
  1. **Accepter les deux langues** dans les ancres : `## (Definition of Done|Définition de Done)` et `## (Escalation Rules|Escalade)`, idem pour `no entries yet|aucune entrée`.
  2. **Aligner la regex des corrections** sur le format réellement documenté (séparateur flexible `[-—–:]` après la date), ou normaliser un seul des deux formats. Choisir **un** sens, pas les deux — sinon la même ambiguïté revient ailleurs.
  3. **Signaler, plutôt que compter juste** : quand une section attendue est **trouvée mais non reconnue**, dire « section `## Escalade` présente, ancre attendue `## Escalation Rules` non reconnue ». C'est le correctif le plus utile des trois : c'est lui qui aurait attrapé ce défaut immédiatement, au lieu de laisser un `0` silencieux.
  4. Éviter le piège symétrique : un décompte écrit en dur dans un document (`adrs_claimed_in_agents_md`, L. 877) devient faux au même titre qu'un décompte calculé faux.
- **Note** : le point 3 est le même défaut de famille qu'INC-003 — **un contrôle jamais vu échouer n'est pas validé, il est inconnu**. Ici le contrôle n'échoue jamais, il est simplement muet.
- **Statut** : ouvert — non corrigé, contourné par abstinence (les compteurs ne sont pas cités)

---

### INC-003 — Un contrôle de corruption « vert » sans avoir jamais été vu échouer

- **Date** : 2026-09-29T09:40:00Z
- **Gravité** : majeur
- **Origine** : environnement
- **Phase** : 0
- **Symptôme** : deux contrôles successifs ont déclaré « 0 problème » sur des fichiers pourtant corrompus. (a) `Get-Content -Raw` combiné à une regex `\u` en PowerShell ne matchait rien. (b) Une fois le scan porté en Node avec des plages CJK, `.opencode/rules/accessibility.md` est sorti propre alors qu'il contenait `_USERNAMEOục` — `U+1EE1`, Latin Extended Additional, hors des plages CJK testées. Le troisième caractère parasite (`diverge阈ront` dans `DECISIONS.md`) n'a été trouvé qu'après passage à une détection par liste blanche. <!-- unicode-scan:ignore (les caractères cités sont l'objet même du constat) -->
- **Cause racine** : le contrôle a été conçu sur l'hypothèse « la corruption est CJK », alors que le mode de défaillance réel est « un caractère unique et plausible hors contexte ». Corréler le contrôle au mode d'échec observé au lieu de le couvrir entièrement.
- **Contournement** : réécriture du scan en Node avec une **liste blanche** de plages autorisées pour un dépôt francophone (Latin-1, Latin Extended-A, ponctuation, symboles, emoji) et un repli `OutOfContext` pour tout le reste. Ajout d'un auto-test (`scan-selftest.cjs`) qui écrit des fichiers volontairement corrompus (Latin étendu, CJK, hébreu, BELL, BOM) et un cas négatif (français normal + citation annotée). Le scan n'est crédible qu'après l'avoir vu accrocher 5 cas sur 5 et laisser passer les 2 cas propres.
- **Coût** : deux faux verts successifs, dont un qui a donné une fausse assurance sur 12 fichiers. Le second aurait pu laisser un document corrompu passer jusqu'à la Phase 5.
- **Action corrective** : pour tout contrôle ajouté (`forge-guard.js`, lint, gates), exiger un auto-test négatif dans le même lot. Un contrôle qui n'a jamais été vu échouer n'est pas validé, il est inconnu.
- **Statut** : corrigé

---

### INC-002 — Caractère CJK parasite injecté dans `conventions.md`

- **Date** : 2026-09-29T09:12:00Z
- **Gravité** : mineur
- **Origine** : environnement
- **Phase** : 0
- **Symptôme** : la rédaction de `.forge/conventions.md` a produit la phrase « l'état de configuration d'un widget en cours d'édition est local au wizard et焦 est sérialisable » — un caractère CJK unique inséré au milieu d'une phrase française, remplaçant la virgule attendue. <!-- unicode-scan:ignore (la citation du défaut est intentionnelle) -->
- **Cause racine** : le projet de référence `ace3i-bankingsms-ui` documente un historique du même type de corruption (caractères BELL `0x07` en tête de ligne dans `docs/slices/`, `CJK=0` en contrôle de recette). Le défaut est donc **récurrent à l'échelle de l'environnement de génération**, pas propre à un fichier.
- **Contournement** : correction manuelle du caractère, puis scan de contrôle sur le fichier livré : `CJK=0 Replacement=0 Control=0` sur 263 lignes.
- **Coût** : 1 aller-retour de lecture/édition ; risque non nul de transmission d'un document de conventions vers les plans de Phase 5.
- **Action corrective** : Forge pourrait imposer un scan Unicode optionnel dans `forge-guard.js` (`unicode-scan`) sur les livrables, sur le modèle de ce que le projet de référence applique manuellement.
- **Statut** : corrigé

---

### INC-001 — Scripts Forge inopérables depuis un dépôt `"type": "module"`

- **Date** : 2026-09-29T09:05:00Z
- **Gravité** : bloquant
- **Origine** : forge
- **Phase** : 0
- **Symptôme** : `node scripts/state.js anchor <racine>` échoue immédiatement avec `ReferenceError: require is not defined in ES module scope`. Le skill vit dans `.agents/skills/forge/` du projet `ace3i-bankingsms-ui`, dont le `package.json` déclare `"type": "module"`. Tous les scripts Forge sont en CommonJS (`require`, `__dirname`) mais portent l'extension `.js` : Node les interprète comme ESM.
- **Cause racine** : les scripts du skill ne déclarent pas leur propre contexte de module. Ils héritent du `package.json` le plus proche, qui peut être un projet ESM. Le `package.json` du skill lui-même (ou une extension `.cjs`) est absent.
- **Contournement** : copie du dossier `scripts/` vers `%LOCALAPPDATA%\Temp\opencode\forge-scripts` avec un `package.json` neutre (`"type"` absent), puis exécution depuis cette copie. Le skill d'origine n'a pas été modifié.
- **Coût** : 2 commandes + un contournement non documenté à rejouer à chaque invocation. Toute commande launched depuis le cwd du projet de référence échoue.
- **Action corrective** : renommer les scripts en `.cjs` (`state.cjs`, `forge-guard.cjs`, …) et documenter les chemins dans `SKILL.md`. À défaut, ajouter un `package.json` `{"type":"commonjs"}` à la racine du skill.
- **Résolution** : le skill a été installé **localement** dans ce dépôt
  (`.agents/skills/forge/`), ce qui évite de modifier le projet de référence `ace3i-bankingsms-ui`
  déclaré lecture seule. Le correctif recommandé a été appliqué à la copie locale : ajout du seul
  fichier `.agents/skills/forge/scripts/package.json` contenant `"type": "commonjs"`. Aucun script
  existant n'a été modifié. Vérifié : `state.js start`, `forge-guard.js all`,
  `consistency-check.js all` et `state.js sync` s'exécutent désormais **en place**, sans copie
  temporaire.
- **Statut** : corrigé

---

## Récurrences observées

> À remplir en fin de projet : quels schémas d'incident se répètent ?

| Schéma                                     | Occurrences                                                                       | Phase   | Cause commune                                       |
| ------------------------------------------ | --------------------------------------------------------------------------------- | ------- | --------------------------------------------------- |
| Scripts CJS dans un hôte ESM               | 1 (mais touche **tous** les scripts du skill)                                     | 0       | Absence de `type` propre au skill                   |
| Caractère parasite dans un document généré | 3 <!-- unicode-scan:ignore (les caractères cités sont les données du constat) --> | 0 / n/a | Artefact de génération ; contrôle conçu trop étroit |
| Contrôle « vert » jamais vu échouer        | 2 (PowerShell, puis Node à plages CJK)                                            | 0       | Contrôle corrélé au seul mode d'échec observé       |

---

## Améliorations proposées pour Forge

| #   | Proposition                                                                                                                                                                                                  | Origine          | Impact estimé                                                         |
| --- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ | ---------------- | --------------------------------------------------------------------- |
| 1   | Passer les scripts en `.cjs`, ou **intégrer le `package.json` `{"type":"commonjs"}` au skill publié** — le correctif n'existe aujourd'hui que dans les copies locales, il ne survit pas à une réinstallation | INC-001          | fort — débloque l'outillage dans tout projet ESM                      |
| 2   | Ajouter un garde-fou `unicode-scan` (liste blanche, auto-test négatif obligatoire) dans `forge-guard.js`                                                                                                     | INC-002, INC-003 | moyen — protège les livrables contre un défaut récurrent              |
| 3   | Exiger pour **tout** nouveau contrôle un cas négatif dans le même lot de livraison                                                                                                                           | INC-003          | fort — un contrôle jamais vu échouer n'est pas validé, il est inconnu |

---

## Ce qui a bien fonctionné

> Utile autant que les problèmes : empêche de casser ce qui marche lors d'une évolution du skill.

| Élément                          | Commentaire                                                                                                                                                                                                         |
| -------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `state.js anchor`                | A correctement résolu le nouveau dossier vide comme projet neuf (`source: cwd`, aucune remontée) au lieu d'ancrer sur un projet voisin. La règle « un répertoire vide ne remonte pas » fait exactement son travail. |
| `--reference`                    | L'anchor refuse explicitement de se poser sur un projet de référence. La déclaration d'`ace3i-bankingsms-ui` en lecture seule est maintenant protégée mécaniquement.                                                |
| `register` + garde-fou de chemin | `.forge/conventions.md` a été enregistré sans divergence statut ; le rejet hors `.forge/` est en place.                                                                                                             |

---

## Checklist de gate

- [x] Tout incident `bloquant` ou `majeur` est écrit avec sa cause racine.
- [x] Chaque incident a une **origine** (`forge` / `projet` / `environnement`).
- [x] Les incidents d'origine `forge` ont une action corrective formulée.
- [x] Les récurrences sont identifiées.
- [x] Le journal d'audit machine (`run-log.jsonl`) est cohérent avec ce fichier.
