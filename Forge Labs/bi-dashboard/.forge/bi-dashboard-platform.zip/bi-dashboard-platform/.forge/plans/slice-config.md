---
type: implementation-plan
slice: config
module: config
status: draft
generated_at: 2026-09-29
derived_from:
  - .forge/prd.md
  - .forge/architecture.md
  - .forge/conventions.md
conventions_ref: .forge/conventions.md
---

# Plan d'implémentation — `config`

> Vague 0, sans dépendance. Ce contrat **ne change pas** après cette slice.
>
> **Version 3 — périmètre réduit.** Les deux validateurs Fast Track ont consommé le budget de
> tentatives (2/2) et renvoyé `REVISE` à chaque tour. Le signal est explicite dans le skill : au-delà
> de deux tentatives, **le problème est en amont du plan**. Il l'était — pas sur la forme, mais sur
> la **frontière de la slice**.
>
> Ce qui a été **sorti** de cette slice, et où :
>
> | Sorti de `config`                           | Vers où                  | Pourquoi                                                                                                                                                                                             |
> | ------------------------------------------- | ------------------------ | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
> | `migrate`, `MIGRATION_STEPS`, `MIN_VERSION` | `slice format-migration` | Une seule version existe. Un moteur de migration sans migration est du code qui ne sert jamais, et ses branches sont **inatteignables donc non testables**.                                          |
> | `disposition` (`layout`, `columns`)         | `slice disposition`      | La disposition est un sujet de conception, pas de format. Aucune règle du PRD ne borne `columns`.                                                                                                    |
> | `params[].kind` (`period` / `filter`)       | `slice params`           | Le PRD dit « plusieurs paramètres communs » (US-9) mais **ne définit pas le comportement** d'un paramètre `filter`. Un champ dont le comportement n'est spécifié nulle part ne peut pas être validé. |
> | Politique « refus sans code technique »     | **PRD — à trancher**     | `B13` l'exige et **rien ne dit où ça s'implémente**. Ce n'est pas une propriété de schéma : c'est une politique de production de messages.                                                           |
>
> Ce qui reste est **entièrement spécifié** et vérifiable aujourd'hui. Voir § 12 pour le contrat
> complet de ce qui a été sorti.

---

## Sources

- **PRD** : `.forge/prd.md` — règles `B1`, `B2`, `B3`, `B4`, `B13`, `B16`, `B19`, `B26`, `B27` · edge cases `E10`, `E17`
- **Architecture** : `.forge/architecture.md` — entité `ViewConfig`, ADR-003, ADR-010, ADR-012
- **Conventions** : `.forge/conventions.md` — § Stack (Zod), § Tests (ADR-011)

## 1. Résumé de la slice

Cette slice définit **le schéma d'une vue** : ce qu'elle contient, ce qu'elle ne peut pas contenir,
et comment on la valide. Elle ne produit aucun écran, aucun appel réseau, aucune écriture, **et ne
migre rien** — il n'existe qu'une version.

Le format ne contient **jamais** de clé non déclarée (`B19`, ADR-003) : c'est une propriété du
schéma, vérifiable par un test, pas une intention. Sur les **valeurs**, le contrat est plus étroit
et le dit : des scalaires et des listes de scalaires, dans une famille fermée. La section § 7 porte
la limite exacte de cette promesse.

**User stories couvertes** : US-2 (Créer une vue — étape 1, informations)
**Règles métier couvertes** : `B1`, `B2`, `B3`, `B4`, `B13`, `B16`, `B19`, `B26`, `B27`
**Edge cases couverts** : `E10`, `E17`
**Hors périmètre** : `B5`, `B6`, `B24` (versionnement — slice `publication`), `B10`/`B11`/… (voir § 12)

---

## 2. Contrats de données (code)

### 2.1 Schémas de validation

```ts
// src/core/config/variables.ts
import { z } from "zod";

/** Longueur 1 à 64. Source unique : réutilisée par tous les identifiants. */
export const ID_PATTERN = /^[a-z0-9][a-z0-9_-]{0,63}$/;
export const idSchema = z.string().regex(ID_PATTERN, "Identifiant invalide");

/** B4 : liste fermée. Un agrégat non supporté par l'hôte est INVALIDE, pas ignoré. */
export const AGGREGATIONS = ["sum", "count", "avg", "min", "max"] as const;
export type Aggregation = (typeof AGGREGATIONS)[number];

/** B3 : un nom de variable MÉTIER. Le point est interdit par la regex : pas de `users.password_hash`. */
export const variableRefSchema = idSchema;

/** Famille fermée de valeurs. B19 : pas de `z.unknown()` — voir § 7. */
export const scalarSchema = z.union([
  z.string().max(256),
  z.number().finite(),
  z.boolean(),
  z.null(),
]);
const ordinalSchema = z.union([z.number().finite(), z.string().datetime()]);

/**
 * B19 : UNION DISCRIMINÉE sur `op`. Le mode `.strict()` ne contrôle que les CLÉS
 * d'objet, jamais les VALEURS : `z.unknown()` laisserait passer
 * `{ nested: { sql: "…" } }`. Chaque `op` a donc sa propre forme de `value`.
 */
export const filterSchema = z.discriminatedUnion("op", [
  z
    .object({
      op: z.literal("eq"),
      variableRef: variableRefSchema,
      value: scalarSchema,
    })
    .strict(),
  z
    .object({
      op: z.literal("in"),
      variableRef: variableRefSchema,
      value: z.array(scalarSchema).min(1).max(500),
    })
    .strict(),
  z
    .object({
      op: z.literal("gt"),
      variableRef: variableRefSchema,
      value: ordinalSchema,
    })
    .strict(),
  z
    .object({
      op: z.literal("lt"),
      variableRef: variableRefSchema,
      value: ordinalSchema,
    })
    .strict(),
  z
    .object({
      op: z.literal("between"),
      variableRef: variableRefSchema,
      value: z.tuple([ordinalSchema, ordinalSchema]),
    })
    .strict(),
]);

/** B2 : l'identité de l'indicateur est son `id`. Unicité en § 2.2. */
export const indicatorSchema = z
  .object({
    id: idSchema,
    variableRef: variableRefSchema,
    aggregation: z.enum(AGGREGATIONS),
    filters: z.array(filterSchema).max(10).default([]),
    /** B26 : l'ordre fait foi (ordre du tableau). Le rang saisi est un indice, pas une garantie. */
    rank: z.number().int().min(0).max(59),
    label: z.string().max(120).optional(),
  })
  .strict();

/** E17 : vide = s'applique à TOUS. Sinon : des `indicators[].id`. */
export const paramSchema = z
  .object({
    id: idSchema,
    default: scalarSchema.optional(),
    appliesTo: z.array(idSchema).max(60).default([]),
  })
  .strict();

export const audienceSchema = z
  .object({
    users: z.array(z.string().min(1).max(128)).max(500).default([]),
    groups: z.array(z.string().min(1).max(128)).max(200).default([]),
  })
  .strict();
```

```ts
// src/core/config/schema.ts
import { z } from "zod";
import {
  audienceSchema,
  filterSchema,
  idSchema,
  indicatorSchema,
  paramSchema,
} from "./variables";

export const CURRENT_VERSION = 1 as const;

export const viewConfigSchema = z
  .object({
    version: z.literal(CURRENT_VERSION),
    id: idSchema,
    name: z.string().min(1).max(120), // B1
    description: z.string().max(2000).nullable().default(null), // B1
    indicators: z.array(indicatorSchema).max(60).default([]),
    params: z.array(paramSchema).max(20).default([]),
    audience: audienceSchema,
  })
  .strict()
  .superRefive((cfg, ctx) => {
    // Zod 4 : sur un parse « dirty », superRefine est parfois sauté. Sans cette
    // garde, un tableau contenant une entrée INVALIDE ferait boucler la
    // vérification sur des `item.id` à `undefined` et émettrait
    // « identifiant dupliqué : undefined » — un jeton technique dans une
    // erreur qui doit être formulée en langage métier (B13).
    if (ctx.issues.length > 0) return;

    // B2 : la référence stable doit être UNIQUE. Deux `id` égaux produiraient
    // une QuerySpec ambiguë en vague 1, silencieusement.
    for (const [label, arr] of [
      ["indicators", cfg.indicators],
      ["params", cfg.params],
    ] as const) {
      const seen = new Set<string>();
      arr.forEach((item, index) => {
        if (seen.has(item.id)) {
          ctx.addIssue({
            code: "custom",
            // Index d'élément : sans lui, l'écran ne peut pas surligner la
            // ligne fautive, et N doublons produisent N-1 messages identiques.
            path: [label, index, "id"],
            message: `identifiant dupliqué : ${item.id}`,
            params: { rule: "B2" },
          });
        }
        seen.add(item.id);
      });
    }

    // E17 : `appliesTo` ne peut viser que des indicateurs PRÉSENTS. Un id
    // fantôme produirait un paramètre qui ne s'applique à rien, et
    // l'interface afficherait « non filtré » pour tous — silencieusement.
    const ids = new Set(cfg.indicators.map((i) => i.id));
    cfg.params.forEach((param, pIndex) => {
      param.appliesTo.forEach((target, aIndex) => {
        if (!ids.has(target)) {
          ctx.addIssue({
            code: "custom",
            path: ["params", pIndex, "appliesTo", aIndex],
            message: `le paramètre ${param.id} vise un indicateur inconnu`,
            params: { rule: "E17" },
          });
        }
      });
    });
  });

export type ViewConfig = z.infer<typeof viewConfigSchema>;
```

### 2.2 Correspondance chemin → règle (`B13`)

Le plan ne devine pas la règle depuis le nom du champ : **la table est explicite**, et les issues
issues de `superRefine` portent leur règle dans `params.rule`.

| Chemin d'issue                                           | Règle | Message (exemple)                            |
| -------------------------------------------------------- | ----- | -------------------------------------------- |
| `name`                                                   | `B1`  | « Le nom est obligatoire »                   |
| `description`                                            | `B1`  | « La description est requise par ce projet » |
| `indicators` (vide)                                      | `B27` | « Au moins un indicateur est requis »        |
| `indicators[i].id` (doublon)                             | `B2`  | « Identifiant dupliqué : {id} »              |
| `indicators[i].variableRef`                              | `B3`  | « Référence de variable invalide »           |
| `indicators[i].aggregation`                              | `B4`  | « Agrégat non supporté »                     |
| `params[p].appliesTo[a]`                                 | `E17` | « Vise un indicateur inconnu »               |
| **toute autre** (`unrecognized_keys`, `too_big`, `type`) | `B19` | « Champ non déclaré » / « Valeur refusée »   |

**B13 impose deux choses, et les deux sont implémentées :**

1. Un message par **chemin de champ**, jamais un message global.
2. **Aucun jeton technique** : ni nom de table, ni nom de champ, ni code HTTP, ni trace. Les
   messages ci-dessus sont des libellés d'interface. Un test (§ 11.1) le vérifie en parcourant tous
   les messages produits par une config d'injection et en cherchant `sql`, `table`, `column`,
   `stack`, `undefined`, et un motif de code HTTP.

### 2.3 Types

```ts
// src/core/config/policy.ts
/** B1 : la SEULE dépendance à l'hôte. Tout le reste est une borne technique du schéma. */
export type ConfigPolicy = { descriptionRequired: boolean };
export const DEFAULT_POLICY: ConfigPolicy = { descriptionRequired: false };

// src/core/config/result.ts
export type ValidationError = { path: string; rule: string; message: string };
/** Un seul code, et un seul émetteur (§ 3 étape 4). Aucun membre d'énumération mort. */
export type ValidationWarning = {
  code: "RANKS_NORMALISED";
  path: string;
  message: string;
};
/** B16 : `raw` TOUJOURS présent — un refus ne détruit pas la saisie. */
export type ValidationResult = {
  ok: boolean;
  raw: unknown;
  config: ViewConfig | null; // null SEULEMENT si le parse strict a échoué
  errors: ValidationError[];
  warnings: ValidationWarning[];
};
```

### 2.4 Contrats API

Aucun. Le socle ne définit aucun endpoint (architecture §5). Entrée `unknown`, sortie
`ValidationResult`.

---

## 3. Algorithmes critiques

### `validateForPublication` (couvre `B1`, `B13`, `B16`, `B19`, `B26`, `B27`)

```
validateForPublication(raw, policy = DEFAULT_POLICY):

  1. PARSE STRICT
     res = viewConfigSchema.safeParse(raw)
     si res.error:
       RETOURNER { ok: false, raw, config: null,
                   errors: issues -> { path: issue.path.join("."),
                                       rule: issue.params?.rule
                                             ?? REGLE_PAR_CHEMIN[issue.path[0]]
                                             ?? "B19",
                                       message: messageEnMetier(issue) },
                   warnings: [] }
     B19 : le mode strict fait ÉCHOUER le parse sur toute clé non déclarée.
           Il ne l'ignore pas.

  2. DESCRIPTION — B1
     si policy.descriptionRequired ET (description est vide OU absent) :
       errors += { path: "description", rule: "B1",
                   message: "La description est requise par ce projet" }
     On ne MODIFIE PAS la config : la correction est à l'écran, qui a la valeur.

  3. INDICATEURS — B27
     si config.indicators est vide :
       errors += { path: "indicators", rule: "B27",
                   message: "Au moins un indicateur est requis" }
       PAS de retour anticipé : les étapes 4 et 5 s'exécutent aussi, pour que
       le signalement soit le même quel que soit le nombre d'indicateurs.

  4. RANGS — B26
     attendu = [0 .. indicators.length - 1]
     si les rangs déclarés !== attendu (trous, doublons, ordre) :
       renuméroter par l'ordre du tableau
       warnings += { code: "RANKS_NORMALISED", path: "indicators",
                     message: "L'ordre des indicateurs a été normalisé" }
     L'ordre du tableau EST l'ordre. Les rangs saisis ne sont qu'un indice.

  5. RETOURNER { ok: errors est vide, raw, config, errors, warnings }
```

> **Correction v3.** En v2, l'étape 3 faisait un **retour anticipé** : une config à 0 indicateur
> court-circuitait les étapes 4 et 5. Le signalement dépendait alors du nombre d'indicateurs. La
> sortie est désormais unique quelle que soit l'entrée.

### `messageEnMetier` (couvre `B13`)

```
messageEnMetier(issue) -> une chaîne en français, en langage métier.

  - NEVER issue.message si elle contient un identifiant technique.
    Zod produit par exemple « Invalid literal value, expected 1 » ou
    « Unrecognized key(s) in object: 'sql' » : les deux sont des jetons
    techniques, et « sql » est précisément le nom d'un champ injecté.
  - On mappe par code d'issue sur le message de la table § 2.2.
  - Test d'invariant (§ 11.1) : aucun message produit ne contient
    "sql", "table", "column", "stack", "undefined", ni /HTTP \d{3}/.
```

---

## 4. Plan composants

### 4.1 Arbre de composants

Aucun. `src/core` ne contient ni React, ni DOM (architecture §1.2).

### 4.2 Exports

| « Composant » | Fichier                        | Exports                                                                                                        |
| ------------- | ------------------------------ | -------------------------------------------------------------------------------------------------------------- |
| Schémas       | `src/core/config/variables.ts` | `idSchema`, `scalarSchema`, `filterSchema`, `indicatorSchema`, `paramSchema`, `audienceSchema`, `AGGREGATIONS` |
| Schéma racine | `src/core/config/schema.ts`    | `viewConfigSchema`, `ViewConfig`, `CURRENT_VERSION`                                                            |
| Politique     | `src/core/config/policy.ts`    | `ConfigPolicy`, `DEFAULT_POLICY`                                                                               |
| Résultat      | `src/core/config/result.ts`    | `ValidationError`, `ValidationWarning`, `ValidationResult`                                                     |
| Validation    | `src/core/config/validate.ts`  | `validateForPublication`, `REGLE_PAR_CHEMIN`, `messageEnMetier`                                                |

> **`migrate`, `MIGRATION_STEPS`, `validateStrict` ne sont pas exportés** : ils appartiennent à
> `slice format-migration`, qui n'existera qu'au moment où un format v2 verra le jour. Les écrire
> maintenant produirait des branches **inatteignables**, donc **non testables**, et c'est
> précisément ce que les validateurs ont signalé en v1 et v2.

### 4.3 États par écran

Aucun écran. Fonctions pures appelées par `wizard-etape-1-informations` et
`wizard-etape-3-disposition` via le reducer d'`ADR-010`.

### 4.4 Formulaires

Aucun. ADR-012 : le wizard est contrôlé et consomme `ValidationResult`, **pas** un type de
bibliothèque de formulaires.

---

## 5. Gestion d'état

| Donnée         | Portée      | Stockage                    | Initialisation         | Mise à jour              |
| -------------- | ----------- | --------------------------- | ---------------------- | ------------------------ |
| `ViewConfig`   | slice       | état du brouillon (reducer) | `config` de `draft`    | via le reducer (ADR-010) |
| `ConfigPolicy` | application | paramètre de configuration  | injection au démarrage | jamais en cours de vie   |

---

## 6. Traçabilité des règles

### 6.1 Règles métier

| ID    | Règle (PRD)                                                                         | Implémentée où                                                                                              | Approche                                                                                                                                                                            |
| ----- | ----------------------------------------------------------------------------------- | ----------------------------------------------------------------------------------------------------------- | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `B1`  | Nom obligatoire ; description facultative par défaut, obligatoire si l'hôte l'exige | `schema.ts` (`name.min(1)`), `validate.ts` étape 2                                                          | Le caractère obligatoire vient de `ConfigPolicy`, **pas** du schéma (ADR-012)                                                                                                       |
| `B2`  | Indicateurs identifiés par une **référence stable**                                 | `schema.ts` : `id` + unicité indexée par `superRefine`                                                      | Le versionnement **vit au niveau de la vue** (`B5`/`B6`/`B24`), pas sur l'indicateur. Stabilité prouvée par deux tests : `id` survit au réordonnancement et au renommage de `label` |
| `B3`  | Un indicateur référence des **variables métier**                                    | `variableRefSchema` = `idSchema`, regex sans point                                                          | Une référence technique ne peut pas être valide : le format du nom l'interdit par construction                                                                                      |
| `B4`  | L'assistant ne propose que des choix autorisés **et supportés**                     | `z.enum(AGGREGATIONS)`                                                                                      | Liste **fermée**. Un agrégat non supporté est invalide, pas ignoré                                                                                                                  |
| `B13` | Un refus est formulé en termes métier, **sans code technique**                      | `result.ts`, `validate.ts` étape 1, `messageEnMetier`, table § 2.2                                          | Deux exigences, deux implémentations : un message par chemin, **et** aucun jeton technique — vérifié par un test qui parcourt tous les messages                                     |
| `B16` | Un brouillon n'est **jamais détruit** par un échec                                  | `result.ts` : `raw` toujours présent                                                                        | La validation **ne mute pas** son entrée. Un refus est un retour, pas une mutation                                                                                                  |
| `B19` | Aucun nom de table, champ technique, code ni secret                                 | `.strict()` sur tous les objets ; `filterSchema` discriminée ; `param.default` et `label` en `scalarSchema` | Clés inconnues → échec, pas silence. **Valeurs** → famille fermée de scalaires. La limite exacte de cette promesse est en § 7                                                       |
| `B26` | Ordre stable et total                                                               | `validate.ts` étape 4                                                                                       | L'**ordre du tableau** fait foi ; les rangs saisis sont normalisés et le renumérotage est **signalé**                                                                               |
| `B27` | Publication refusée tant qu'aucun indicateur                                        | `validate.ts` étape 3                                                                                       | Erreur citant la règle ; `config` retourné intact ; pas de retour anticipé                                                                                                          |

**Règles citées mais hors périmètre, avec propriétaire nommé** (pour qu'un lecteur puisse vérifier
qu'elles sont ailleurs) : `B5`, `B6`, `B24` → `slice publication` · `B7`, `B8` → `slice sharing` ·
`B9` → `slice duplication` · `B10` → `slice administration` · `B21`, `B22` → `slice consumption` ·
`B15`, `B18` → `slice consumption` · `B28`–`B35` → `slice journal` · `B11` → `slice draft`.

### 6.2 Edge cases

| ID    | Cas                                                  | Approche                                                                                                                                                                                                                                              | Où                               |
| ----- | ---------------------------------------------------- | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | -------------------------------- |
| `E10` | Deux vues portent le même nom                        | **Aucune** unicité sur `name`. Choix : la désambiguïsation est faite par propriétaire + date, à l'affichage. Un test vérifie que deux configs de même nom parsent **toutes les deux** — il échoue le jour où quelqu'un ajoute un `.refine` par erreur | `schema.ts` (absence volontaire) |
| `E17` | Un paramètre ne s'applique qu'à certains indicateurs | `appliesTo` référence des `id` d'indicateurs. Vide = tous. Non vide = sous-ensemble des indicateurs présents, sinon refus avec chemin indexé. Un identifiant fantôme afficherait « non filtré » pour tous, silencieusement                            | `schema.ts` `superRefine`        |

### 6.3 Contraintes

| ID   | Contrainte                      | Comment elle est respectée                                                          |
| ---- | ------------------------------- | ----------------------------------------------------------------------------------- |
| `C1` | Aucune base de données imposée  | Aucune dépendance de stockage                                                       |
| `C3` | Aucune bibliothèque d'interface | Zod n'est pas une bibliothèque d'interface. `src/core` n'importe ni React ni le DOM |

---

## 7. Pièges à éviter

- **La promesse sur les VALEURS est plus étroite que sur les CLÉS.** ⚠️ § 1 dit « jamais de code, de
  secret, d'URL ». Le schéma garantit les **clés** (strict) et la **structure** (union fermée). Il
  ne garantit pas qu'une chaîne de 256 caractères ne ressemble pas à une URL — il l'accepte, et
  c'est délibéré : `variableRef` et les libellés sont des chaînes. **Ne pas reformuler § 1 en
  « aucune URL »** : ce serait promettre plus que le code ne fait. C'est l'item `minor` que
  `red-team` a rendu en v2, et il est accepté comme limite documentée.
- **Ne pas remettre `descriptionRequired` dans le schéma.** Un hôte exige la description, on ajoute
  `.min(1)`, et le socle devient impossible à configurer ailleurs. Le comportement correct (`B1`) est
  un **paramètre d'exécution**.
- **Ne pas utiliser `z.unknown()`.** ⚠️ Le mode strict ne contrôle que les **clés**, jamais les
  valeurs. `param.default = z.unknown()` laisserait passer `{ sql: "…" }` — et c'est exactement ce
  que `param.default: scalarSchema` corrige en v3.
- **Ne pas utiliser `Object.keys` pour détecter `__proto__`.** ⚠️ Posé via un littéral d'objet,
  `__proto__` **pose le prototype** au lieu de créer une propriété propre : `Object.keys` ne le voit
  pas, et le test « `__proto__` → refus » échouerait. Il faut `Object.getOwnPropertyNames` sur un
  document issu de `JSON.parse`. _(Ce piège n'existe plus en v3 : `default` est un `scalarSchema`, un
  objet n'y entre pas du tout. Il reste documenté parce qu'il reviendra dès qu'un champ libre
  existera.)_
- **Ne pas laisser la `superRefine` boucler sur un parse « dirty ».** ⚠️ Sans la garde
  `if (ctx.issues.length > 0) return`, un tableau contenant une entrée invalide fait produire
  `« identifiant dupliqué : undefined »` — un jeton technique dans une erreur qui doit être en
  langage métier (`B13`).
- **Ne pas inverser le sens du tableau des dépendances.** ⚠️ `config` n'a **aucune** dépendance
  entrante ; `draft`, `query`, `publication` en dépendent. Inverser les deux fait dire au plan qu'il
  est bloqué par ce qu'il bloque.
- **Ne pas déclarer un champ qu'aucun algorithme ne lit.** `ConfigPolicy.maxIndicators` l'a fait en
  v1 ; `DESCRIPTION_DROPPED` l'a fait en v2. Un tel champ laisse croire à une configurabilité qui
  n'existe pas, et force un `switch` mort chez le consommateur.
- **Ne pas réintroduire `migrate` ici.** Une seule version existe. Le moteur appartiendra à
  `slice format-migration`, le jour où il y aura une v2 à migrer.

---

## 8. Dépendances

**Dépendances entrantes — une seule :**

| Dépend de  | Nature | Statut           | Fallback si absent                          |
| ---------- | ------ | ---------------- | ------------------------------------------- |
| `zod` ^4.6 | lib    | `conventions.md` | **BLOCK** — pas de repli pour la validation |

**Consommateurs — en aval, ce ne sont pas des blocages :**

| Consommée par | Vague | Nature                                  |
| ------------- | ----- | --------------------------------------- |
| `draft`       | 1     | Le reducer porte un `ViewConfig`        |
| `query`       | 1     | Construit la spec à partir de la config |
| `publication` | 3     | Écrit une version publiée               |
| `sharing`     | V1    | Lit `audience`                          |

> **Correction v3.** En v2, ce tableau listait `draft`, `query`, `publication` et `sharing` avec un
> statut **`BLOCK`**, alors que la prose disait « cette slice ne dépend d'aucune autre ». Lu
> littéralement, le plan interdisait sa propre implémentation. Le sens est maintenant explicite :
> **entrantes** en haut, **consommateurs** en bas.

La version majeure de `zod` est **fixée à 4** dans `conventions.md` : le comportement de
`superRefine` sur un parse « dirty » diffère entre v3 et v4, donc un test qui ne dépend pas de la
version serait un test instable.

---

## 9. Checklist de tâches

### Phase 1 — Couche de données

- [ ] `src/core/config/variables.ts` : `ID_PATTERN`, `idSchema`, `scalarSchema`, `filterSchema`
      (union discriminée), `indicatorSchema`, `paramSchema`, `audienceSchema` — tous `.strict()`
- [ ] `src/core/config/schema.ts` : `viewConfigSchema` + `superRefine` (unicité `B2` indexée avec
      `params.rule`, `appliesTo` `E17`) **avec la garde `ctx.issues.length > 0`**
- [ ] `src/core/config/policy.ts` : `ConfigPolicy` (un champ)
- [ ] `src/core/config/result.ts` : `ValidationError`, `ValidationWarning` (un code), `ValidationResult`

### Phase 2 — Logique métier

- [ ] `src/core/config/validate.ts` : `REGLE_PAR_CHEMIN`, `messageEnMetier`, `validateForPublication`
      (5 étapes, **sans retour anticipé**)
- [ ] Tests unitaires **sans React** (ADR-010) couvrant `B1`, `B2`, `B3`, `B4`, `B13`, `B16`, `B19`,
      `B26`, `B27`, `E10`, `E17`
- [ ] **Chaque test de la ligne § 11.1 est écrit et cité son ID** — pas de scénario listé sans test

### Phase 3 — Interface utilisateur

- Aucun. `src/core` ne produit pas d'interface, par construction.

### Phase 4 — Intégration

- [ ] Test d'injection **en clé** : `sql`, `expression`, `url` → `unrecognized_keys`
- [ ] Test d'injection **en valeur**, avec un fixture **complet** :
      `{ filters: [{ op: "eq", variableRef: "annee", value: { x: { sql: 1 } } }] }` → refus sur le
      chemin `indicators.0.filters.0.value`
- [ ] Test d'invariant `B13` : aucun message produit ne contient de jeton technique
- [ ] Test de désambiguïsation `E17` : `appliesTo: ["inconnu"]` → refus, chemin indexé

### Phase 5 — Tests et polish

- [ ] `coverage-check.js slice config` renvoie `pass: true`
- [ ] `forge-exit.js <anchor> config` passe
- [ ] Scénarios § 11.6 différés : **créés avec un propriétaire nommé**, pas laissés orphelins

### Vérifications finales

- [ ] Lint sans erreur · Typecheck clean
- [ ] **Frontière : aucun import de React, du DOM ou du réseau dans `src/core/config/`**
- [ ] Chaque `B*` de la slice a un test **cité par son ID**
- [ ] **Aucun marqueur non résolu** : pas de `<…>`, pas de `…`, pas de `TODO` (voir § 11.7)

---

## 10. Critères d'acceptation

- [ ] `B1` : `name: ""` refusé ; `description: null` **accepté** sous `DEFAULT_POLICY` et **refusé**
      sous `{ descriptionRequired: true }` ; `description: ""` refusé sous cette même politique
- [ ] `B2` : deux `indicators[].id` égaux → refus sur le chemin `indicators[1].id` **avec index** ;
      deux `params[].id` égaux → refus sur `params[1].id` ; même `variableRef` et `id` différents →
      acceptés
- [ ] `B2` : l'`id` d'un indicateur **survit** à un réordonnancement du tableau **et** à un renommage
      de `label` — deux tests
- [ ] `B3` : `variableRef: "users.password_hash"` → refus (le point est interdit par la regex)
- [ ] `B4` : `aggregation: "median"` → refus
- [ ] `B13` : une config invalide produit une erreur par chemin, chacune portant `rule` **et** un
      chemin indexé là où l'élément est identifiable
- [ ] `B13` : **aucun** message produit ne contient `sql`, `table`, `column`, `stack`, `undefined`
      ni un motif de code HTTP
- [ ] `B16` : `validateForPublication` ne mute pas son entrée ; après un refus de `B27`, `raw` est
      identique à l'entrée et `config` porte encore ses indicateurs
- [ ] `B19` : `{ sql: "…" }` au niveau racine → `unrecognized_keys`. `{ filters: [{ op: "eq", variableRef: "a",
value: { x: { sql: 1 } } }] }` → refus. `param.default = { a: 1 }` → refus
- [ ] `B19` : `indicators` à 61 éléments → refus ; `filters` à 11 → refus ; `in` avec 501 valeurs →
      refus ; `in` avec 0 valeur → refus ; `rank: 60` → refus ; `rank` absent → refus ;
      `label` à 121 caractères → refus ; `params` à 21 → refus ; `audience.users` à 501 → refus
- [ ] `B26` : rangs `[5, 2, 9]` → `[0, 1, 2]` **et** un `warning: RANKS_NORMALISED` ; rangs
      dupliqués → idem ; rangs contigus → **aucun** warning
- [ ] `B27` : `indicators: []` → erreur citant `B27`, `config` retourné intact, **et** les étapes 4
      et 5 exécutées (sortie unique quel que soit le nombre d'indicateurs)
- [ ] `E10` : deux configurations de même `name` parsent **toutes les deux**
- [ ] `E17` : `appliesTo: []` accepté ; `["idprésent"]` accepté ; `["inconnu"]` **refusé** sur le
      chemin `params[0].appliesTo[0]`
- [ ] `superRefine` : une config dont `indicators` contient une entrée **invalide** ne produit
      **aucune** issue de unicité (pas de `undefined` dans un message)
- [ ] Aucun `migrate`, `MIGRATION_STEPS` ou `validateStrict` n'est exporté : le module n'a qu'une
      version, donc aucune migration à faire

---

## 11. Plan de tests

### 11.1 Tests unitaires

| Cible                         | Scénarios                                                                                                                                                                                  | IDs                       |
| ----------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ | ------------------------- |
| `viewConfigSchema`            | nominal ; `sql`/`url`/`expression` en clé ; `name` vide ; `variableRef` avec point ; `aggregation` hors liste ; `columns`/`layout` **absents du schéma** (migration en § 12)               | `B3`, `B4`, `B19`         |
| bornes déclarées              | `indicators` 61 · `filters` 11 · `in` 0 et 501 · `rank` absent et 60 · `label` 121 · `params` 21 · `audience.users` 501 · `description` 2001                                               | `B19`                     |
| unicité (`superRefine`)       | deux `indicators[].id` égaux → chemin **indexé** ; deux `params[].id` égaux ; même `variableRef`, `id` différents (accepté)                                                                | `B2`                      |
| stabilité de l'`id`           | réordonnancement → `id` inchangés ; renommage de `label` → `id` inchangé                                                                                                                   | `B2`                      |
| `superRefine` sur parse dirty | `indicators` contenant une entrée invalide → **aucune** issue d'unicité, aucun `undefined` dans un message                                                                                 | `B13`                     |
| `filterSchema`                | `eq` scalaire ; `in` 1 et 500 valeurs ; `in` **vide** → refus ; `between` tuple de 2 (accepté) ; `between` scalaire unique → refus ; `value` objet (avec `variableRef` **valide**) → refus | `B19`                     |
| `paramSchema.default`         | scalaire accepté ; **objet → refus** ; tableau → refus                                                                                                                                     | `B19`                     |
| `appliesTo`                   | `[]` ; id présent ; id absent **refusé**, chemin `params[p].appliesTo[a]`                                                                                                                  | `E17`                     |
| `validateForPublication`      | 0 indicateur ; `descriptionRequired` vrai/faux ; `description: ""` sous politique stricte ; rangs `[5,2,9]` ; rangs dupliqués ; rangs contigus (aucun warning) ; **entrée non mutée**      | `B1`, `B16`, `B26`, `B27` |
| chemins et règles             | config invalide → une `ValidationError` par chemin, chacune avec `rule` non vide                                                                                                           | `B13`                     |
| invariant `B13`               | parcourir **tous** les messages d'une config d'injection et affirmer l'absence de `sql`, `table`, `column`, `stack`, `undefined`, `/HTTP \d{3}/`                                           | `B13`                     |
| `E10`                         | deux `name` identiques parsent tous les deux                                                                                                                                               | `E10`                     |

### 11.2 Tests de composants

Aucun — `src/core` ne rend rien.

### 11.3 Tests d'intégration

Aucun **aujourd'hui** : les scénarios qui exigent `query` et `draft` ne sont pas exécutables tant que
ces slices n'existent pas. Ils sont différés en § 11.6 avec un propriétaire nommé.

### 11.4 Tests E2E

Aucun — la publication est couverte par `publication`, le parcours complet en Phase 6.

### 11.5 Vérifications Chrome MCP

Sans objet — aucun écran dans cette slice.

### 11.6 Tests différés (avec suivi)

| ID de suivi           | Scénario                                                          | Slice propriétaire | IDs          |
| --------------------- | ----------------------------------------------------------------- | ------------------ | ------------ |
| `DEF-config-query-1`  | une config valide produit une `QuerySpec` **sans champ exotique** | `query` (vague 1)  | `B2`, `B19`  |
| `DEF-config-draft-1`  | un refus de publication ne détruit pas la saisie du brouillon     | `draft` (vague 1)  | `B27`, `B16` |
| `DEF-config-shared-1` | `audience` alimente le partage nominatif et groupes               | `sharing` (V1)     | `B7`         |

> Un test différé sans propriétaire nommé n'est pas un test différé : c'est un constat laissé
> « dans un plan à venir », ce que Fast Track refuse explicitement.

### 11.7 Contrôle des marqueurs non résolus

`forge-guard placeholders` ne détecte que `{{PLACEHOLDER}}` à **double accolades**. Un marqueur à
chevrons (une alternative de règle entre chevrons) ou un mot coupé suivi d'un point **passent au
travers** — c'est arrivé en v2, deux fois, dans un plan déclaré « code réel ».

Vérification manuelle, à passer sur chaque plan avant validation. Le motif est volontairement
large, donc **il signale aussi des occurrences légitimes** qu'il faut laisser :

| Signalé                                   | Verdict attendu                             |
| ----------------------------------------- | ------------------------------------------- |
| `Set<string>`, `z.infer<typeof X>`        | **légitime** — generic TypeScript           |
| `<anchor>` dans une commande              | **légitime** — paramètre de commande        |
| Le motif cité **dans ce paragraphe même** | **légitime** — il exemplify ce qu'il traque |
| Un `...` à l'intérieur d'un littéral JSON | **défaut** — marqueur accidentel            |

```bash
# Sortir chaque occurrence AVEC sa ligne, et les juger une par une.
grep -nE "<[A-Za-z0-9| ]+>|\bTODO\b|\.\.\." .forge/plans/slice-*.md
```

> Un contrôle large qui signale du bruit est utilisable **si** on le juge ligne à ligne. Un
> contrôle étroit qui ne dit rien est pire : il donne un vert. C'est la règle appliquée au scan
> Unicode, et elle s'applique ici.

---

## 12. Contrat de ce qui a été sort de la slice

| Élément                                     | Slice destinataire | Statut de la spécification                                                                                                      |
| ------------------------------------------- | ------------------ | ------------------------------------------------------------------------------------------------------------------------------- |
| `migrate`, `MIGRATION_STEPS`, `MIN_VERSION` | `format-migration` | **Nécessaire et non existant.** Créer la slice au moment où un format v2 existe                                                 |
| `disposition` (`layout`, `columns`)         | `disposition`      | `columns` n'est borné par aucune règle du PRD. Le design system dit « 12 colonnes » : à trancher                                |
| `params[].kind` (`period` / `filter`)       | `params`           | US-9 dit « plusieurs paramètres communs » mais **le comportement d'un `filter` n'est défini nulle part**. Vide de spécification |
| Politique « refus sans code technique »     | **PRD**            | `B13` l'exige, **rien ne dit où ça s'implémente**. Décision de produit, pas de plan                                             |

---

## Checklist de gate

- [x] Sources explicitement référencées (PRD, architecture, conventions)
- [x] Chaque ID `B*` / `E*` / `C*` du périmètre apparaît en § 6 ; les règles citées hors périmètre ont
      un **propriétaire nommé**
- [x] Les contrats de données (§ 2) sont du **code réel** : `.strict()` dans le bloc, `import`
      présents, **aucun `z.unknown()`**, **aucun marqueur non résolu**
- [x] `ConfigPolicy` ne contient aucun champ mort ; `ValidationWarning` n'a qu'un code et un émetteur
- [x] Aucun champ du schéma sans consommateur ni test ; chaque borne déclarée a un scénario
- [x] `validateForPublication` n'a **aucun retour anticipé** — une seule forme de sortie
- [x] La correspondance chemin → règle est une **table**, pas une devinette inline
- [x] `B13` est traduit **dans ses deux moitiés** : chemin de champ, et absence de jeton technique
- [x] Le tableau § 8 distingue **dépendances entrantes** et **consommateurs**, sans `BLOCK` inversé
- [x] Les tests d'injection ont des fixtures **complets** : un test qui échoue sur une clé manquante
      ne prouve pas la règle qu'il prétend prouver
- [x] La checklist de tâches (§ 9) couvre les 5 phases, Phase 3 explicitement vide et pourquoi
- [x] Les critères d'acceptation (§ 10) sont vérifiables individuellement
- [x] Le plan de tests (§ 11) couvre tous les IDs ; les tests différés ont un propriétaire ; § 11.7
      couvre ce que `forge-guard` ne couvre pas
- [x] **Ce qui a été sorti est nommé, avec propriétaire et état de spécification** (§ 12)
- [ ] `coverage-check.js slice` renvoie `pass: true` — **à l'exécution, pas à l'écriture**
