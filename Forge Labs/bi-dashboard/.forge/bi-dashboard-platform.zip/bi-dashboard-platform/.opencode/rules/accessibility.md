# Accessibilité

> Règles **non négociables** : un écran qui ne peut pas être opéré au clavier n'est pas terminé.
> Le drag-and-drop est un enhancement, jamais l'unique moyen.

## Langue : WCAG 2.2 niveau AA

Cible du pilote : **zéro** violation sérieuse ou critique sur les parcours principaux
(`axe` ou équivalent). « Presque accessible » ne se mesure pas et ne se valide pas.

## Le clavier est le chemin par défaut

Toute action dispose d'un équivalent clavier. Pour le déplacement et le redimensionnement d'un
widget :

| Touche              | Effet                                   |
| ------------------- | --------------------------------------- |
| `Entrée` / `Espace` | saisir le mode déplacement              |
| flèches             | déplacer d'une position logique         |
| `Entrée` / `Espace` | valider                                 |
| `Échap`             | annuler et restaurer la position exacte |

Le focus **reste** sur la poignée pendant l'opération et ne disparaît jamais. Les instructions
sont découvrables **avant** de commencer l'action, pas seulement en cas d'erreur.

Une zone de dépôt doit être annoncée (`aria-live`, polie) à chaque changement de position, avec
l'identifiant du widget, sa nouvelle position et sa nouvelle taille.

## Structure et navigation

- Une seule balise `h1` par page ; hiérarchie de titres sans niveau sauté.
- Le pas courant d'un assistant est marqué `aria-current="step"`, avec un indicateur d'étape
  **visible en texte** — un bandeau purement graphique ne renseigne personne en lecture d'écran.
- Le focus va au titre de l'étape suivante ; le focus **revient** à l'élément déclencheur à la
  fermeture d'une boîte de dialogue.
- Les zones principales sont des _landmarks_ ; le contenu doit être atteignable au clavier sans
  traverser une longue série d'éléments sans intérêt.

## Erreurs et statuts

- Les erreurs de champ sont associées au contrôle (`aria-invalid` + `aria-describedby`) et
  décrites avant la saisie du premier champ en erreur, pas seulement à la fin.
- La validation ne se déclenche **pas à chaque frappe** : une erreur affichée puis effacée à la
  frappe suivante est pire que pas d'erreur.
- Un message d'erreur de page est annoncé **une fois**. Douze squelettes animés ne sont pas
  douze annonces utiles.
- Les messages d'erreur n'exposent ni code HTTP, ni nom de table, ni trace.

## Graphiques

- Nom accessible, résumé de tendance, et **tableau de valeurs** équivalent.
- Un utilisateur non visuel doit pouvoir obtenir les valeurs clés sans interpréter une
  géométrie ni une couleur.
- Les éléments décoratifs du SVG sont masqués à l'arbre d'accessibilité.

## Non-textuel

- La couleur n'est jamais le seul signal d'état, de sélection, d'erreur ou de série.
- Focus visible, contraste ≥ 3:1 pour l'indicateur de focus.
- `prefers-reduced-motion` respecté : plus d'animation décorative, mais le retour textuel et le
  focus restent.

## Responsive

- Opérable à 320 px de large et à 400 % de zoom, sans défilement bidirectionnel de la page.
- Cible tactile ≥ 44 × 44 px sur les dispositions tactiles.
- Un tableau large peut défiler dans une zone nommée et focusable, mais ne doit jamais faire
  déborder la page entière.
- En une colonne, l'ordre de lecture reste gauche→droite puis haut→bas, cohérent avec l'ordre
  du DOM.

## Tableaux

- `<th>` avec `scope`, cellules associées.
- Virtualisation : exposer `aria-rowcount` et `aria-rowindex`, sinon les lecteurs d'écran
  annoncent « ligne 1 sur 1 » pour une table de 5 000 lignes.

## Ce qui n'est pas de l'accessibilité

- Une étiquette `aria-label` sur un élément non focusable pour « améliorer » le score.
- Un `role` qui ne correspond pas au comportement réel.
- Remplacer une commande inaccessible par une autre inaccessible mais conforme.

Chacun de ces trois cas fait monter le score sans changer l'expérience : c'est une régression,
pas une correction.
