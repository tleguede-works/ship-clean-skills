# Données, configuration et état

> Règles de **forme des données** et de leur cycle de vie. Les ports/adapters sont définis
> dans `architecture.md` ; les implications de sécurité sont dans `security.md`.

## 1. Une configuration sauvegardée est une donnée, jamais du code

Une vue publiée est un objet sérialisé. Elle peut contenir : des clés de variables sémantiques,
des identifiants de widget, des paramètres de présentation, des positions de grille, des
chaînes de texte.

Elle ne peut **jamais** contenir :

| Interdit                                                         | Raison                                 |
| ---------------------------------------------------------------- | -------------------------------------- |
| fonction, composant React, classe                                | exécution non revue au moment du rendu |
| `eval`, `new Function`, import dynamique nommé par l'utilisateur | injection de code                      |
| SQL, fragment de requête, nom de table/colonne brut              | fuite de schéma + injection            |
| HTML brut                                                        | XSS stocké                             |
| secret, token, clé d'API, URL de connexion                       | le client ne détient pas de secret     |
| URL arbitraire « fetch this »                                    | SSRF / sortie du périmètre autorisé    |

Un widget est résolu par une **clé stable et versionnée** dans un registre côté hôte. La
configuration ne fait que _nommer_ ; le code vit dans le registre.

```bash
# Attendu : 0 résultat dans src/ et pilot/
Select-String -Path src/**,pilot/** -Pattern "dangerouslySetInnerHTML|eval\(|new Function"
```

## 2. Identifiants sémantiques, jamais de libellés ni de noms de champs

Une vue référence `"bi.sms.provider"`, pas `"api"` ni `"API"` ni `"Fournisseur"`. Les libellés
sont résolus au moment du rendu depuis le catalogue courant.

Conséquence directe : si une variable est renommée ou retirée, la vue doit le **dire**
explicitement (« mise à jour requise »), jamais pointer silencieusement vers autre chose.
Renommer n'est pas mettre à jour.

Chaque document porte sa version de schéma (`schemaVersion`, `contractVersion`,
`layoutVersion`). Une migration est explicite ; un `best effort` silencieux est un bug.

## 3. Immuabilité par version

- Éditer une vue crée un **nouveau brouillon** ; ne modifie jamais une version publiée.
- Publier crée une version **immuable**, avec auteur, horodatage et empreinte du contenu.
- Un doublon est un **nouvel objet** appartenant au duplicateur ; il n'hérite pas des droits
  d'accès de la source.
- Un changement de « vue par défaut » est un **changement de pointeur**, pas une édition, et il
  est journalisé comme tel.

## 4. Édition concurrente

Deux sessions peuvent modifier le même brouillon. Écrire un brouillon sans jeton de
concurrence revient à écraser silencieusement le travail d'autrui.

- Un jeton d'optimisme (`revision` / ETag) accompagne chaque écriture.
- Un conflit répond `409` et propose : recharger le dernier, garder son brouillon comme copie,
  ou annuler. **Jamais** de fusion silencieuse, **jamais** d'écrasement.
- Un brouillon en cours de saisie n'est jamais détruit par un échec de sauvegarde ou de
  validation.

## 5. Le runtime ne connaît que des états nommés

Chaque requête de widget passe par un état **nommé** et testable, jamais une cascade de
booléens : `idle`, `validating`, `loading`, `refreshing`, `success`, `empty`, `stale`,
`partial`, `forbidden`, `rejected`, `error`.

`empty` et `success` avec zéro ligne sont **différents** : l'un signifie « pas de donnée pour
cette période », l'autre « la requête a réussi ». Les confondre produit des messages faux.

Un `refreshing` conserve la donnée précédente affichée ; un refresh ne remplace jamais des
valeurs lisibles par un squelette.

## 6. Une vue est une exécution cohérente, pas une collection de widgets

Un rafraîchissement global est **une** exécution coordonnée, pas N effets indépendants.

- Toutes les requêtes d'une exécution partagent la révision de vue et les paramètres globaux.
- Les requêtes identiques sont dédupliquées par **empreinte de requête normalisée**, jamais par
  identité d'objet.
- Un résultat obsolète ne doit jamais écraser un résultat plus récent (réponse arrivée en
  retard).
- Si la cohérence de snapshot n'est pas garantie, le résultat est marqué `partial` ou
  `inconsistent` — jamais présenté comme exact.

## 7. Cache

La clé de cache inclut au minimum : requête normalisée, **version du catalogue**, et
**identifiant du périmètre d'autorisation**. Un cache servi à un périmètre plus large que le
demandeur est une fuite de données, pas une optimisation.

Un changement de permission, une déconnexion ou un `401`/`403` invalide les entrées concernées.

```bash
# Attendu : aucune clé de cache construite sans le scope d'autorisation
Select-String -Path src/** -Pattern "queryKey|queryKeyHashFn" -Context 0,3
```

## 8. Régénération : in-memory d'abord

Tout port non encore branché s'implémente d'abord **en mémoire** (`InMemoryViewRepository`,
`StaticCatalogProvider`) afin que l'UI et les tests fonctionnent sans backend. Le branchement
réel vient après, et ne modifie jamais le contrat du port.

Un composant qui dépend d'un backend non disponible n'est pas testable : c'est un signal
d'architecture, pas un problème d'outillage.
