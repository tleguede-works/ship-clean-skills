# Architecture et frontières

> Règles de **structure**. Les choix de stack sont dans `.forge/conventions.md` § Stack.
> Les interdits de sécurité qu'elles impliquent sont dans `security.md`.

## Principe directeur

Ce produit est destiné à devenir une bibliothèque. Le coût d'erreur le plus élevé n'est pas un
bug : c'est une **dépendance de l'hôte qui s'est glissée dans le core**, qui rend l'extraction
impossible et impose de réécrire le package. Toute décision d'architecture se juge d'abord à
cette question : _est-ce que cette ligne relie ce module à un projet, un framework ou un
transport précis ?_

## Les frontières

| Couche           | Peut importer                     | Interdit                                                       |
| ---------------- | --------------------------------- | -------------------------------------------------------------- |
| `src/core`       | Zod uniquement                    | React, Next, Axios, `src/react`, `src/ui`, `src/next`, `pilot` |
| `src/react`      | `src/core`                        | `next/*`, `pilot`, libs de data client                         |
| `src/ui`         | `src/core`, `src/react`           | `next/*`, `pilot`                                              |
| `src/next`       | `src/core`, `src/react`, `next/*` | `pilot`                                                        |
| `pilot/adapters` | tout `src/**`                     | dépendance inverse (rien dans `src/**` n'importe `pilot`)      |

Le core ne contient **aucun composant** et **aucun appel réseau**. S'il a besoin de savoir
quoi que ce soit de l'extérieur, il définit une interface — il ne l'importe pas.

## shadcn est le défaut, jamais une dépendance

shadcn fonctionne par **copie de code source** : la CLI écrit les fichiers dans le projet, qui
deviennent la propriété du projet ; seules les vraies dépendances (Radix, etc.) sont installées
en npm. Conséquence directe, à ne jamais enfreindre :

**Interdit dans `src/core` et `src/react`** — tout import d'un chemin shadcn de l'hôte :

```ts
import { Button } from "@/components/ui/button"; // interdit hors src/ui
```

Ces fichiers n'existent que dans un projet ayant lancé la CLI. Le second projet hôte (`C6`,
Elora, mobile) ne les aura **jamais** : il n'a ni DOM, ni composants web. Un socle qui importe
un chemin de l'hôte n'est pas réutilisable, il est recopiable.

**Autorisé dans `src/ui`** — et seulement là, et seulement via le registre de composants :
l'implémentation par défaut est shadcn, mais elle est **remplaçable**. Un hôte sans shadcn
fournit ses propres composants au même registre ; le comportement du module ne change pas.

```bash
# Attendus : 0 résultat dans core/ et react/ ; des résultats sont normaux dans src/ui/
Select-String -Path src/core/**,src/react/** -Pattern "from ['\"].*components/ui"
```

Voir ADR-005 pour la décision et sa justification.

## Port plutôt que dépendance

Avant d'ajouter une dépendance runtime à `src/react` ou `src/ui` (cache, formulaires,
grille, graphiques), se poser la question : _est-ce un détail d'implémentation ou un point
d'extension ?_

- Détail d'implémentation → il reste interne, l'hôte n'a rien à dire.
- Point d'extension réel → il devient un **port** dans `src/core`, avec une implémentation de
  référence dans `pilot/adapters/`, et l'hôte fournit la sienne.

Un widget, une source de données, un mécanisme de cache, un rendu de graphique : tous sont des
ports. C'est précisément ce qui rend le package réutilisable dans un projet qui n'a rien à voir
avec l pilote.

## Port ≠ lecture d'un registre arbitraire

Un registre associe une **clé stable et versionnée** à une implémentation. Un composant n'est
jamais stocké dans la configuration sérialisée : il est résolu par la clé au moment du rendu.
C'est ce qui distingue une extension d'une injection de code — voir `data-and-state.md` § 1.

## `'use client'` est une frontière, pas un attribut de convenience

Le core et les renderers sans état peuvent rester rendables depuis un composant serveur. Marquer
`"use client"` au plus haut niveau possible élargit le bundle client sans raison. Seul `src/next`
importe `next/*` — y compris `next/dynamic` pour le chargement différé des chunks lourds.

## Vérification

```bash
# Aucun import d'hôte ou de framework dans le core (attendu : 0 résultat)
Select-String -Path src/core/** -Pattern "from ['\"](react|next|@/)"

# Aucun module src/ n'importe le pilote (attendu : 0 résultat)
Select-String -Path src/** -Pattern "from ['\"].*pilot"

# Frontières réelles : ces chemins n'existent pas encore, la commande doit le dire
Select-String -Path src/** -Pattern "from ['\"](@tanstack/react-query|axios|@reduxjs/toolkit)"
```

Un test qui ne touche que le chemin nominal ne vérifie pas une frontière : voir `testing.md` § 2.

## Contamination inter-projets

Le projet de référence `ace3i-bankingsms-ui` est un **berceau**, pas une source. Le _pattern_
est portable (revue avant commit, mémoire inter-sessions, ports/adapters) ; le **contenu** ne
l'est pas. Ne jamais importer un nom de fichier, une bibliothèque ou un terme de processus
depuis ce projet sans le re-derivér à partir de la stack réelle d'ici.

Termes et fichiers à ne pas reprendre tant qu'ils n'ont pas été délibérément adoptés ici :
`MIGRATION_ROADMAP`, `MIGRATION_TASKS`, `.plan.md`, `RequirePermission`, `PageLayout`,
`lib/routes.ts`, `PERMISSIONS`, Base UI, Redux Toolkit, Formik, `useReactTable` pattern.
Le terme « slice » est **autorisé** ici : c'est l'unité de planification définie par Forge,
pas la tranche de migration du projet de référence. Ce qui est interdit, c'est d'importer le
vocabulaire de workflow d'un autre projet.
