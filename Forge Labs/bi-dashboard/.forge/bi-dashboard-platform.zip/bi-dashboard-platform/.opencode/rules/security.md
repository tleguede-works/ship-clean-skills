# Sécurité

> Règles de sécurité **applicatives**. Le produit manipule des données métier agrégées et des
> textes saisis par des utilisateurs : ce sont deux surfaces d'attaque, pas une.

## Principe : le client n'est pas une frontière

Masquer un bouton, retirer une option d'une liste, désactiver un champ : ce sont des
conveniences d'interface. Elles ne protègent rien, car l'appel réseau est reproductible
directement.

Toute décision d'accès est prise **par le service qui exécute la requête**, sur la base de
l'identité de l'appelant. Si une règle de sécurité du PRD ne peut pas être vérifiée par un test
contre le backend réel, elle n'est pas implémentée : elle est documentée comme non couverte.

Les trois contrôles sont **conjointifs** (tous vrais requis) :

1. accès à la vue ;
2. accès à la source, au champ et à l'agrégat ;
3. périmètre de lignes (data scope).

Un partage de vue **ne confère aucun droit nouveau** au destinataire.

## Échec fermé

Si un périmètre d'autorisation ne peut pas être résolu, le résultat est **vide**, jamais
« toutes les lignes ». Une incertitude de sécurité se résout du côté le plus restrictif.

```bash
# Un guard de permission ne doit jamais avoir de branche « permission inconnue => autorisé »
Select-String -Path src/** -Pattern "if \(!.*permission.*\)" -Context 0,2
```

## Le modèle de requête est fermé

Une requête est un AST **versionné, validé, fermé**. Elle ne peut pas exprimer : du SQL, des
scripts, des expressions arbitraires, des fonctions définies par l'utilisateur, une source non
enregistrée, un champ non déclaré, un chemin de jointure non déclaré.

La validation s'exécute **à chaque** requête, y compris quand le client affirme avoir déjà
validé. Un drapeau « déjà validé » envoyé par le client n'est jamais une preuve.

Les limites (champs de sortie, conditions, profondeur, regroupements, lignes, fenêtre de dates,
durée, débit) sont imposées **par le serveur** et non modifiables par l'appelant. Une
dépassement est un refus structuré, pas une troncature silencieuse.

## Le texte saisi est une donnée non fiable

Noms de vues, descriptions, titres de widgets, annotations, libellés : traités comme une entrée
publique, quel que soit le rôle de l'auteur.

- Rendu en **texte**. Jamais de HTML brut.
- Markdown, si un jour activé : pipeline d'assainissement centralisé, liste blanche explicite,
  protocoles d'URL restreints. Pas de configuration d'assainissement par appel.
- Longueurs et nombre de caractères bornés **au niveau du schéma**, pas seulement à l'affichage.
- Identifiants de série et couleurs de graphique validés **avant** d'être passés à une
  génération de style ou d'attribut.

```bash
# Attendu : 0 résultat
Select-String -Path src/** -Pattern "dangerouslySetInnerHTML|innerHTML\s*=|javascript:"
```

## Secrets

Aucun secret n'atteint le navigateur. Les identifiants de source de données, clés d'API et
chaînes de connexion vivent côté service, proviennent de l'environnement ou d'un coffre, et
n'apparaissent ni dans les logs, ni dans les réponses d'erreur, ni dans les événements de
télémétrie.

Un utilisateur ne fournit **jamais** une URL de connexion, un DSN, un nom de pilote ou une
classe d'adaptateur. L'enregistrement d'un adaptateur est un acte d'administration, pas une
fonctionnalité d'auto-service.

## Erreurs

Un code d'erreur stable et un message générique. Jamais de stack trace, de fragment SQL, de nom
de table ou d'entité, de chemin de fichier, de chaîne de connexion ni d'exception brute.

Un refus d'autorisation est **distingable** d'une absence, mais ne doit pas révéler par
différence de réponse qu'une ressource existe quand sa simple existence est sensible.

## Audit

Événements journalisés en écriture seule : création, modification, publication, partage,
révocation, duplication, archivage, changement de vue par défaut, exécution de requête
(normalisée et expurgée), refus d'accès.

Les valeurs de filtre et le contenu des lignes n'entrent **pas** dans le journal. Le journal
n'est ni modifiable ni supprimable par un rôle applicatif.

**La lecture du journal est elle-même journalisée** (`B35`). Un journal consultable sans trace
laisserait l'auto-espionnage hors de portée : celui qui veut savoir ce qu'un autre a consulté
n'aurait aucun moyen de l'apprendre. On journalise donc la consultation : qui, quelle période,
sur quel périmètre.

## Actions, pas rôles

Le socle définit un **vocabulaire d'actions** (`view:write`, `journal:read`, `data:execute`…) et
**jamais** un catalogue de rôles. Le mapping action → droit réel est fait par l'hôte.

Deux raisons, qui n'en font qu'une : un rôle est une convention sociale du projet, et il varie
d'un projet à l'autre ; une action est une capacité qui doit exister pour être déléguée
séparément. Le socle qui définit les rôles force une migration chez tous les hôtes (`C2`) **et**
rend inexprimable toute séparation de droits qu'un hôte voudrait.

Cas d'école : `journal:read` est distincte de l'administration des vues (`B31`). Un hôte **peut**
les réunir dans un rôle unique (`B32`), mais le défaut est la séparation (`B33`) et la portée est
bornée au périmètre du titulaire (`B34`).

```ts
// Interdit : le socle ne décide pas qui est administrateur
type Role = "admin" | "editor" | "viewer";

// Attendu : le socle nomme des capacités, l'hôte décide qui les détient
type Action =
  | "view:read"
  | "view:write" // crée, modifie ET supprime : un seul pouvoir d'écriture (B36)
  | "view:publish"
  | "view:share"
  | "view:set-default"
  | "data:execute"
  | "journal:read";
```

`view:write` couvre les trois opérations d'écriture parce qu'aucune n'est accordable sans les
autres : créer, c'est écrire une vue absente ; supprimer, c'est écrire son état. Mais `view:write`
**ne détruit pas** l'historique des versions — écrire remplace l'état courant (`B37`), sans quoi
la restauration d'une version antérieure deviendrait impossible.

## Ce qui n'est pas de la sécurité

- Chiffrer en base la configuration d'une vue.
- Masquer un champ côté client.
- Vérifier qu'un `typeof` est correct.

Ces mesures ne remplacent pas une autorisation serveur, et leur présence ne doit jamais servir
à justifier qu'une autorisation serveur a été omise.
