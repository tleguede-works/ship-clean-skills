# Tests

> Règles de **discipline de test**. L'outillage (framework, commandes) est dans
> `.forge/conventions.md` § Stratégie de tests et n'est pas répété ici.

## 1. Un test couvre une règle nommée

Chaque test vise **une** règle métier, un edge case ou une contrainte du PRD, et **cite son
identifiant** (`B12`, `E7`, `C3`) dans le nom du test ou le bloc.

Un test qui ne touche aucune règle n'est pas un test de règle : il sera supprimé par la
prochaine réécriture sans que personne ne s'en aperçoive. Corollaire : si un `B*` n'est couvert
par aucun test, il n'est pas implémenté — même si le code « marche ».

## 2. Une frontière se prouve par deux tests

Une frontière testée uniquement par le chemin nominal ne prouve rien. Pour toute frontière
(import interdit, permission, limite, version), il faut **au minimum deux** cas : le cas
autorisé et le cas refusé.

- `core/` n'importe pas React → un test ou un lint le prouve ; un import interdit doit
  **échouer**, pas être simplement absent.
- Une limite de 5 000 lignes → un test à 5 000 passe **et** un test à 5 001 échoue.
- Une publication immuable → un test « la version précédente est inchangée après publication ».

## 3. L'attendu est une question posée aux données

Un attendu se formule d'abord comme une question sur le résultat observé, puis on répond. Un
attendu calculé par le même algorithme que le code testé ne vérifie rien.

- ❌ `expect(sum(rows)).toBe(rows.reduce(add))`
- ✅ `expect(render(<Kpi value={1234} />)).toContain("1 234")`

De même : un test qui passe parce qu'il n'a rien trouvé n'est pas un test. Si une recherche doit
renvoyer 0 résultat, l'assertion doitporter sur ce 0, pas sur l'absence d'erreur.

## 4. Un test qui échoue pour la mauvaise raison est pire qu'un échec

Avant de croire un test vert, savoir **pourquoi** il passe. Un composant qui rend `null` fait
passer un `expect(getByTestId(...)).toBeTruthy()` si le `getByTestId` est mal utilisé… non : il
le fait échouer. Le vrai piège est l'inverse — un mock qui absorbe tout.

Règle : si un test passe alors qu'une dépendance est mockée, vérifier que le mock **n'a pas
reproduit la logique testée**. Un test qui reimplémente la règle qu'il est censé vérifier
teste sa propre copie, et passe.

## 5. Couverture : la présence n'est pas la vérification

Un fichier de test sans **cas** ne compte pas. C'est la distinction que `state.js start`
applique mécaniquement : `test_count: 0` sur une slice marquée terminée = faux signal, le
défaut le plus coûteux parce qu'il rend le suivi faux **sans aucun signal**.

## 6. Le contrat réel, pas le mock

Les tests d'autorisation, de data scope et de limites de requête s'exécutent **contre le
contrat backend réel**. Un mock d'axios peut dissimuler une divergence de contrat — c'est-à-dire
exactement le faux vert que la vérification en direct d'un backend réel a déjà rattrapé dans le
projet de référence.

Le mock est légitime pour l'UI sans backend (port en mémoire), jamais pour prouver une
propriété de sécurité.

## 7. Non-régression : écrire le test avant le correctif

Quand un bug est trouvé : écrire d'abord le test qui échoue, puis corriger. Un correctif sans
test qui échoue beforehand n'a rien prouvé — il peut corriger le symptôme et laisser la cause.

## 8. Les états sont des cas de test, pas un détail d'affichage

Pour tout composant affichant des données, il existe un test par état nommé
(`data-and-state.md` § 5). Un composant qui n'a un test que pour `success` n'est pas testé.

En particulier : `empty` ≠ `success` avec zéro ligne ; `forbidden` ≠ `error` ; `stale` doit
préserver la valeur affichée et exposer son horodatage.

## 9. Accessibilité testée

Pour toute interaction : assertion sur le **rôle et le nom accessible**, pas sur la classe CSS
ni sur l'implémentation. Un test qui passe en vérifiant une classe ne prouve pas que
l'élément est atteignable au clavier.
