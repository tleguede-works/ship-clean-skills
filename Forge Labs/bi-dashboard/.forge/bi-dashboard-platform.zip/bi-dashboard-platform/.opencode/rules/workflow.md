# Workflow de planification (Forge)

> Règles de **comportement** de l'agent pendant la planification. Les conventions techniques
> (stack, nommage, typage) sont dans `.forge/conventions.md` et ne sont pas répétées ici.
> Les règles transversales sont dans `AGENTS.md`.

## Ordre des phases

`0 bootstrap → 1 PRD → 2 roadmap → 3 design → 4 architecture → 5 plans → 6 tests → 7 implémentation → 8 validation`

Chaque phase se termine par un **gate humain explicite**. Ne jamais entamer la phase suivante
sans approbation. Le silence, une question, ou un « ok » ambigu ne valent pas approbation.

## Journal de session

Ce dépôt tient **quatre** fichiers de mémoire, et un gate les rend actif. Un fichier jamais écrit
est un fichier inerte.

| Fichier          | Contenu                                         | Écrit quand                                         |
| ---------------- | ----------------------------------------------- | --------------------------------------------------- |
| `SESSION_LOG.md` | Le récit de la session, 8 champs                | **Avant de terminer** toute session qui a travaillé |
| `DECISIONS.md`   | Décisions d'architecture fermées                | À la clôture d'une décision de fond                 |
| `LEARNINGS.md`   | Corrections apprises, avec domaine de promotion | Quand une faute est répétée                         |
| `.forge/audit/`  | Journaux de Forge (machine + incidents)         | Par Forge, automatiquement                          |

**Le gate :** avant tout `git commit` et avant de terminer une session, `SESSION_LOG.md` contient une
entrée pour cette session. Si le fichier n'a pas été modifié dans la session, c'est une session
sans travail — sinon c'est une entrée manquante.

**Ce qui ne compte pas comme travail :** lire des livrables, poser une question, corriger une faute
de forme. Ce qui compte : un livrable produit ou modifié, une décision fermée, une gate franchie.

**Le format est imposé par le skill** `project-rules-architect` : 8 champs, du plus ancien au plus
récent — `STARTED FROM` · `DECIDED` · `REJECTED` · `BLOCKED` · `FILES TOUCHED` · `STATUS` ·
`NEXT SESSION SHOULD` · `NEXT SESSION SHOULD NOT`. Ne pas le reformater.

**`REJECTED` est le champ le plus utile et le plus souvent omis.** C'est là qu'on note ce qui a été
proposé puis écarté, et surtout **pourquoi** — sans quoi la session suivante repose la même
question. Le `DECISIONS.md` ne suffit pas : il ne conserve que les décisions _closes_, pas les
hypothèses qui ont péri en chemin.

**Ce que `SESSION_LOG.md` ne porte jamais** : le statut d'un livrable (c'est `state.json`), une
décision d'architecture (c'est `DECISIONS.md`), le détail d'une correction (c'est
`LEARNINGS.md`). Trois faits, trois propriétaires, aucune superposition.

## Oùvit un livrable

| Livrable            | Chemin canonique                 |
| ------------------- | -------------------------------- |
| PRD                 | `.forge/prd.md`                  |
| Roadmap             | `.forge/roadmap.md`              |
| Conventions         | `.forge/conventions.md`          |
| Benchmarks          | `.forge/benchmarks.md`           |
| Design system       | `.forge/design/design-system.md` |
| Écran               | `.forge/design/screens/<nom>.md` |
| Architecture        | `.forge/architecture.md`         |
| Plan de slice       | `.forge/plans/<slice>.md`        |
| Plan de test global | `.forge/test-plan.md`            |

`state.js register` **refuse** tout chemin hors de `.forge/` et tout chemin non canonique.
Un livrable écrit ailleurs n'est pas un livrable : il est perdu. En cas de Need, utiliser
`forge-guard.js strays --relocate` plutôt que copier à la main.

## Qui fait foi

- `.forge/state.json` est l'**autorité** du statut.
- Le champ `status:` du front matter d'un `.md` est un **miroir**, écrit uniquement par
  `state.js set-status`. Jamais à la main.
- `content_hash` porte sur le **corps** du document : changer un statut n'invalide pas un plan ;
  éditer le corps d'un document approuvé le rend `stale` — c'est le but.

Divergence détectée → `forge-guard.js sync .` (exit 1) puis `--fix`.

## Identifiants stables

| Préfixe | Désigne                            | Exemple |
| ------- | ---------------------------------- | ------- |
| `B`     | règle métier                       | `B12`   |
| `E`     | edge case                          | `E7`    |
| `C`     | contrainte                         | `C3`    |
| `F`     | constat routé (`state.js finding`) | `F-001` |

Un ID n'est **jamais réutilisé**, même si la règle disparaît. Chaque ID doit être tracé jusqu'à
un critère de test ou un critère d'acceptation dans un plan de slice. Un ID qui ne renvoie
nulle part est une affirmation non vérifiée.

## Cycles de vie d'une slice

`identified → planned → in_progress → implemented → validated`

Une slice ne passe pas à `implemented` sans **des cas de test**, pas un fichier de test.
`state.js start` signale les slices marquées terminées avec `test_count: 0` : c'est le premier
signal fiable, traiter avant tout le reste.

`check-stale <slice>` avant de l'implémenter : il compare le hash du plan et détecte la dérive
des documents amont (`prd`, `architecture`, `conventions`, `design_system`).

## Règle d'exhaustivité

Avant de présenter un document majeur, se relire sous **deux postures** :

1. **Qualité** — quels cas d'usage, edge cases, contraintes non fonctionnelles manquent ?
2. **Risques** — quelles contradictions internes, hypothèses non vérifiées, angles morts ?

Un document relu une seule fois n'est pas relu. Corriger ce que la deuxième posture trouve, puis
présenter la liste des corrections **et** la liste de ce qui reste à trancher.

## Écrire un constat

Un constat sans domaine de promotion n'a nulle part où aller : il reste un journal.

```bash
node .agents/skills/forge/scripts/state.js finding "$PWD" --domain=architecture.md --severity=majeur "<fait>" "<correction>"
```

Le domaine doit nommer le fichier de règles visé. Un bug, une divergence ou un incident qui ne
correspond à aucune règle vont dans `.forge/audit/issues.md`, **pas** dans `state.json`.

## Multi-perspective obligatoire

Avant les gates **PRD**, **architecture** et **validation finale**, deux perspectives
différentes doivent avoir analysé le document — l'objectif n'est pas de dire « c'est bon » mais
de trouver ce que la perspective principale a manqué. Documenter les deux lectures dans le
compte rendu du gate.
