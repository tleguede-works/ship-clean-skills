# LEARNINGS.md — corrections apprises

Fichier **append-only**. Une ligne par faute **réellement observée**, ajoutée quand l'agent se
trompe deux fois — jamais une règle spéculative sur un problème qui n'est pas encore arrivé.

> Une entrée qui n'atteint jamais un fichier de règles n'a rien changé. Chaque ligne indique le
> **domaine** de promotion : le fichier de `.opencode/rules/` qui doit l'accueillir. Une entrée
> sans domaine est un journal, pas une règle.

## Format

```markdown
- AAAA-MM-JJ — <la faute, formulée comme un contraste : "ne pas X, le comportement correct est Y">
  → domaine: <fichier de règles visé> | Seen: <où>
```

## Corrections

- 2026-09-29 — Ne pas écrire un contrôle de caractères corrupted en PowerShell (`Get-Content -Raw` + regex `\u`) : il renvoie 0 même sur un fichier corrompu, donc un faux vert. Utiliser Node avec une **liste blanche** de plages autorisées, et tester le détecteur sur des entrées corrompues connues avant de croire un scan à 0.
  → domaine: workflow.md | Seen: détection d'un caractère parasite que le contrôle déclarait absent

- 2026-09-29 — Ne pas considérer un scan « 0 problème » comme une preuve sans avoir vu le scan accrocher sur une entrée volontairement corrompue. Un contrôle jamais vu échouer n'est pas validé, il est inconnu.
  → domaine: testing.md | Seen: le scan est resté à 0 pendant que le fichier contenait `U+1EE1`, hors des plages CJK testées

- 2026-09-29 — Ne pas « porter le pattern » d'un projet en copiant son contenu. Le pattern (revue avant commit, ports/adapters, mémoire inter-sessions) est portable ; les noms de fichiers, bibliothèques et termes de workflow ne le sont pas.
  → domaine: architecture.md | Seen: au moment de décider si le profil de règles Next.js existant était réutilisable

- 2026-09-29 — Ne pas filtrer un inventaire de fichiers pour « alléger » la sortie : `-Exclude "*.jsonl"` a masqué `.forge/audit/run-log.jsonl`, et j'ai conclu devant l'utilisateur que le journal de session n'existait pas. Le format du fichier est une propriété de l'outil, pas un détail de présentation.
  → domaine: workflow.md | Seen: question « je n'ai pas vu de fichier de session » sur un projet pourtant correctement initialisé

- 2026-09-29 — Ne pas déduire le schéma d'un journal de données en devinant les noms de champs : j'ai affiché `event`, `phase`, `key` et obtenu des colonnes vides, alors que le champ s'appelait `type`. Une colonne vide est un signal que la requête est fausse, pas que la donnée manque — lire une ligne brute avant d'agréger.
  → domaine: workflow.md | Seen: 19 événements affichés sans type, alors que le journal était complet

- 2026-09-29 — Ne pas échouer silencieusement sur une édition après approbation. Modifier le corps d'un livrable `approved` puis laisser le statut tel quel produit un document que personne n'a validé. Remettre `draft`, re-hacher, puis faire ré-approuver : le garde-fou l'interdit de toute façon, autant que le statut le dise aussi.
  → domaine: workflow.md | Seen: `forge-guard` a échoué sur `content_hashes_current` après l'ajout des règles `B31`–`B35`

- 2026-09-29 — Ne pas valider une citation d'identifiant en testant seulement que **l'identifiant existe**. J'ai écrit 22 références `B*` dans trois spécifications d'écran et n'ai vérifié que leur présence dans le PRD : **8 sur 22 étaient fausses**. Le contrôle disait « tous présents dans le PRD » — vrai, et parfaitement inutile, parce que `B5` existe et ne parle pas de ce que j'avais écrit. Une référence fausse est plus grave qu'une référence absente : elle donne l'apparence d'une traçabilité vérifiée. **Il faut comparer chaque citation à la définition de la règle, pas à son existence.** Et effectuer ce contrôle avec les moyens du projet (extraction du texte de chaque règle), pas de mémoire.
  → domaine: workflow.md | Seen: 8 `B*` mal citées dans `wizard-etape-1/2/3` — `B11` (trois étapes du wizard) cité pour l'immutabilité de la version publiée, `B24` (restauration de version) cité pour la conservation de saisie, `B16` (brouillon non détruit) cité pour le partage nominatif

- 2026-09-29 — Ne pas énoncer un interdit sans connaître la **voie de sortie**, et ne pas la découvrir en la violant. « Ne jamais éditer `state.json` à la main » est la règle que j'ai écrite ; or `state.js` n'a **aucune commande de suppression**, donc une clé enregistrée par erreur ne se retire autrement. J'ai violé ma propre règle et constaté le fait en même temps. Une règle doit dire ce qu'on fait **quand elle ne peut pas être suivie** — sinon elle s'enfraint en silence, et l'exception reste inconnue de tout le monde sauf de celui qui l'a découverte. Ici l'exception légitime est : « sauf pour retirer une clé erronée, en le consignant ». Voir INC-008.
  → domaine: workflow.md | Seen: clé `probe` enregistrée par erreur en Phase 5, retirée par script Node faute de commande dédiée

- 2026-09-29 — Ne pas conclure « ce fichier est inutile, un autre fait déjà le travail » sans avoir lu la **frontière de propriété** que l'outil ayant produit ce fichier déclare. L'argument « doublon » n'a de valeur que si les deux fichiers revendiquent le **même fait**, pas le même domaine. Ici, un journal machine (`run-log.jsonl` : quelles commandes ont tourné) et un journal humain (`SESSION_LOG.md` : ce qui a été décidé et pourquoi) ne dérivent pas l'un de l'autre. Et un contrat d'agencement — ici le tableau de répartition du skill `project-rules-architect` — prime sur une décision de session : sans lui, le skill est décoratif.
  → domaine: workflow.md | Seen: ADR-004 affirmait « pas de `SESSION_LOG.md` car Forge tient déjà le journal » ; l'utilisateur a cherché le fichier, et le skill l'exigeait explicitement

## Constats non promus

_(rien pour l'instant — un constat sans domaine de promotion va dans `.forge/audit/issues.md`, pas ici)_
