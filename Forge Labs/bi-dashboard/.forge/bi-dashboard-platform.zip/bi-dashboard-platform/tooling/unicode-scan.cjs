// unicode-scan.cjs — détecte les caractères parasites dans les documents générés.
//
// PÉRIMÈTRE : uniquement le contenu que ce projet écrit. `.agents/` est du code tiers
// installé (les skills) : le scanner n'a pas à juger le contenu de quelqu'un d'autre.
//
// CONTEXTE : ce dépôt est francophone. Un contrôle « CJK only » a laissé passer
// `_USERNAMEOục` (U+1EE1, Latin Extended Additional) en FBVERT <!-- unicode-scan:ignore (citation du défaut) -->, et un contrôle
// PowerShell `Get-Content -Raw` + regex \u ne détectait rien du tout. Un contrôle
// qui ne détecte rien ne protège de rien : d'où l'approche par LISTE BLANCHE.
//
// Stratégie : autorisé = ASCII + Latin-1 + Latin Extended-A (accents français) +
// ponctuation générale + symboles + emoji (avec leur sélecteur U+FE0F) +
// CJK/kana/hangul (citations d'incident). Tout le reste est signalé.
//
// Une ligne contenant `unicode-scan:ignore` est ignorée : sert à citer un défaut
// dans le journal d'incidents sans déclencher de faux positif sur la citation elle-même.
const fs = require("fs");
const path = require("path");

const root = process.argv[2] || process.cwd();
// Contenu tiers + l'auto-test lui-même (fixtures corrompues par design).
const SKIP = new Set([
  "node_modules",
  ".git",
  ".next",
  "coverage",
  ".codegraph",
  ".agents",
  "scan-selftest.cjs",
]);
const exts = new Set([
  ".md",
  ".json",
  ".ts",
  ".tsx",
  ".js",
  ".mjs",
  ".cjs",
  ".yml",
  ".yaml",
]);

const inRange = (cp, a, b) => cp >= a && cp <= b;

function verdict(cp) {
  if (cp === 9 || cp === 10 || cp === 13) return null; // tab, LF, CR
  if (cp < 32 || cp === 127) return "Control";
  if (cp === 0x7f) return "Control";
  if (cp < 127) return null; // ASCII
  if (inRange(cp, 0xa0, 0xff)) return null; // Latin-1 Supplement (à, é, ç, œ, « »…)
  if (inRange(cp, 0x100, 0x17f)) return null; // Latin Extended-A
  if (inRange(cp, 0x2000, 0x206f)) return null; // General Punctuation (— – " " …)
  if (inRange(cp, 0x20a0, 0x20bf)) return null; // Currency
  if (inRange(cp, 0x2100, 0x214f)) return null; // Letterlike (×, №)
  if (inRange(cp, 0x2190, 0x21ff)) return null; // Arrows
  if (inRange(cp, 0x2200, 0x22ff)) return null; // Math operators
  if (inRange(cp, 0x2500, 0x27bf)) return null; // Box drawing + misc symbols
  if (inRange(cp, 0x2e00, 0x2e7f)) return null; // Supplemental punctuation (CJK quotes)
  if (inRange(cp, 0xfe00, 0xfe0f)) return null; // Variation selectors (⚠️ = U+26A0 U+FE0F)
  if (inRange(cp, 0x1f000, 0x1faff)) return null; // Emoji
  if (cp === 0xfeff) return "BOM";
  if (cp === 0xfffd) return "Replacement";
  if (
    inRange(cp, 0x4e00, 0x9fff) ||
    inRange(cp, 0x3040, 0x30ff) ||
    inRange(cp, 0xac00, 0xd7af)
  )
    return "CJK";
  // Tout le reste : autres systèmes d'écriture, Latin étendu supplémentaire, etc.
  return "OutOfContext";
}

let files = 0;
let findings = 0;

function walk(dir) {
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    if (SKIP.has(entry.name)) continue;
    const abs = path.join(dir, entry.name);
    if (entry.isDirectory()) {
      walk(abs);
      continue;
    }
    if (!exts.has(path.extname(entry.name))) continue;

    files++;
    const lines = fs.readFileSync(abs, "utf8").split("\n");

    lines.forEach((line, i) => {
      if (line.includes("unicode-scan:ignore")) return;
      const seen = new Set();
      for (const ch of line) {
        const kind = verdict(ch.codePointAt(0));
        if (!kind) continue;
        const tag = `${kind}:U+${ch.codePointAt(0).toString(16).toUpperCase().padStart(4, "0")}`;
        if (seen.has(tag)) continue; // un même caractère répété ne se signale qu'une fois
        seen.add(tag);
        findings++;
        const rel = path.relative(root, abs);
        console.log(
          `${kind}\tU+${ch.codePointAt(0).toString(16).toUpperCase().padStart(4, "0")}\t${rel}:${i + 1}\t${line.trim().slice(0, 100)}`,
        );
      }
    });
  }
}

walk(root);
console.log(`\nscan: ${files} files, ${findings} problem(s)`);
process.exit(findings > 0 ? 1 : 0);
