// Auto-test du détecteur : un scan à 0 ne vaut rien tant qu'on ne l'a pas vu accrocher.
// Écrit en Node (le BOM ajouté par Set-Content -Encoding utf8 faussait le test précédent).
const fs = require("fs");
const path = require("path");

const dir = path.join(
  process.env.LOCALAPPDATA || "/tmp",
  "Temp",
  "opencode",
  "scan-selftest",
);
fs.rmSync(dir, { recursive: true, force: true });
fs.mkdirSync(dir, { recursive: true });

const cases = [
  ["latin-extended-additional.md", "phrase avec ục parasite\n"],
  ["cjk.md", "中文 parasite\n"],
  ["hebrew.md", "טקסט זר\n"],
  ["bip.md", "bip\n"],
  ["bom.md", "﻿avec un BOM\n"],
  // DOIVENT être propres : le français normal, la ponctuation, les symboles, le CJK cité.
  ["ok-french.md", "accent : é à ç œ « » — × 20 % ≤ → ✓\n"],
  ["ok-ignoré.md", "焦 cité <!-- unicode-scan:ignore -->\n"],
];

for (const [name, content] of cases) {
  fs.writeFileSync(path.join(dir, name), content, "utf8");
}
console.log(`selftest fixtures written to ${dir}`);
