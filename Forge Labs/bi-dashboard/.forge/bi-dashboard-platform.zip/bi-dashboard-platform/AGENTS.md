# AGENTS.md — Plateforme BI configurable

> Ce fichier est la **source unique** pour les règles transversales. Tout fichier de règle
> applicatif ne doit pas reformuler une règle présente ici : il la référence par son §.

## Définition de Done

Aucun travail n'est « terminé » tant que ces quatre points ne sont pas tous vrais. Le statut
`done` d'une session ne vaut pas approbation : l'approbation humaine est un acte distinct.

1. **Garde-fous Forge verts** (voir §Commandes) — `pass: true` sur `forge-guard.js all` **et**
   `consistency-check.js all`.
2. **Aucun livrable hors de `.forge/`** — un document de planification écrit ailleurs est perdu.
3. **Les IDs existent** — toute règle métier (`B*`), edge case (`E*`) et contrainte (`C*`) posée
   porte son ID stable et est tracée jusqu'à un critère de test ou un critère d'acceptation.
4. **Aucune régression de frontière** — les interdits d'import du §Frontières tiennent encore
   (vérifiable par grep, §Commandes).

Quand le squelette applicatif existera, deux points s'ajouteront : `lint` et `typecheck` sans
erreur, suite de tests verte. Ils sont volontairement absents tant qu'aucun `package.json`
n'existe — une commande qui ne peut pas s'exécuter ne fait pas partie de la définition de done.

## Commandes

> **Deux outils, deux exécuteurs — ne pas les confondre.** L'**outillage Forge** s'exécute par
> `node` : ce sont des scripts CommonJS d'un actif partagé, et les changer d'exécuteur changerait
> leur comportement sans qu'on le voie. Le **projet** s'exécute par `bun` : c'est son gestionnaire
> de paquets (ADR-008). `bun.lock` / `node_modules/` du projet n'ont rien à voir avec le `node` qui
> lance les commandes ci-dessous.

Les scripts du skill Forge vivent dans ce dépôt, sous `.agents/skills/forge/scripts/`.

```bash
# 1. L'état RÉEL — première commande de chaque session
node .agents/skills/forge/scripts/state.js start "$PWD"

# 2. Garde-fous, avant chaque gate
node .agents/skills/forge/scripts/forge-guard.js all        "$PWD"   # pass: true
node .agents/skills/forge/scripts/consistency-check.js all "$PWD"   # pass: true

# 3. Corruption Unicode (défaut récurrent, voir INC-002 et INC-003)
node tooling/unicode-scan.cjs "$PWD"                                  # exit 0 = propre
```

> **Version de Node.** Épinglée dans `.node-version`, lue par `fnm`. Ne jamais figer une version de
> runtime dans une commande ou un script : un `fnm use` joué hors du bon répertoire change le
> runtime **sans aucun signal**. Le fichier est créé avec le squelette du projet, en Phase 7.

> **Pourquoi cette forme de commande.** Les scripts sont CommonJS ; sans un
> `.agents/skills/forge/scripts/package.json` déclarant `"type": "commonjs"`, un projet hôte
> ESM fait échouer `node` sur `require is not defined`. Ce fichier fait partie du skill
> installé. Le bug est documenté et reproduit dans `.forge/audit/issues.md` (`INC-001`).

`state.js start` affiche la phase réelle, les gates en attente, les slices marquées faites
**sans cas de test**, et les documents en dérive de hash. Ne jamais reconstruire cet état de
mémoire.

Le scan Unicode utilise **Node** et une liste blanche de plages, pas PowerShell : un contrôle
qui n'a jamais été vu échouer ne protège de rien. Vérifier le détecteur lui-même avec
`node tooling/scan-selftest.cjs` (5 cas corrompus, 2 cas propres).

## Ce que ce projet est

Une bibliothèque React headless + une application Next.js de référence permettant à des
utilisateurs métier de **créer, configurer, publier, partager et consulter des vues BI**
(dashboards composés de widgets), sans développement à chaque nouveau besoin d'analyse.

Trois interdits structurants, non négociables. Forme détaillée : `security.md` et
`data-and-state.md` § 1.

1. **Aucune requête SQL client.** Le modèle de requête est déclaratif, fermé, versionné.
2. **Aucun code exécutable dans une configuration sauvegardée.** Ni fonction, ni composant,
   ni script, ni HTML brut, ni secret. Un widget est résolu par une **clé stable** dans un
   registre côté hôte.
3. **Le client n'est jamais la frontière de sécurité.** Le masquage d'un bouton est du confort
   d'interface ; l'autorité est le service qui exécute la requête.

## Frontières de couches

Ces règles sont les plus coûteuses à rattraper après coup, parce qu'une dépendance circulaire
entre le core et l'hôte rend le package non extractible.

**Le tableau des frontières et ses commandes de vérification sont dans
`.opencode/rules/architecture.md`** — une seule source, ici on n'en garde que l'intention :

- `src/core` n'importe que Zod. Ni React, ni Next, ni Axios, ni l'app de référence.
- Seul `src/next` importe `next/*`.
- Aucun module `src/**` n'importe l'app de référence (`pilot/`).

Toute dépendance externe dont l'hôte a besoin d'un variant devient un **port** défini dans
`src/core` — voir `architecture.md` § Port plutôt que dépendance.

## Projet de référence

`ace3i-bankingsms-ui` est déclaré **lecture seule** dans `.forge/state.json`. C'est le premier
hôte pilote, pas une dépendance.

- **Le développement du socle se fait ici**, dans `pilot/` et `src/**`. On n'écrit pas de code du
  socle dans `ace3i-bankingsms-ui`. Seul un **point d'entrée d'intégration** y est installé, quand
  c'est nécessaire, pour brancher la vue BI sur son backend et ses droits réels (ADR-006).
- Ne jamais importer depuis ce projet les noms de fichiers, bibliothèques ou conventions de
  l'app de référence (Redux, `RequirePermission`, `PageLayout`, `lib/routes.ts`, Base UI,
  `SESSION_LOG.md`…). Le _pattern_ est portable, le _contenu_ ne l'est pas.
- L'intégration dans ACE3i s'ouvre dans ce dépôt et s'exécute dans l'autre : ici le socle, là-bas
  le branchement. Le **package npm** reste interdit tant que `C6` n'est pas satisfait — ce qui
  s'installe dans `ace3i` est un point d'entrée interne, pas une publication.

## Mémoire inter-sessions

| Fichier                      | Propriété | Contenu                                                                                                             |
| ---------------------------- | --------- | ------------------------------------------------------------------------------------------------------------------- |
| `.forge/state.json`          | Forge     | **Autorité** du statut. Jamais édité à la main.                                                                     |
| `.forge/audit/run-log.jsonl` | Forge     | Journal machine des événements                                                                                      |
| `DECISIONS.md`               | ce projet | Décisions d'architecture **fermées** — ne jamais rouvrir sans le dire                                               |
| `LEARNINGS.md`               | ce projet | Corrections apprises, append-only, une ligne par faute récurrente                                                   |
| `SESSION_LOG.md`             | ce projet | Récit de session :Started From, Decided, Rejected, Blocked, Files Touched, Status, Next Session Should / Should Not |

Ces quatre fichiers sont **complémentaires, pas concurrents**. `run-log.jsonl` dit _quelles
commandes Forge ont tourné_ ; `SESSION_LOG.md` dit _ce qui a été décidé et pourquoi_. Aucun ne
dérive de l'autre.

> **Lire `SESSION_LOG.md` en entier au début de chaque session**, avant d'ouvrir `.forge/`. C'est
> le seul endroit qui dise pourquoi une décision a été remise en cause — information qu'aucun
> autre fichier ne sait déduire.

Le format de `SESSION_LOG.md` est imposé par le skill `project-rules-architect` : 8 champs par
entrée, du plus ancien au plus récent. Ne pas le reformater sans vérifier le tableau de répartition
de ce skill.

## Règles de workflow

Détail dans `.opencode/rules/workflow.md`. Les quatre qui comptent :

1. **Les gates humains ne se négocient pas.** Aucune phase suivante sans approbation explicite.
   Le silence n'est pas une approbation.
2. **`state.json` fait foi.** Le front matter `status:` d'un `.md` est un miroir écrit par
   `state.js set-status` — jamais à la main.
3. **Aucun livrable hors `.forge/`.** Jamais de contenu de document dans `state.json`.
4. **Exhaustivité avant vitesse.** Un plan superficiel mais cohérent est pire qu'un plan lent
   et complet.

## Escalade

- **Bloqué par une décision produit** → arrêter, formuler la question, attendre. Ne pas choisir
  à la place de l'utilisateur et ne pas avancer sur une supposition.
- **Blocage technique** → tenter une correction bornée (2 essais), puis **arrêter et rapporter**
  le symptôme exact, la cause racine observée et le contournement tenté. Ne jamais élargir le
  périmètre pour contourner un blocage.
- **Constat sans domaine de promotion** → il va dans `.forge/audit/issues.md`, pas dans un
  fichier de règles.

### Interdits absolus

- Modifier `ace3i-bankingsms-ui`, **sauf l'installation du point d'entrée** prévue par **ADR-006** :
  le code du socle se développe dans **ce** dépôt (`pilot/`, `src/**`), et `ace3i` ne reçoit que
  l'intégration minimale qui le branche sur son backend et ses droits réels. **Jamais de
  développement dans le projet de référence.** L'installation reste réversible et séparée (un
  commit identifiable), `state.json` reste `read_only: true`, et l'outillage de protection reste
  armé (INC-005). Elora reste en lecture seule, sans exception.
- Éditer `state.json` à la main pour lever une protection outillage. Si une décision exige de
  contourner un garde-fou, elle se prend dans `DECISIONS.md` et l'outillage se signale
  (voir INC-005) — on ne désarme pas une vérification pour qu'un fichier dise ce qui est vrai.
  **Exception unique et connue** : retirer une clé enregistrée par erreur. `state.js` n'a aucune
  commande de suppression (`register` est à sens unique), donc l'édition manuelle est la seule voie
  — et elle doit être consignée dans `.forge/audit/issues.md` (INC-008). Une règle sans exception
  connue s'enfraint en silence ; celle-ci est donc écrite.
- Écrire un statut à la main dans un front matter `.forge/`.
- Écrire un livrable Forge hors de `.forge/`.
- Avancer une phase sans gate.
- Marquer une slice « faite » sans qu'elle contienne **des cas de test**, pas un fichier de test.
- Introduire une dépendance runtime (Redux, Axios, une librairie de formulaires, un moteur de
  grille) dans `src/core` ou `src/react`.
- Supprimer une règle existante pour « faire plus court » : une règle sans fait d'observation
  derrière est candidate à la fusion, jamais à la suppression.

## Où vivent les choses

| Quoi                                                                       | Où                        |
| -------------------------------------------------------------------------- | ------------------------- |
| Intentions produit, règles métier (`B*`), edges (`E*`), contraintes (`C*`) | `.forge/prd.md`           |
| Découpage en versions                                                      | `.forge/roadmap.md`       |
| Conventions techniques (stack, nommage, typage)                            | `.forge/conventions.md`   |
| Architecture, slices, dépendances                                          | `.forge/architecture.md`  |
| Plan d'implémentation d'une slice                                          | `.forge/plans/<slice>.md` |
| Stratégie de test globale                                                  | `.forge/test-plan.md`     |
| Règles de comportement de l'agent                                          | `.opencode/rules/*.md`    |
