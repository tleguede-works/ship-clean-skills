# DECISIONS.md — Plateforme BI configurable

## Règle

Ce projet couvre plusieurs sessions avec un contexte qui repart de zéro. Sans ce fichier
respecté, une IA sans mémoire va périodiquement reproposer des alternatives déjà écartées —
sLoss ce qu'on construit et en refaisant le débat.

**Une décision consignée ici est fermée.** Elle ne doit être ni reproposée, ni retournée
silencieusement, même si elle paraît sous-optimale pour la tâche en cours.

Si une décision fermée est **actuellement fausse** : le dire explicitement, nommer la décision
et l'endroit où elle est consignée, expliquer en quoi elle ne tient plus ici, et **s'arrêter
pour demander** avant de procéder autrement. Ne pas simplement construire l'alternative.

Consigner une décision ici, plutôt que dans un plan de slice, quand elle s'applique à plusieurs
slices. Si elle devait être répétée ou redébatue dans chaque plan qui la touche, c'est ici
qu'elle appartient.

Ce fichier est **append-only**. Ne jamais supprimer une entrée : si une décision change, on
ajoute une nouvelle entrée qui la supersède et on renvoie à l'ancienne.

## Format d'une entrée

```markdown
## ADR-<NNN>: <Titre>

- Date: <YYYY-MM-DD>
- Statut: Actif / Supersédé par ADR-<NNN>
- Contexte: <ce qui a déclenché la décision>
- Décision: <ce qui est décidé>
- Alternatives considérées: <quoi d'autre, et pourquoi rejeté>
- Conséquences: <à quoi cela engage les phases suivantes>
```

## Journal

## ADR-001: Un monolithe modulaire d'abord, pas des packages publiés

- Date: 2026-09-29
- Statut: Actif · **Remplacé sur un point par ADR-006**
- Contexte: le besoin initial est de valider le concept dans un projet React/Next.js avant toute
  standardisation en package npm. Deux voies : un gros module `features/bi` à extraire plus tard,
  ou des frontières de package dès le début.
- Décision: construire dans **ce** dépôt (`bi-dashboard-platform`) un monolithe modulaire —
  application Next.js de référence + `src/core`, `src/react`, `src/ui`, `src/next` — avec les
  frontières d'import imposées dès la première ligne de code. L'extraction en package publié
  n'a lieu qu'après validation par **deux** consommateurs.
- Alternatives considérées: (a) un seul dossier `features/bi` — plus rapide au premier jour, mais
  l'extraction tardive est le moment où l'on découvre les dépendances croisées, au pire coût ;
  (b) des workspaces npm publiés immédiatement — ajoute outillage, peer dependencies et
  problèmes de build sans prouver la valeur métier ; (c) implémenter directement dans
  `ace3i-bankingsms-ui` — contredit sa déclaration en projet de référence **lecture seule**.
  **Ce point a été tranché dans l'autre sens par l'ADR-006** : `ace3i` devient le pilote du MVP.
  L'architecture de ce dépôt ne change pas — le socle reste ici, les frontières d'import restent
  les mêmes — mais l'exception est désormais ouverte côté projet hôte, et **documentairement**.
- Conséquences: le dépôt contient `pilot/` (application de référence) et non un dossier de
  feature dans l'app de référence. L'intégration ACE3i est un chantier qui s'ouvre dans ce dépôt
  et s'exécute dans l'autre. `architecture.md` interdit structurellement une dépendance
  `src/** → pilot`.

## ADR-002: Le client n'est jamais la frontière de sécurité

- Date: 2026-09-29
- Statut: Actif
- Contexte: le produit laisse des utilisateurs non techniques composer des requêtes sur des
  données d'entreprise. Une interface qui masque un champ ou un bouton semble protéger, alors
  que l'appel réseau est reproductible directement.
- Décision: toute décision d'accès est prise par le service qui exécute la requête, sur trois
  contrôles **conjointifs** — accès à la vue, accès à la source/champ/agrégat, périmètre de
  lignes. Le client ne fait que du confort d'interface. Un périmètre non résolu est un **échec
  fermé** (résultat vide), jamais un fallback permissif.
- Alternatives considérées: (a) s'appuyer sur le masquage frontend — rejeté, reproductible ;
  (b) champs sensibles chiffrés côté client — ne remplace pas une autorisation serveur et
  donne une fausse assurance ; (c) vérification de type seule — n'est pas une autorisation.
- Conséquences: `security.md` exige que toute règle de sécurité soit couverte par un test contre
  le **contrat backend réel**, pas un mock. Un droit non testable n'est pas implémenté, il est
  documenté comme non couvert. Le même raisonnement s'applique **en amont du code** : le socle
  définit des **actions** nommées et déléguables séparément, jamais des rôles (§ 4.1 du PRD,
  `B31`–`B34`). Un rôle est une convention sociale du projet hôte ; une action est une capacité
  qui doit exister pour être déléguée. Confondre les deux rend une séparation de droits
  inexprimable — ce qui est arrivé pendant la rédaction du PRD. Corollaire : une action ne se
  sépare d'une autre que si elle est accordable sans elle, ce qui a réduit trois actions
  d'écriture (`view:create` / `view:update` / `view:delete`) à une seule, `view:write` (`B36`).
  Réduire le vocabulaire d'actions n'est pas un renoncement à la finesse : c'est la condition
  pour qu'un pouvoir soit réellement accordable, donc réellement contrôlable.

## ADR-003: Aucun code exécutable dans une configuration sauvegardée

- Date: 2026-09-29
- Statut: Actif
- Contexte: la personnalisation d'une vue passe par une configuration sérialisée. Un composant
  ou une expression stockés dans ce JSON exécuterait du code non revu au moment du rendu.
- Décision: une vue publiée ne contient que des **données** : clés sémantiques, identifiants de
  widget, paramètres de présentation, positions de grille, texte. Les composants sont résolus
  par une **clé stable et versionnée** dans un registre côté hôte. Interdits : fonction,
  composant, `eval`, import dynamique nommé par l'utilisateur, SQL, HTML brut, secret, URL de
  connexion.
- Alternatives considérées: (a) sérialiser le composant lui-même — exécution non revue,
  impossible à migrer ; (b) autoriser des expressions utilisateur — surface d'attaque et
  problème de performance ; (c) champ d'import de module par chemin — contournement du
  registre.
- Conséquences: `data-and-state.md` § 1 porte la liste et la commande de vérification. Le
  registre devient le point d'extension principal du package.

## ADR-004: Le journal de session est humans, pas machine

- Date: 2026-09-29
- Statut: Actif
- Amendé le 2026-09-29 (voir « Histoire » ci-dessous)
- Contexte: le projet de référence utilise un trio `SESSION_LOG.md` / `DECISIONS.md` /
  `LEARNINGS.md`. Forge produit déjà `.forge/audit/run-log.jsonl` (journal machine) et
  `.forge/audit/issues.md` (journal d'incidents du processus).
- Décision: ce dépôt tient **les quatre** fichiers : `SESSION_LOG.md` (récit de session),
  `DECISIONS.md` (décisions fermées), `LEARNINGS.md` (corrections apprises) — et laisse
  `.forge/audit/` à Forge. Les quatre sont complémentaires, aucun ne remplace un autre.
- Alternatives considérées: (a) ne créer que les deux autres, Forge tenant « déjà » le journal —
  **c'était la version initiale de cette décision, elle était fausse**, voir l'amendement ;
  (b) créer les quatre — le risque réel de redondance existe, mais il porte sur les _faits_, pas
  sur les _types de récit_ : chaque fichier a une frontière que le skill définit.
- Conséquences: `state.js start` remonte `project_memory` à partir de `AGENTS.md`, `DECISIONS.md`,
  `LEARNINGS.md`, `SESSION_LOG.md` et `.opencode/rules/`. Un nouveau fichier mémoire doit être
  justifié par une absence réelle, pas par symétrie avec un autre projet.

### Amendement du 2026-09-29

La version initiale affirmait qu'aucun `SESSION_LOG.md` n'était nécessaire parce que
`.forge/audit/run-log.jsonl` tenait déjà le journal. **C'est une confusion de deux faits
différents**, et elle a été découverte en cherchant un fichier que l'utilisateur croyait manquant.

- `run-log.jsonl` est un journal **machine** : il enregistre `init`, `hash`, `status_change`,
  `gate_approved`. Il sait qu'un hash a tourné ; il ne sait pas **pourquoi** la décision qui l'a
  précédé a été remise en cause.
- `SESSION_LOG.md` est un journal **humain** : il porte la séquence des arbitrage, les
  hypothèses rejetées, ce qui bloque, et ce que la session suivante ne doit pas refaire.

Aucun des deux ne dérive de l'autre, donc aucun ne peut le remplacer.

**Erreur de règle, pas d'exécution.** Le tableau de répartition du skill
`project-rules-architect` (`SKILL.md`) attribue explicitement `SESSION_LOG.md` à ce skill, et
n'attribue ce fichier à aucun autre. La décision initiale **violait le contrat du skill** en
inventant une frontière que le skill ne prévoit pas. Un contrat d'agencement prime sur une
décision de session : sans cela, le skill n'est pas exécutable, seulement décoratif.

**Ce que l'erreur a coûté.** Une session qui démarre ne savait pas ce qui avait été décidé
aujourd'hui tant que la conversation n'était pas relue. Le PRD le constatait, mais rien ne
l'exécutait.

**Leçon retenue.** Avant de conclure « ce fichier est inutile parce qu'un autre existe », vérifier
la **frontière de propriété** que l'outil qui a produit le fichier déclare. L'argument
« ça fait doublon » n'a de valeur que si les deux fichiers revendiquent le même fait — pas le même
domaine.

**Une précision de plus, venue après coup.** La conséquence citait `dod_items: 0` rapporté par
`state.js start` comme une mesure. **Ce n'en était pas une** : `state.js` cherche une ancre
anglaise (`## Definition of Done`) dans un document français, et lit donc zéro dans un fichier
rempli. Le chiffre est faux, la conclusion tirée de ce chiffre est juste, et le rapprochement
tient — mais il ne s'appuie pas sur une mesure. Voir INC-004.

**Ce qu'il faut en retenir, sur un plan général** : quand deux outils se répondent l'un à
l'autre — le `.forge` qui lit la mémoire du projet, la mémoire du projet qui s'écrit pour être
lue — **vérifier qu'un compteur non nul prouve quelque chose**. Un `0` qui peut signifier « vide »
ou « non reconnu » est un `0` qui ne prouve rien. C'est le pendant numérique d'INC-003.

## ADR-005: shadcn est le design system par défaut, jamais une dépendance

- Date: 2026-09-29
- Statut: Actif
- Contexte: le projet SMS Banking a été construit avec la commande `shadcn`, et l'usage a donné
  satisfaction — au-delà des composants isolés, la CLI installe aussi des **blocs de page
  entière** (connexion, tableau de bord, barre latérale), qui font gagner un temps
  disproportionné sur la coquille applicative. Notre socle doit pouvoir profiter de cet
  accélérateur sans devenir dépendant d'un modèle de distribution par copie.
- Décision:
  1. **Phase 3 (design)** — l'application de référence adopte shadcn via la CLI, blocs de page
     compris, comme source de design system. C'est un accélérateur, pas une contrainte.
  2. **`src/ui`** — l'implémentation visuelle par défaut du module est construite sur les
     primitives shadcn de l'hôte, mais elle est **remplaçable** et résout ses composants par
     un registre, pas par un import codé en dur.
  3. **Interdit** — ni `src/core` ni `src/react` n'importe un chemin shadcn de l'hôte
     (`@/components/ui/...`). Ces fichiers n'existent que dans un projet ayant lancé la CLI :
     Elora, qui est mobile, ne les aura jamais.
- Alternatives considérées: (a) shadcn en dépendance dure — casse `C1`/`C3` et rend `C6`
  impossible avec Elora ; (b) n'utiliser que des composants unitaires et écrire la coquille à la
  main — c'est précisément ce que la CLI résout en mieux, on perdrait l'avantage pour rien ;
  (c) reprendre la page de tableau de bord du projet SMS Banking telle quelle — c'est un habillage
  d'une application, pas un point de départ réutilisable.
- Conséquences: le mécanisme réel de shadcn est **la copie de code source** : la CLI écrit les
  fichiers dans le projet, qui deviennent la propriété du projet ; seules les véritables
  dépendances (Radix, etc.) sont installées en npm. Toute règle d'architecture doit en tenir
  compte. **Correction d'une inférence antérieure** : la présence de `@dnd-kit` et de
  `@tanstack/react-table` dans le projet SMS Banking ne prouve pas qu'un moteur de grille y était
  prévu — ces paquets sont listés comme dépendances du bloc `dashboard-01` de shadcn. La
  présence est donc expliquée, non justifiée. Le fond reste vrai par ailleurs : `@dnd-kit` n'est
  pas un moteur de grille avec coordonnées, collisions et redimensionnement.
- Portée: `conventions.md` § Stack, `architecture.md` § Frontières.

## ADR-006: `ace3i-bankingsms-ui` devient le pilote du MVP, exception **documentaire**

- Date: 2026-09-29
- Statut: Actif
- Contexte: le PRD désigne « un pilote » sans nommer quel projet. Le choix conditionne la V1.5 :
  tant qu'aucun hôte réel n'a consommé le socle, `C6` reste une hypothèse. `ace3i-bankingsms-ui`
  est le seul candidat disposant d'un **vrai système d'autorisation** derrière — Spring Boot, JWT,
  permissions existantes. `security.md` interdit de considérer une règle de sécurité comme
  testée si elle n'a été éprouvée que contre un faux écrit par nous, ce qui élimine un hôte neuf
  sans droits préexistants.
- Décision: **`ace3i-bankingsms-ui` sert de pilote du MVP**, et l'exception est inscrite **dans les
  documents uniquement** :
  1. `state.json` conserve `read_only: true`. Il n'est **pas** édité à la main.
  2. `AGENTS.md` § Interdits absolus porte l'exemption, nommément, avec sa justification.
  3. `conventions.md` et `roadmap.md` sont mis à jour pour ne pas conserver une règle périmée.
- **Pourquoi l'outillage n'est pas utilisé pour porter l'exception.** `state.js` écrit
  `read_only: true` en dur à l'init (l. 303) et **n'a aucune commande** pour le basculer. Le
  modifier à la main violerait l'interdit « ne jamais éditer `state.json` à la main », et
  `forge-guard` utilise `reference_projects` pour **ignorer** un livrable écrit dans une référence
  (`forge-guard.js` l. 130-131) : passer le champ à `false` désarmerait cette protection
  silencieusement. Une exception mesurée vaut mieux qu'une protection désarmée. Signalé comme
  **INC-005**.
- Alternatives considérées: (a) `read_only: false` à la main — cohérent sur le papier, mais édite
  l'autorité à la main et désarme un garde-fou ; (b) un dépôt neuf comme pilote — respecte la
  frontière, mais teste les **trois contrôles** (`NFR §7.2`), `B25` et `B31`-`B35` contre un faux
  auto-écrit, ce que `security.md`
  interdit ; (c) Elora comme hôte des droits — crédible, mais Elora est déjà le Second hôte de la
  **V1.5** : l'utiliser deux fois ferait de la V1.5 un test contre lui-même.
- **Ce que cette exception ne couvre pas.** `Elora` reste strictement en lecture seule, sans
  exception. Le PRD, la roadmap et la suite de l'architecture ne sont modifiés qu'au moment de
  l'intégration du pilote, et seulement dans le périmètre autorisé.
- Conséquences: l'interdit « ne pas écrire dans `ace3i-bankingsms-ui` » est levé pour **l'intégration
  seulement**, jamais pour du développement. `SESSION_LOG.md` consigne chaque session qui y installe
  quelque chose, avec la liste exacte des fichiers touchés.
- **Où vit le code, tranché le 2026-09-29 (complète cette ADR).** Le socle et l'application de
  référence restent dans **ce dépôt**, sous `pilot/` — la structure déjà décidée par ADR-001. Rien
  n'est développé dans `ace3i-bankingsms-ui`.
  1. **Le socle est développé ici** : `src/core`, `src/react`, `src/ui`, `src/next`, et
     l'application de référence dans `pilot/`.
  2. **`ace3i-bankingsms-ui` n'est pas réécrit.** On y **installe** le socle lorsque c'est
     nécessaire — pour brancher la vue BI sur son backend réel et son autorisation réelle, pas pour
     y porter du développement.
  3. **Ce qui s'installe est un point d'entrée**, pas du code du socle déplacé. Le socle reste ici ;
     `ace3i` reçoit l'intégration minimale qui le branche sur ses endpoints et ses droits.
  4. **L'installation est réversible et séparée** : un commit identifiable, annulable sans toucher
     à l'historique du projet de référence.
- **Pourquoi cette précision était nécessaire.** L'ADR laissait ouvert « le pilote écrit _dans_
  `ace3i` ou _dans ce dépôt_ ». La réponse est : **les deux, mais pas au même endroit ni au même
  moment**. Le développement est ici ; l'intégration est là-bas. Confondre les deux revenait à
  autoriser du développement dans le projet de référence — ce que l'ADR-001 refusait, à juste titre.
- **Ce que cela ne change pas.** `ace3i` reste le **pilote de validation** : c'est lui qui fournit
  l'autorisation réelle contre laquelle les **trois contrôles** (`NFR §7.2`), `B25` et `B31`–`B35`
  seront éprouvées. Le rôle ne
  change pas, seul le lieu d'écriture change — et l'exception d'ADR-006 se resserre d'autant.
- **Le package npm reste interdit** tant que `C6` n'est pas satisfait : ce qui s'installe dans
  `ace3i` est un point d'entrée interne, pas une publication.

## ADR-007: Le moteur de requêtes est un adaptateur, jamais une dépendance

- Date: 2026-09-29
- Statut: Actif
- Contexte: le PRD ne tranche pas le moteur de requêtes, et la roadmap le renvoie en Phase 4. Deux
  voies : le socle définit l'**interface** et chaque hôte fournit son moteur (adaptateur), ou le
  socle expose un **registre** de moteurs et compte sur un moteur « similaire » chez l'hôte.
- Décision: **adaptateur**. Le socle définit le port d'exécution ; il ne connaît aucun moteur
  concret. Un adaptateur est un port : le socle ignore son implémentation. Un registre de moteurs
  n'en est pas un.
- **Pourquoi le registre de moteurs est refusé.** Il paraît plus souple et il est plus rapide à
  écrire, mais il fait dépendre le fonctionnement du socle d'un moteur « similaire » chez l'hôte.
  Or « similaire » n'est pas un contrat, c'est un souhait. Une dépendance de moteur est la manière
  la plus discrète de rendre un socle non réutilisable : elle ne se voit pas, elle se découvre à
  l'intégration — c'est-à-dire trop tard, après la sortie du monolithe.
- Alternatives considérées: (a) registre de moteurs — refusé pour la raison ci-dessus ; (b)
  dépendance directe sur un moteur unique — la rendrait permanente et rendrait `C6` faux ; (c)
  ports multiples avec détection — même défaut que (a), en plus de la complexité.
- Conséquences: **chaque** moteur devient un adaptateur à écrire, pour le pilote comme pour chaque
  hôte. C'est un coût certain contre un risque évité, et il est concentré sur la tranche V1.5.
  ADR-001 s'applique : le socle définit l'interface, il ne l'importe pas.

## ADR-008: `bun` comme gestionnaire, Node épinglé par `.node-version`

- Date: 2026-09-29
- Statut: Actif
- Contexte: `conventions.md` retenait `npm`, avec pour seule justification la « cohérence avec
  l'app de référence ». L'utilisateur choisit `bun` et utilise `fnm` (Fast Node Manager) pour gérer
  ses runtimes Node.
- Décision:
  1. **Le gestionnaire de paquets est `bun`**, pas `npm`. Toutes les commandes de projet passent
     par `bun run <script>`. Le style explicite `bun run` est retenu plutôt que la forme courte
     `bun <script>`, qui ne distingue pas un script du package d'une commande de `bun`.
  2. **La version de Node est épinglée dans `.node-version`**, fichier que `fnm` lit. Le fichier est
     créé **avec le squelette du projet**, pas avant : une version inventée aujourd'hui serait
     fausse au moment de la créer.
  3. **Aucune version de runtime n'est écrite en dur** dans une commande, un script ou une
     instruction de documentation.
- **Pourquoi `bun` — la vraie raison.** Ce n'est pas une préférence de vitesse. Le socle est destiné
  à devenir un package npm (après `C6`). Développer avec `npm` et publier avec `bun` exposerait
  **deux arbres de dépendances**, donc deux résolutions potentiellement différentes entre ce qui
  est testé et ce qui est publié. Or « ce qui est testé n'est plus ce qui est publié » est
  exactement la pathologie « un fait, deux représentations » appliquée à la chaîne de
  distribution. Le gestionnaire doit être **le même** de l'installation à `bun pm pack`.
- **Pourquoi la justification d'origine est abandonnée.** `conventions.md` justifiait `npm` par la
  cohérence avec l'app de référence. Cet argument ne vaut plus : `ace3i-bankingsms-ui` est en lecture
  seule (ADR-006) et un dépôt indépendant n'a pas à hériter du gestionnaire d'un autre dépôt. La
  même correction s'applique aux lignes Lint et Format, qui portaient la même mention caduc.
- Alternatives considérées: (a) `npm` — deux arbres de dépendances entre développement et
  publication, ce que la raison ci-dessus exclut ; (b) conserver « cohérence avec l'app de
  référence » comme argument — un projet de référence en lecture seule n'a pas d'autorité sur
  l'outillage d'un dépôt indépendant ; (c) version de Node en dur dans les scripts — produit un
  runtime silencieux différent selon le répertoire, sans aucun signal.
- **Pièges propres à `bun`, à surveiller.** 1) **Résolution de `node_modules` différente de npm** :
  `bun install` produit un `node_modules` et un lockfile au format propre. Un projet censé tourner
  sous Node doit être testé sous **Node**, pas sous le runtime de `bun` : le gestionnaire est `bun`,
  le runtime reste Node. Confondre les deux ferait valider sous un runtime que l'hôte n'utilisera
  pas. 2) **Durée de vie de `bun` et du format de lockfile** : moins établis que npm, donc
  sensibles aux ruptures de compatibilité — d'où `.node-version` et le verrouillage des versions de
  dépendances. 3) **Les scripts Forge sont en CommonJS** et s'exécutent par `node` : ils restent
  exécutés par `node`, jamais par `bun`, pour ne pas changer le comportement d'un actif partagé
  (voir INC-001, et `AGENTS.md` § Commandes).
- Conséquences: `conventions.md` § Commandes passe en `bun run`; un `.node-version` accompagne le
  squelette du projet en Phase 7; `AGENTS.md` § Commandes distingue les commandes `node` (outillage
  Forge, `node_modules/` ignoré) des commandes `bun` (projet). Le `packageManager` du manifeste
  déclare `bun` pour que l'outil d'installation attendu soit explicite.

## ADR-009: Le port d'exécution retourne l'issue, pas seulement les lignes

- Date: 2026-09-29
- Statut: Actif
- Contexte: ADR-007 a tranché « adaptateur » sans dire ce que l'adaptateur accepte ni ce qu'il rend.
  C'est la décision la plus structurante de la Phase 4, parce qu'elle décide si le noyau peut
  distinguer deux situations qui se ressemblent à l'écran.
- Décision : le port d'exécution a cette forme —

  ```ts
  type ExecutionOutcome = {
    rows: Row[];
    // "resolved" | "unresolved" | "not-applicable"
    scopeState: "resolved" | "unresolved" | "not-applicable";
    truncated: boolean;
    // Requis si truncated. Jamais déduit côté client.
    totalRows: number | null;
    // Date de calcul, fournie par le service (B14)
    calculatedAt: string;
    durationMs: number;
  };
  ```

- **Pourquoi `rows` seul ne suffit pas.** Trois exigences en dépendent, et aucune n'est satisfiable
  avec un tableau de lignes :
  1. **Périmètre non déterminable → résultat vide** (`NFR §7.2`). Le noyau doit pouvoir distinguer
     « aucune donnée sur cette période » (« aucune donnée » n'est pas le même message que « rien »)
     de « votre périmètre n'a pas pu être résolu ». Avec `rows: []` seul, les deux sont
     indistinguables, et l'interface affiche le mauvais des deux messages.
  2. **Troncature** (`E6`) : l'interface doit afficher le compte exact. Un total déduit côté client est
     un **mensonge chiffré** — la somme d'un échantillon présentée comme un total.
  3. **Fraîcheur** (`B14`) : la date de calcul vient de l'exécution, pas de l'heure de réception.
- **Le noyau ne calcule jamais le périmètre de lignes.** Il ne connaît ni l'identité, ni le modèle de
  données. Il reçoit un contexte d'identité et rend `scopeState` ; l'hôte résout. C'est pourquoi
  `scopeState` est un retour et non un paramètre.
- Alternatives considérées: (a) `rows` seul — le noyau ne peut pas distinguer vide-sans-données de
  périmètre-échoué, ni connaître la troncature ; (b) le noyau calcule le périmètre — impossible sans
  connaître le modèle de données de l'hôte ; (c) le port lève une exception en cas de périmètre
  non résolu — transforme un cas d'usage attendu en erreur, et `NFR §7.2` demande un résultat vide,
  pas un échec.
- Conséquences: tout adaptateur d'hôte doit rendre `scopeState` et `totalRows`, y compris quand la
  réponse est vide. Le noyau peut donc garantir `E5`, `E6` et la règle de périmètre sans jamais
  exécuter de requête. `E7` (durée) est rendu par `durationMs` et par le refus de l'hôte : les
  limites sont imposées par le service et ne sont pas négociables (`B21`).

## ADR-010: Le reducer de brouillon est dans `src/core`, pas dans React

- Date: 2026-09-29
- Statut: Actif
- Contexte: le brouillon de création de vue porte des règles : ordre stable (`B26`), immuabilité de
  la version publiée (`B5`, `B6`), blocage « mise à jour requise » (`B12`), refus de publier sans
  indicateur (`B27`).
- Décision : le reducer est une **fonction pure dans `src/core`**, testable sans React ni DOM. L'hôte
  le branche sur la bibliothèque de son choix ; l'implémentation de référence du pilote est
  `useReducer`.
- **Ce n'est pas un choix d'esthétique.** Ces règles sont des règles de métier, pas des états
  d'interface. Un reducer placé dans React ne serait testable qu'à travers un DOM, et une règle de
  sécurité testée à travers une couche d'interface est une règle testée à moitié — ce que
  `security.md` interdit. C'est le même argument que pour le noyau lui-même, appliqué à l'état.
- Alternatives considérées: (a) reducer dans le composant — non testable sans DOM ; (b) bibliothèque
  d'état imposée (`C1`, `C3`) — le noyau imposerait alors une dépendance qu'aucun hôte n'a demandée ;
  (c) le brouillon n'est pas de l'état mais une valeur dérivée — impossible, l'ordre saisi doit être
  conservé (`B26`).
- Conséquences: `src/core` devient testable intégralement sans DOM, ce qui est la condition pour que
  la règle de couverture « chaque `B*` a un test » soit atteignable. L'interface React se réduit à
  câbler le reducer et rendre son résultat.

## ADR-011: La couverture se mesure en règles testées, pas en lignes

- Date: 2026-09-29
- Statut: Actif
- Contexte: `conventions.md` demandait un framework de test, mais pas une métrique. Or dans un cœur
  où cinq règles de sécurité portent l'essentiel du risque, un pourcentage de lignes ne dit rien du
  risque couvert.
- Décision :
  1. **La métrique est le nombre de règles `B*` sans test**, pas le pourcentage de lignes. Un seuil de
     lignes se choisit pour ne pas échouer ; le nombre de règles non testées ne se gonfle pas.
  2. **Chaque test cite l'ID qu'il couvre** dans son nom. Un test qui ne couvre aucune règle n'est pas
     un test de règle.
  3. **Les trois contrôles et `B25` sont vérifiés par un contrat publié**, pas par un mock : le socle
     fournit une suite de tests que l'adaptateur de l'hôte doit passer. Un hôte qui ne la passe pas
     n'est pas conforme, et rien d'autre ne le détecterait.
  4. **`E6` et `E7` sont des tests d'injection de faute**, pas des tests de chemin nominal : un test
     qui ne fait jamais échouer l'exécution ne vérifie pas la troncature.
  5. **Les tests de `src/core` tournent sans React** (ADR-010).
- Alternatives considérées: (a) seuil de lignes — mesurable mais sans rapport avec le risque, et
  susceptible au remplissage cosmétique ; (b) couverture des seuls modules sensibles — laisse les
  règles transversales sans filet ; (c) revue manuelle — non reproductible, donc non exigible en CI.
- Conséquences: le test de contrat devient une **dépendance de la conformité d'un hôte** : il entre
  dans les critères d'un projet comme Elora (V1.5). L'exécution des commandes est re-datée en Phase 5
  (le squelette n'existe pas) ; la **nature** des tests est tranchée ici.

## ADR-012: Le wizard est contrôlé, sans bibliothèque de formulaires

- Date: 2026-09-29
- Statut: Actif
- Contexte: le wizard en trois étapes (US-2, US-3, US-4) gère un formulaire simple à l'étape 1 et un
  catalogue avec aperçus d'exécution réelle à l'étape 2. Un choix d'outillage devait être fait.
- Décision : le wizard est **contrôlé**, sans bibliothèque imposée. Le socle expose son propre type
  `ValidationResult` — jamais un type de bibliothèque.
- **L'argument est technique, et il tient en une règle.** `B1` rend le caractère obligatoire de la
  description **configurable par le projet hôte** : la même vue peut être publiée avec une description
  facultative dans un projet et obligatoire dans un autre. Une bibliothèque de formulaires avec un
  schéma statique se bat contre cette règle, parce que son schéma est construit une fois.
- **La complexité réelle n'est pas dans le formulaire.** L'étape 2 est un catalogue avec des options
  filtrées par droits et des aperçus exécutés ; cette logique appartient à `src/core`, pas au
  formulaire. Une bibliothèque aurait résolu la moitié facile du problème et laissé la difficile.
- Alternatives considérées: (a) bibliothèque imposée — impose une dépendance et un type de validation
  dans le contrat public, contre `C3` ; (b) bibliothèque en implémentation de référence du pilote —
  possible, mais elle n'aurait pas résolu `B1` et aurait déplacé la vraie complexité ailleurs ;
  (c) formulaire non contrôlé — impossible à tester sans DOM (ADR-010).
- Conséquences: le hôte peut utiliser Formik, React Hook Form ou rien ; l'état reste dans le reducer
  d'ADR-010 et la validation dans `src/core`.

## ADR-013: Le cache n'est jamais l'autorité sur la fraîcheur

- Date: 2026-09-29
- Statut: Actif
- Contexte: le port `QueryCacheAdapter` était prévu sans règle d'usage. Un cache client peut
  contredire ce que le service dit de la fraîcheur.
- Décision, trois règles :
  1. **La fraîcheur vient de la réponse du service** (`B14`), jamais du cache. Une valeur servie depuis
     le cache s'affiche **toujours** avec son état et sa date de calcul, jamais comme fraîche.
  2. **Le cache est en mémoire.** Rien n'est écrit sur disque : une valeur d'indicateur sur un poste
     partagé est une fuite de données, et le cache n'a aucun moyen de savoir qui lit.
  3. **Le cache est vidé à la déconnexion**, sans exception et sans configuration. C'est la seule règle
     qui rend la précédente rétroactivement inoffensive.
- **Pourquoi 1 est la règle importante.** Un cache qui se croit frais quand le service ne l'est pas
  transforme `B14` en promesse non tenue, et le pire cas est un chiffre périmé présenté comme actuel —
  ce que le design system nomme « le mensonge du périmé », et que l'écran de consultation refuse par
  construction.
- Alternatives considérées: (a) cache persistant avec invalidation — un cache invalidé est encore lu
  par une session qui a échoué à s'invalider ; (b) laisser l'hôte gérer la fraîcheur — l'hôte ne peut
  pas distinguer « périmé » de « en cours », donc il ne peut pas l'afficher (`B14`) ; (c) TanStack Query
  comme dépendance du socle — contre `C1` et `C3`.
- Conséquences: `QueryCacheAdapter` est un port, implémenté dans le pilote (TanStack Query) et **jamais
  importé** par `src/core` ni `src/react`. Le journal d'exécution suit la règle 2 et 3 par construction :
  il n'est pas mis en cache du tout, et il est en écriture seule.

## ADR-014: `ViewConfig` est une clé voisine de `disposition`, pas un objet qui l'englobe

- Date: 2026-09-29
- Statut: Actif
- Amende ADR-001 (structure de dossiers) et l'architecture § 4.1
- Contexte: la slice `config` a été réduite en Phase 5, et `disposition` (`layout`, `columns`) en a
  été sortie vers une slice dédiée. Les deux validateurs Fast Track ont signalé la **conséquence** que
  cette réduction n'avait pas vue : `config` déclare une racine **`.strict()`** — donc un ensemble de
  champs **fermé** — et son plan affirmait qu'un `layout` doit être **rejeté**, alors qu'une autre
  slice devait porter ce champ **dans le même `ViewConfig`**. **Aucun slice ne possédait
  `ViewConfig`.** Même trou sur `version` : champ requis, aucun test, aucun propriétaire, alors que
  `B5`/`B6`/`B24` sont hors périmètre avec propriétaire `publication`.
- Décision : **deux clés voisines, deux propriétaires, un seul compositeur.**
  ```
  ViewDocument = { config: ViewConfig; disposition: Disposition }
  ```
  1. `config` possède `ViewConfig` : `version`, `id`, `name`, `description`, `indicators` (avec leur
     **rang déclaré**), `params`, `audience`. Sa racine reste **`.strict()` et fermée**.
  2. `disposition` possède `Disposition` : `layout`, `columns`. Son schéma est **strict et fermé** de
     la même manière.
  3. **`draft` possède la composition.** Il assemble `{ config, disposition }`, valide chaque partie
     avec le schéma de son propriétaire, et **seul** il connaît les deux. Ni `config` ni
     `disposition` n'importe l'autre.
- **Pourquoi la séparation est nette.** `B26` (ordre stable) est une règle de **contenu** : elle
  porte sur l'ordre _déclaré_ par l'auteur et sur la déduplication. Le `layout` est une question de
  **rendu**. Conséquence directe : une évolution du rendu ne doit jamais toucher au contenu, et une
  migration de layout ne doit pas invalider une version de contenu. La frontière suit les règles, pas
  la convenance.
- **Pourquoi la racine reste fermée, et non extensible.** `.catchall` / `.passthrough` rendrait
  négociable la garantie d'`ADR-003` — « aucun champ non déclaré n'entre dans une configuration » —
  qui est la propriété sur laquelle repose `B19`. Une garantie qu'on peut suspendre par un champ
  du schéma n'est plus une garantie.
- **Le composite n'est pas une troisième représentation.** `ViewDocument` n'est pas persisté par un
  propriétaire de données : c'est la forme que `publication` écrit et que `draft` transporte.
- **Correction d'une décision de session.** La réduction de périmètre avait créé une slice
  `params`. **C'était une erreur** : `params[].kind` est une **déclaration** — « ce paramètre est une
  période », « celui-ci est un filtre » — donc elle appartient à `config`. Ce qui manquait n'était pas
  un schéma mais une **sémantique d'exécution**, et elle appartient à `query`, qui traduit une
  déclaration de filtre en prédicat. Créer une slice `params` pour loger une déclaration aurait
  séparé la chose de son sens.
- Alternatives considérées: (a) racine extensible contrôlée — elle affaiblit ADR-003 ;
  (b) `disposition` reste dans `config` — alors `columns`, non borné par aucune règle du PRD, entre
  dans le contrat immuable, ce qui est la situation qu'on vient de résoudre ; (c) `query` compose —
  il ne connaît pas la disposition, donc il ne peut pas la transporter.
- Conséquences: **un nouveau module `disposition` entre dans l'architecture** (il n'y était pas), et
  la vague 0 compte désormais 5 fondations au lieu de 4. Les écrans `wizard-etape-3-disposition`
  consomment `disposition` et non `config` — ce qui supprime la contradiction signalée : l'étape 3
  ne dépend plus d'une slice dont on lui a retiré ses données.
