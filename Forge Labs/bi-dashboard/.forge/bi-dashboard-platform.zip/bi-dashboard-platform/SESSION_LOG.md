# SESSION_LOG.md — journal de session

Fichier **append-only**. Une entrée par session de travail, à lire **en entier au début de chaque
session** et à ajouter **avant de terminer** une session ou un commit.

Chaque entrée porte 8 champs, dans cet ordre : `STARTED FROM` · `DECIDED` · `REJECTED` ·
`BLOCKED` · `FILES TOUCHED` · `STATUS` · `NEXT SESSION SHOULD` · `NEXT SESSION SHOULD NOT`.

**Ce que ce fichier n'est pas.** Il ne porte pas le statut d'un livrable : cette autorité est
`.forge/state.json`, seul. Il ne porte pas une décision d'architecture : c'est `DECISIONS.md`. Il ne
porte pas une correction de fond : c'est `LEARNINGS.md`. Il porte **ce qui s'est passé et dans quel
ordre**, y compris les hésitations et les erreurs — la seule information qu'aucun autre fichier ne
peut contenus déduire.

**Ce que `.forge/audit/run-log.jsonl` n'est pas.** C'est le journal machine des commandes Forge
(`init`, `hash`, `status_change`, `gate_approved`). Il sait qu'un `hash` a tourné ; il ne sait pas
pourquoi la décision qui l'a précédé a été remise en cause. Les deux sont complémentaires, et
aucun des deux ne remplace l'autre.

## Propriété des faits

| Fichier                       | Tient                                                               |
| ----------------------------- | ------------------------------------------------------------------- |
| `.forge/state.json`           | Statut des livrables, hashes, ID — autorité, jamais édité à la main |
| `.forge/audit/run-log.jsonl`  | Journal machine de Forge                                            |
| `.forge/audit/issues.md`      | Incidents du processus de planification                             |
| `DECISIONS.md`                | Décisions d'architecture fermées                                    |
| `LEARNINGS.md`                | Corrections apprises, avec leur domaine de promotion                |
| `SESSION_LOG.md` (ce fichier) | Le récit de la session                                              |

---

## 2026-09-29 — Session 13 : test des validateurs corrigés, et corrections 3+4 appliquées

### STARTED FROM

Fin de session 12 : Fast Track arrêté sur un `BLOCK` (`slice-config` v2), budget de tentatives
épuisé (2/2), slice réduite de périmètre en v3. Trois questions ouvertes : le périmètre du
validateur, la propriété de `ViewConfig`, et la suite.

### DECIDED

- **Tester les validateurs corrigés avant de les appliquer au skill.** Écrits dans
  `%TEMP%\forge-agents-fix\*.v2.md` — **hors dépôt**, rien n'est commité tant que la correction
  n'est pas validée. Testé sur `slice-config` v3 avec le **PRD volontairement hors périmètre**,
  pour mesurer l'angle mort du protocole actuel.
- **Corrections 3 et 4 appliquées au skill** (`.agents/skills/forge/agents/`), après validation
  utilisateur :
  - **3** — `unreadable_without` non vide ⇒ `BLOCK`. Un validateur qui n'a pas pu lire ce qu'il
    devait lire ne peut rien certifier. La v1 rendait un `REVISE` de qualité sur des références
    jamais vérifiées : **aveugle au seul mode de défaillance récurrent** (8 citations fausses en
    session 5, 4 de plus en session 6).
  - **4** — `severity: info` pour un constat de résolution, + `prior_critical_resolved`. La v1
    déclenchait un `BLOCK` sur un bug **déjà corrigé** : un `critical` dont le texte disait
    « aucune correction requise ».
  - **Règle de sortie** : à l'initialisation, `state.json.run.mode` = `fast_track`, avec
    `fast_track.enabled`. Un `BLOCK` repasse en `guided` et journalise `fast_track_block` +
    `fast_track_escape`. **Aucun mécanisme outillé pour cela** : 24 commandes lues, aucune n'expose
    `fast_track` — édition manuelle de `state.json`, journalisée dans `run-log.jsonl`.
- **Rapport écrit dans `.forge/audit/agents-v2-test-report.md`**, avec preuves et contre-preuves.

### REJECTED

- **Appliquer les corrections 1 et 2.** Elles n'ont pas été éprouvées : pour les tester il
  faudrait fournir `derived_from` résolu, ce qui supprimerait précisément l'angle mort que le test
  devait mesurer. **Énoncer une règle qu'un agent ne peut pas appliquer mécaniquement reproduirait
  le défaut qu'on cherche à corriger.**
- **Modifier `Inputs` dans les deux agents** : c'est la partie non testée, elle reste en l'état.
- **Déclarer `read_only: false` dans `state.json`** (option A2 d'ADR-006) : statut utilisé pour
  activer Fast Track — « on ne modifie pas le skill dans ce produit » n'a pas de sens ici, le
  journal de session se contredit et l'exception doit être **écrite**, pas invoquée.
- **Réutiliser `state.js` pour activer Fast Track** : la commande n'existe pas (INC-008, même
  famille). Ajouté comme action corrective d'INC-010.

### BLOCKED

- **`ViewConfig` n'a pas de propriétaire.** `config` déclare une racine `.strict()` — ensemble
  fermé — et § 11.1 affirme que `layout`/`columns` doivent être **rejetés**, alors que § 12 les
  confie à `slice disposition`, qui devra les porter **dans le même `ViewConfig`**. Personne ne le
  possède. Même trou sur `version` : champ requis, aucun test, aucun propriétaire, alors que
  `B5`/`B6`/`B24` sont déclarés hors périmètre avec propriétaire `publication`. **Décision
  d'architecture, pas de plan** — ni le PRD ni les validateurs ne peuvent la trancher.
- **Deux valeurs non spécifiées** : `eq: null` accepté par `scalarSchema` sans test ; `between`
  accepte un couple `[nombre, datetime]` sans règle de comparaison.
- **Un `critical` neuf trouvé par `red-team` v2, interne à l'artefact** : les messages
  interpolent un `id` fourni par l'utilisateur, et `ID_PATTERN` accepte `sql`, `table`, `column`,
  `stack`, `undefined`. `{ params: [{ id: "sql", appliesTo: ["inconnu"] }] }` est une config
  **valide** et produit « le paramètre `sql` vise un indicateur inconnu » — **le code du plan viole
  la seconde moitié de `B13` qu'il vient d'écrire**, et l'interdit dans un test situé 40 lignes plus
  loin. Le test d'invariant adversarial proposé l'aurait attrapé.
- **`consistency-check` : `slice_plan_exists`, `screens_have_slices`.** `slice-config` est `planned`,
  pas `approved`. Les 10 autres slices ne sont pas déclarées.

### FILES TOUCHED

**Dans le dépôt** : `.forge/plans/slice-config.md` (v3, périmètre réduit), `.forge/audit/issues.md`
(INC-009, INC-010), `.forge/audit/agents-v2-test-report.md` (créé), `SESSION_LOG.md`.

**Hors dépôt** (`.agents/skills/` est **gitignoré** — vérifié) :
`.agents/skills/forge/agents/quality-analyst.md` et `red-team.md` (corrections 3 et 4).

### STATUS

```
slice-config.md          planned   v3, périmètre réduit, 2/2 tentatives
INC-009, INC-010         ouverts
agents-v2-test-report    2 corrections eprouvees, 2 non eprouvees
skill agents             corrections 3+4 appliquees (local, non versionne)
phases 0-4   closes · phase 5 (implementation_plan)   in progress
scan 28 fichiers 0 probleme · forge-guard pass
```

### NEXT SESSION SHOULD

- **Trancher la propriété de `ViewConfig`** : racine fermée avec `disposition` en clé voisine
  (`{ config, disposition }`), ou racine extensible contrôlée. C'est le seul défaut que ni le PRD ni
  les validateurs ne peuvent résoudre, et il bloquera `config` et `disposition`.
- **Fixer les deux valeurs non spécifiées** : `eq: null` et `between` mixte.
- **Rejouer les validateurs v2 sur une slice suivante** avant de conclure qu'ils sont fiables — le
  rapport est formel là-dessus : **un artefact n'est pas un échantillon suffisant**.
- Si les 3+4 tiennent sur deux artefacts : appliquer 1 et 2 **avec** la propagation de
  `derived_from` dans `state.json` (action 2 d'INC-010).

### NEXT SESSION SHOULD NOT

- **Ne pas appliquer les corrections 1 et 2 seules.** Sans la propagation mécanique, une règle
  qu'un agent ne peut pas appliquer à la main reproduit le défaut d'INC-010.
- **Ne pas généraliser les 3+4 sur un artefact.** Elles sont éprouvées sur **un**.
- **Ne pas garder « une seule forme de sortie »** comme gate alors que l'étape 1 est un retour
  anticipé : la v3 affirme « sortie unique quelle que soit l'entrée », ce qui est faux au sens
  large. Formuler « pas de retour anticipé **après un parse réussi** ».
- **Ne pas ré-ouvrir** : ADR-001 à ADR-013, la Phase 3 (design system, 6 écrans, routes anglaises non
  numérotées, `US-13` sans écran), la Phase 4 (architecture, gate amendé), le découpage en 5
  tranches, et la réduction de périmètre de `config` (v3) — dont les **raisons** sont dans son
  en-tête et dans son § 12.
- **Ne pas préciser `ViewConfig` par défaut** : c'est le trou que j'ai laissé ouvert, et il a un
  propriétaire à désigner, pas un défaut à corriger.

---

## 2026-09-29 — Session 12 : Phase 5, découpage en slices

### STARTED FROM

Fin de session 11 : Phase 4 clôturée, six livrables approuvés. La Phase 5 doit produire les slices —
ce que `screens_have_slices` attend depuis la Phase 3 (INC-007).

### DECIDED

- **Le découpage en 15 slices, sur 4 vagues + V1**, dérivé des modules de l'architecture et du
  **périmètre MVP de la roadmap** (US-1, 2, 3, 4, 5, 9, 13, 14).

  | Vague | Slice            | US                     | Règles principales                              |
  | ----- | ---------------- | ---------------------- | ----------------------------------------------- |
  | 0     | `config`         | US-2, US-5             | `B1`, `B2`, `B19`, `B26`, `B27`                 |
  | 0     | `permissions`    | US-14                  | `C2`, `B31`–`B35`                               |
  | 0     | `ports`          | transverse             | ADR-007, ADR-009                                |
  | 0     | `journal`        | US-11                  | `B28`, `B29`, `B35`                             |
  | 1     | `query`          | US-3                   | `B2`, `B3`                                      |
  | 1     | `draft`          | US-2, US-3, US-4, US-5 | `B5`, `B6`, `B10b`, `B12`, `B16`, `B24`, `B26`  |
  | 2     | `catalog`        | US-3, US-14            | `B3`, `B4`, `B12`, `B23`, `B25`                 |
  | 2     | `consumption`    | US-9                   | `B14`, `B15`, `B18`, `B21`, `B22`, `B30`        |
  | 2     | `views-index`    | US-1                   | `B1`, `B10`, `B10b`, `B14`, `B19`, `B23`, `B36` |
  | 3     | `publication`    | US-5                   | `B5`, `B6`, `B13`, `B27`                        |
  | V1    | `versioning`     | US-6                   | `B24`                                           |
  | V1    | `sharing`        | US-7                   | `B7`, `B8`                                      |
  | V1    | `duplication`    | US-8                   | `B9`                                            |
  | V1    | `administration` | US-11                  | `B10`, `B28` → `B35`                            |
  | V1    | `integration`    | US-10                  | `B24`                                           |

- **`journal` est dans le MVP, malgré que `US-11` soit V1.** Raison : le format du journal est un
  format **qu'on ne change pas** (B29 : rétention et fenêtre chaude sont configurables par hôte, donc
  le format doit porter ces paramètres dès le premier jour). C'est le même argument que pour
  `config`. De plus, `security.md` impose de journaliser création, publication, exécution — donc
  **le MVP écrit déjà dans ce journal** ; le construit-il plus tard, il écrirait dans un format
  qu'il n'a pas choisi.
- **Distinction `US-6` (V1) / `B5`+`B6` (MVP).** Le **mécanisme** de version est dans le MVP : publier
  crée une version distincte et immuable, c'est nécessaire à `US-5`. Ce qui est différé en V1, c'est
  l'**interface** d'historique — consultation, sélection, restauration (`B24`). Confondre les deux
  ferait croire que le MVP n'a pas de version, ou que la V1 doit reprendre le modèle.
- **Le MVP porte `B14`/`B21`/`B22` sans porter `US-12`.** Les critères de `US-9` incluent « je vois la
  date à laquelle les données ont été calculées » : la donnée de fraîcheur est donc obligatoire dès
  le MVP. `US-12` (comprendre l'origine et la fraîcheur) est V1 et ajoute l'**explication**. C'est un
  découpage que la roadmap ne dit pas et qui, mal vu, se paie en reprise.

### REJECTED

- **Nommer les slices pour contenir les slugs d'écrans** afin de faire passer
  `consistency-check: screens_have_slices`. Le contrôle cherche aussi dans le **texte des plans**
  (`allPlans.includes(s)`), donc un plan qui référence réellement son écran le satisfait. Nommer
  artificiellement serait mentir sur la frontière, et le contrôle aurait raison de le signaler.
- **Écrire les 10 plans de slice dans cette session.** La vague 0 contient les contrats **qu'on ne
  change pas** — schéma de configuration, ports, actions, format du journal. Les écrire après les
  autres serait écrire contre des contrats provisoires.

### BLOCKED

- **`state.js` n'a aucune commande de suppression.** `register` est à sens unique : une clé mal
  enregistrée ne peut être retirée que par édition manuelle de `state.json`. **J'ai dû le faire** pour
  retirer une clé de test : c'est la seule voie, et c'est aussi une violation de la règle « ne jamais
  éditer `state.json` à la main ». Consigné en INC-008 et en `LEARNINGS.md`.
- **Plans de slice complets : vague 0 d'abord.** Les 4 fondations fixent les contrats dont dépend tout
  le reste. Les vagues 1 à 3 suivent, puis les plans E2E (Phase 6).

### FILES TOUCHED

Modifiés : `.forge/state.json` (15 slices déclarées), `.forge/audit/issues.md` (INC-008),
`.forge/audit/LEARNINGS` → `LEARNINGS.md` (1 correction), `SESSION_LOG.md` (cette entrée).

### STATUS

```
phases 0-4   closes
phase 5 (implementation_plan)   in progress
15 slices declarees, 4 plans de vague 0 ecrits
unicode-scan 26 fichiers 0 probleme
forge-guard pass · placeholders pass
```

### NEXT SESSION SHOULD

- **Vagues 1 à 3** : `query` et `draft` (vague 1), puis `catalog`, `consumption`, `views-index`
  (vague 2), puis `publication` (vague 3).
- Chaque plan doit **référencer les slugs d'écrans qu'il couvre** — c'est ce qui satisfait
  `screens_have_slices` de façon vérifiable, par opposition à un renommage de slice.
- Vérifier le graphe avec `dependency-check.js` une fois les slices déclarées.

### NEXT SESSION SHOULD NOT

- **Ne pas renommer une slice pour contenir un slug d'écran.**
- **Ne pas éditer `state.json` à la main** — sauf pour retirer une clé erronée, et en le consignant.
- **Ne pas écrire les plans des vagues 1 à 3 avant que les contrats de la vague 0 soient écrits.**

---

## 2026-09-29 — Session 11 : Phase 4 validée et clôturée

### STARTED FROM

Fin de session 10 : architecture livrée, `conventions.md` repassé en `draft` faute d'approbation.
Deux validations attendues de l'utilisateur.

### DECIDED

- **Phase 4 approuvée et clôturée.** `architecture.md` et `conventions.md` passent de `draft` à
  `approved` dans le même geste, par `state.js set-status` — donc dans l'autorité **et** dans le front
  matter. C'était la condition que la session 10 avait posée : ne pas laisser un document approuvé
  modifié hors bande, et ne pas ré-approuver l'un sans l'autre puisqu'ils disent la même chose.
- `state.json` fait foi : `current = 5`.

### REJECTED

- Rien — cette session est une clôture, pas une décision.

### BLOCKED

- **`consistency-check` reste en `fail`** sur `screens_have_slices`. La Phase 5 est précisément la
  phase où cette vérification devient applicable : elle cessera d'être un contrôle appliqué trop tôt
  (INC-007) pour devenir un vrai contrôle.
- **`coverage-check prd` reste en `fail`** (INC-006).

### FILES TOUCHED

Modifiés : `.forge/state.json`, `.forge/architecture.md` et `.forge/conventions.md` (front matter
miroir), `.forge/audit/run-log.jsonl`, `SESSION_LOG.md` (cette entrée).

### STATUS

```
prd · roadmap · benchmarks · design-system · architecture · conventions
                                          tous approved
phases 0, 1, 2, 3, 4   closes
phase 5 (implementation_plan)   not_started
0 divergence · 0 livraison perimee · 0 gate en attente
unicode-scan 26 fichiers 0 probleme · auto-test exit 0
sync 0 divergence · forge-guard pass
```

### NEXT SESSION SHOULD

- **Phase 5 — plans d'implémentation.** C'est la phase qui rend trois choses vérifiables :
  1. **Les slices**, avec leurs dépendances réelles. C'est l'objet de la phase, et c'est ce que
     `screens_have_slices` attend depuis la Phase 3.
  2. **La commande de vérification de la frontière d'import** : un script qui échoue si `src/core`
     importe React, le DOM ou le réseau. La règle est écrite dans
     `.opencode/rules/architecture.md` ; le contrôle viendra avec les fichiers à contrôler. C'est un
     **livrable**, pas une décision.
  3. **Le squelette du projet** : `package.json`, `.node-version` (ADR-008), `src/**`, `pilot/`.
     Ensuite les commandes deviennent exécutables, et les 3 sections re-datées en Phase 5
     (`bun run test`, `test:contract`, `test:e2e`) se ferment.
- Utiliser `dependency-check.js` sur les slices une fois déclarées, pour vérifier que le graphe est
  sans cycle — c'est un item de gate de l'architecture qui n'était pas vérifiable en Phase 4.

### NEXT SESSION SHOULD NOT

- **Ne pas rouvrir** : ADR-001 à ADR-013, la Phase 3 (design system, 6 écrans, routes anglaises non
  numérotées, `US-13` sans écran), le découpage en 5 tranches, le gate amendé de `conventions.md`.
- **Ne pas modifier un livrable `approved` sans le remettre en `draft` d'abord.** Le protocole est
  établi : `set-status draft` → correction → `hash` → approbation. Il s'est appliqué deux fois
  (`prd.md` en session 5, `conventions.md` en session 10) et le garde-fou l'exige.
- **Ne pas faire passer `consistency-check` en déclarant des slices vides** : la Phase 5 doit produire
  de vraies slices, pas des emplacements.

---

## 2026-09-29 — Session 10 : Phase 4, architecture, ADR-009 à ADR-013

### STARTED FROM

Fin de session 9 : Phase 3 clôturée. Décision utilisateur : **garder l'ouverture** sur les sections
`À DÉCIDER` de `conventions.md`, plutôt que de tout verrouiller en Phase 4.

### DECIDED

- **Le gate de `conventions.md` est amendé.** Il exigeait « aucune section `À DÉCIDER EN PHASE 4` ne
  subsiste » — ce qui rendait la décision de garder l'ouverture contradictoire avec le document. La
  formulation retenue admet la **re-datation explicite** vers une phase ultérieure, à condition
  qu'elle soit motivée. Un report silencieux ne l'est pas.
- **Les 5 sections ouvertes n'ont pas la même nature**, et les traiter comme un bloc était faux :
  stack (state, cache, formulaires) = **tranché en Phase 4** ; tests = **nature tranchée, exécution
  re-datée** ; commandes = **re-datées en Phase 5**, seule raison : le squelette n'existe pas, donc
  une commande ne peut être ni écrite ni vérifiée.
- **ADR-009 — le port d'exécution rend l'issue, pas les lignes** (`scopeState`, `totalRows`,
  `calculatedAt`, `durationMs`), et **les rend toujours**, même quand `rows` est vide. Sans cela le
  noyau ne peut pas distinguer « aucune donnée sur la période » de « périmètre non résolu » : deux
  messages opposés, une seule représentation (`rows: []`).
- **Le noyau ne calcule jamais le périmètre de lignes** : il ne connaît ni l'identité ni le modèle
  de données. Il reçoit un contexte, l'hôte résout, le noyau rend `scopeState`.
- **ADR-010 — le reducer de brouillon est dans `src/core`.** Le brouillon porte des règles
  (`B26`, `B5`, `B6`, `B12`, `B27`), pas des états d'interface. Un reducer dans React ne serait
  testable qu'à travers un DOM — et une règle de sécurité testée à travers une couche d'interface
  est testée à moitié, ce que `security.md` interdit.
- **ADR-011 — la couverture se mesure en règles `B*` sans test, pas en pourcentage de lignes.** Un
  seuil de lignes se choisit pour ne pas échouer ; le nombre de règles non testées ne se gonfle pas.
  Et les trois contrôles sont vérifiés par un **contrat publié** que l'adaptateur d'hôte doit passer.
- **ADR-012 — le wizard est contrôlé, sans bibliothèque.** L'argument tient en une règle : `B1` rend
  l'obligation de la description **configurable à l'exécution**, et une bibliothèque à schéma
  statique se bat contre cela. La vraie complexité est dans le catalogue (`src/core`), pas dans le
  formulaire.
- **ADR-013 — le cache n'est jamais l'autorité sur la fraîcheur.** Fraîcheur du service, cache en
  mémoire, vidé à la déconnexion. Un cache qui se croit frais quand le service ne l'est pas fait
  passer un chiffre périmé pour actuel.
- **Le socle ne définit aucun endpoint** — c'est une bibliothèque. Ce qu'il impose est une liste de
  **garanties** sur ce qu'un endpoint doit rendre. Les codes HTTP appartiennent à l'hôte ; ce qui est
  imposé est que le client distingue erreur et refus.

### REJECTED

- **Verrouiller toute la stack en Phase 4** — verrouiller une convention avant d'avoir vu un plan
  d'implémentation, c'est verrouiller une hypothèse.
- **Définir les slices en Phase 4** — une slice est une unité de travail livrable ; la définir ici
  serait la deviner. C'est l'objet de la Phase 5, et le gate le dit.
- **Un registre de moteurs de requêtes** — refus maintenu en ADR-007 : il repose sur un moteur
  « similaire » chez l'hôte, or « similaire » n'est pas un contrat.
- **Persistance côté noyau** (`C1`) — le noyau ne persiste rien ; les entités documentées sont des
  **contrats**, pas un schéma de base.
- **Décomposer le modèle d'identité** — le noyau reçoit un `IdentityContext` opaque. Un noyau qui
  connaît le modèle d'identité d'un hôte est un noyau lié à cet hôte.

### BLOCKED

- **`consistency-check` toujours `fail`** sur `screens_have_slices` : les slices arrivent en Phase 5.
  Le contrôle sera alors applicable, et pas avant.
- **`coverage-check prd` toujours `fail`** (INC-006) : sections françaises non reconnues.
- **Non traitable en Phase 4, et écrit comme tel dans le gate** : chaque US → une slice ; vérification
  du graphe par `dependency-check.js` ; commandes fonctionnelles ; **commande de vérification de la
  frontière d'import**. Cette dernière est un _livrable_, pas une décision : la règle est écrite
  dans `.opencode/rules/architecture.md`, le contrôle viendra avec les fichiers à contrôler.

### FILES TOUCHED

Créés : `.forge/architecture.md` (Phase 4, `draft`).

Modifiés : `DECISIONS.md` (ADR-009 → ADR-013), `.forge/conventions.md` (3 sections tranchées, tests
partiellement tranchés, commandes re-datées, gate amendé, nouvelle section « Tests de contrat de
sécurité »), `SESSION_LOG.md` (cette entrée).

### STATUS

```
.forge/architecture.md    draft   enregistre
  13 ADR   001 -> 013
  7 modules, 4 vagues, aucun cycle
conventions.md            approved -> DRAFT (modifie apres approbation)
prd · roadmap · benchmarks   approved
phases 0, 1, 2, 3   closes
phase 4 (architecture) in progress
unicode-scan 26 fichiers 0 probleme
forge-guard pass · placeholders pass
consistency-check FAIL (screens_have_slices, INC-007)
coverage-check FAIL (INC-006)
```

> **Attention** : `conventions.md` était `approved` et a été modifié pour cette phase. Il repasse
> **`draft`** et devra être ré-approuvé avec l'architecture, ou explicitement maintenu `approved` si
> les changements sont acceptés tels quels. Rappel du protocole : `set-status draft` → correction →
> `hash` → approbation.

### NEXT SESSION SHOULD

- **Faire valider l'architecture**, puis ré-approuver `conventions.md` dans le même geste.
- **Phase 5** : les slices, leurs dépendances réelles, et la commande de vérification de la frontière
  d'import. C'est la phase où `screens_have_slices` devient un vrai contrôle au lieu d'un contrôle
  appliqué trop tôt (INC-007).
- Créer le squelette : `package.json`, `.node-version` (ADR-008), `src/**`, `pilot/`. Les commandes
  deviennent alors exécutables et `conventions.md` se verrouille.

### NEXT SESSION SHOULD NOT

- **Ne pas définir de slice en Phase 4** pour faire passer `consistency-check`. Le contrôle a raison
  d'exiger la couverture ; il a tort de l'exiger avant que les slices existent.
- **Ne pas introduire de persistance dans le noyau** (`C1`).
- **Ne pas faire du cache l'autorité de la fraîcheur** (ADR-013 règle 1).
- **Ne pas mettre de reducer dans un composant React** : les règles du brouillon deviennent
  testables uniquement à travers un DOM.
- **Ne pas ré-ouvrir** : ADR-001 à ADR-008, la Phase 3 (design system, 6 écrans, routes en anglais
  non numérotées), le découpage en 5 tranches, `US-13` sans écran.

---

## 2026-09-29 — Session 9 : Phase 3 validée et clôturée

### STARTED FROM

Fin de session 8 : routes en anglais, `US-13` tranché. Le gate de la Phase 3 attendait la validation
explicite de l'utilisateur.

### DECIDED

- **Phase 3 approuvée et clôturée.** `design-system.md` et les 6 écrans passent de `draft` à
  `approved`, par `state.js set-status` — donc dans l'autorité **et** dans le front matter, jamais à la
  main.
- Les 6 écrans sont enregistrés comme `kind: screen`, pas comme livrable : ils s'approuvent avec
  `set-status <root> screen <clé> approved`. Vérifié sur les six, et relu dans le front matter.

### REJECTED

- Rien — cette session est une clôture, pas une décision.

### BLOCKED

- **`consistency-check` reste en `fail`** sur `screens_have_slices` seul. C'est **attendu et correct** :
  la règle dit « un écran sans slice ne sera jamais implémenté », et les slices arrivent en Phase 5.
  C'est le moment où cette vérification devient applicable — elle ne le sera jamais avant.
- **`coverage-check prd` reste en `fail`** (INC-006) : il cherche `## Edge cases` et `## Hors scope`
  dans un PRD français où les sections s'appellent `## 6. Cas limites` et `## 9. Hors périmètre`.

### FILES TOUCHED

Modifiés : `.forge/state.json` (statuts), les 6 écrans (front matter miroir), `.forge/audit/run-log.jsonl`,
`SESSION_LOG.md` (cette entrée).

### STATUS

```
design-system.md          approved
consultation-vue          approved   /views/{id}
liste-des-vues            approved   /views
administration-vues       approved   /admin
wizard-etape-1            approved   /views/new
wizard-etape-2            approved   /views/new/metrics
wizard-etape-3            approved   /views/new/layout

prd · roadmap · conventions · benchmarks   approved
phases 0, 1, 2, 3   closes
phase 4 (architecture)    not_started
nav : 2 entrees, chacune liee a un ecran
unicode-scan 25 fichiers 0 probleme · auto-test exit 0
sync 0 divergence · forge-guard pass · placeholders pass
```

### NEXT SESSION SHOULD

- **Phase 4 — architecture.** C'est la phase la plus structurante du projet, et elle a quatre
  décisions à prendre :
  1. **Le moteur de requêtes** (ADR-007 : adaptateur) — traded, mais la forme de l'interface du port
     ne l'est pas encore : quelles méthodes, quelle granularité, comment le périmètre de lignes
     (`B7`) traverse le port.
  2. **La pile de tests** — les 5 sections `À DÉCIDER` de `conventions.md` : framework, stratégie
     d'adaptateurs en mémoire, coût de la couverture des **trois contrôles** (`NFR §7.2`) et de `B25`
     contre le contrat backend réel.
  3. **Les frontières d'import** entre `src/core`, `src/react`, `src/ui`, `src/next` et `pilot/` —
     à rendre **vérifiables par une commande**, pas par une intention.
  4. **Le format de configuration** versionné (ADR-003) : ce qu'il contient, ce qu'il ne contient
     jamais, et comment il migre.
- Décider si les 5 sections `À DÉCIDER` de `conventions.md` sont verrouillées en Phase 4, ou
  restent ouvertes jusqu'à la Phase 5 (plans d'implémentation). Le PRD les nomme « verrouillées en
  Phase 4 », mais la Phase 5 est plus adaptée à certaines d'entre elles.

### NEXT SESSION SHOULD NOT

- **Ne pas rouvrir** : le découpage en 5 tranches, la densité `dense`, la navigation à 2 entrées,
  les routes descriptives non numérotées, les routes en anglais, `US-13` sans écran, ADR-005 à
  ADR-008, et les contre-décisions visuelles (pas de cartes, pas d'ombre comme séparateur, rayon
  unique, aucune animation qui porte une information).
- **Ne pas faire passer `consistency-check` en Phase 4** en déclarant des slices : les slices sont
  l'objet de la Phase 5. La vérification redevient applicable **après** qu'elles existent.
- **Ne pas déclarer les slices vides** pour calmer le contrôle. C'est lui donner tort.

---

## 2026-09-29 — Session 8 : routes en anglais, et `US-13` sans écran

### STARTED FROM

Fin de session 7 : 6 écrans, gate prêt. Deux points en attente : le sort de `US-13` (dans le MVP mais
sans écran) et le nommage des routes, resté en français par défaut.

### DECIDED

- **`US-13` (refus compréhensible) reste dans le MVP sans écran dédié.** Un refus est un **état de
  n'importe quel écran**, porté par le composant `RefusalNotice` ; lui donner un écran le
  transformerait en destination, ce qu'il n'est pas. Un écran « page de refus » serait une destination
  qu'on atteint après avoir échoué ailleurs — donc un cul-de-sac.
- **Les routes sont en anglais, l'interface reste en français.** Le code, les URL et les identifiants
  sont lus par des développeurs et des machines ; l'interface est lue par des utilisateurs. Une URL
  française est un défaut, pas une localisation.
- **Segments descriptifs, jamais numérotés** : `/views/new/metrics` et non `/views/new/2`. Le
  tunnel **est** numéroté dans l'interface — l'utilisateur doit savoir où il en est — mais l'URL n'a
  pas à porter le numéro : insérer un écran de confirmation demain ne déplacerait rien. Un numéro dans
  une URL est un engagement à ne jamais insérer d'étape.
- **Les fichiers de spécification restent en français.** `liste-des-vues.md` n'est lu que par vous et
  par l'agent ; une URL `/vues` est dans l'historique de navigation de tout le monde et dans les
  journaux du serveur. La frontière est **qui lit**, pas la langue.

| Ancien                       | Nouveau              |
| ---------------------------- | -------------------- |
| `/vues`                      | `/views`             |
| `/vues/nouvelle`             | `/views/new`         |
| `/vues/nouvelle/indicateurs` | `/views/new/metrics` |
| `/vues/nouvelle/disposition` | `/views/new/layout`  |
| `/vues/{id}`                 | `/views/{id}`        |
| `/administration`            | `/admin`             |

### REJECTED

- **Ajouter un champ `route` aux entrées de navigation.** `set-nav` ne connaît pas ce champ et
  **rejette silencieusement** ce qu'il ne reconnaît pas : mon `route` n'a jamais été enregistré, et la
  commande a rendu un succès. Les routes sont donc documentées dans `design-system.md` § 3.4, qui est
  lu, plutôt que dans un fichier que l'outillage tronque en silence. **Un succès qui ignore une
  entrée n'est pas un succès** — c'est à consigner comme tel.

### BLOCKED

- **`consistency-check` reste en `fail`** sur `screens_have_slices` (INC-007) ; `coverage-check prd`
  reste en `fail` (INC-006). Inchangé.
- **`US-6`, `US-7`, `US-8`, `US-10` sans écran** — V1 selon la roadmap, pas des oublis.
- **L'assistant d'installation n'a pas de parcours d'écran.** `US-10` est V1, mais le tunnel à trois
  étapes est le seul flux spécifié ; l'assistant d'intégration est une autre chose que le wizard de
  création, et il n'est pas dessiné.

### FILES TOUCHED

Modifiés : les 6 écrans (routes), `.forge/design/design-system.md` (nouvelle section 3.4 Routes,
tableau des routes, renumérotation 3.5), `SESSION_LOG.md` (cette entrée).

### STATUS

```
design-system.md + 6 ecrans   draft
routes : 6 ecrans, toutes en anglais kebab-case, aucune numerotee
prd · roadmap · conventions · benchmarks   approved
phases 0, 1, 2   closes
phase 3 (design) in progress — pret pour le gate
unicode-scan 25 fichiers 0 probleme
```

### NEXT SESSION SHOULD

- **Présenter la Phase 3 au gate** pour validation explicite. Ne pas démarrer la Phase 4 sans.
- Phase 4 : slice d'architecture — moteur de requêtes (ADR-007), pile de tests (les 5 sections
  `À DÉCIDER` de `conventions.md`), ports, frontières d'import.

### NEXT SESSION SHOULD NOT

- **Ne pas numéroter une URL.** `/views/new/2` interdit d'insérer une étape demain.
- **Ne pas mettre de route en français** dans un écran, une URL ou un log.
- **Ne pas ajouter de champ inconnu à `set-nav`** en croyant qu'il sera conservé : il est ignoré
  silencieusement, et la commande renvoie un succès.
- **Ne pas créer d'écran dédié pour un refus** : c'est un état transversal, pas une destination.

---

## 2026-09-29 — Session 7 : liste des vues, administration, et `set-nav` exécuté

### STARTED FROM

Fin de session 6 : 4 écrans spécifiés. Restent la liste des vues (`US-1`) et l'administration
(`US-11`), puis `set-nav` qui ne pouvait pas être exécuté avant que les destinations existent.

### DECIDED

- **Liste des vues : table dense, jamais de mosaïque de cartes.** On ne compare pas une propriétaire
  et une date de mise à jour dans une grille de tuiles. La propriétaire et la date sont **dans la
  ligne** — ce qui est caché derrière un survol ne se compare pas.
- **La table ne défile pas horizontalement sur mobile** : une table BI qui exige un défilement
  horizontal sur téléphone n'est pas dense, c'est un document mal présenté. D'où la liste empilée,
  qui reste dense : la densité est le nombre d'informations par regard, pas la présence de colonnes.
- **`E10` — deux vues de même nom sont désambiguïsées, jamais renumérotées.** Renuméroter
  mentirait sur le contenu. La désambiguïsation vient de la propriétaire et de la date — ce qui n'est
  pas un détail d'affichage mais la raison de les mettre dans la ligne.
- **Menu contextuel proscrit** (`liste-des-vues`) : c'est le modèle « dense » par défaut et il est
  inaccessible au clavier (`B17`). Remplacé par des actions visibles qui apparaissent **au focus
  comme au survol**.
- **Administration : deux fonctions, deux droits, un seul écran.** C'est la conséquence directe de
  `B31`–`B35`. Quand les droits sont réunis (`B32`), les deux panneaux sont là. Sinon un est
  **absent, et son absence est expliquée** — un panneau qui s'évanouit sans mot ressemble à une perte
  de fonction.
- **`B28` est aussi une décision de mise en page.** Le journal ne montre aucun résultat : pas de
  colonne d'aperçu, pas de miniature, **pas d'infobulle au survol** — l'infobulle est précisément
  l'endroit où l'utilisateur irait chercher.
- **Rétention et périmètre affichés avant les données.** Ce sont des faits permanents, pas un
  contenu à charger : un écran de journal qui masque sa rétention pendant le chargement laisse
  croire que tout est conservé.
- **Aucun cache du journal.** Un journal mis en cache est un journal périmé sur des événements de
  sécurité, et il n'étant pas modifiable, il n'est pas invalidable.
- **Clés de navigation = noms d'écran.** `set-nav` compare la clé nav au nom d'écran ; nommer
  `mes-vues` pour l'écran `liste-des-vues` était un renommage gratuit qui rompait le lien. Les clés
  portent maintenant les noms d'écran.
- **Le JSON `set-nav` du design system était faux** et a été remplacé par la version qui fonctionne.
  Le schéma réel impose `key / label / rank / frequency / task_criticality / rationale` ; le
  document donnait `label / rank / screen`, rejeté par `invalid_nav`. Un document qui montre une
  commande fausse fait perdre du temps à celui qui l'exécute.

### REJECTED

- **Un compteur de vues paginé.** Une liste de vues se parcourt, elle ne se pagine pas : « 24 vues »
  est une information, un paginateur ne l'est pas. Le **journal**, lui, se pagine — un journal n'a pas
  de fin, et il faut dire où l'on est (« 100 sur 1 284 »).
- **Toggle désactivé pour un membre de profil.** `B10b` lui donne une **action** — « Dupliquer » —
  pas une action morte. Un `Toggle` désactivé sans alternative est un mur.
- **Retirer une vue dont la version est retirée** (`E16`) de la liste : cela ferait croire à une
  suppression. Elle passe « retraitée » et reste listable.

### BLOCKED

- **`consistency-check` reste en `fail`** sur `screens_have_slices` seul — INC-007, non applicable
  avant la Phase 5. `nav_items_have_screens` est désormais **`pass`**.
- **`coverage-check prd` reste en `fail`** — INC-006, sections françaises non reconnues.
- **4 US sans écran** : `US-6`, `US-7`, `US-8` (versionnage et partage) et `US-10` (assistant) sont
  **V1** selon la roadmap — pas des oublis. Mais **`US-13` (refus compréhensible) est dans le MVP**
  et n'a pas d'écran : ses critères sont aujourd'hui portés par `RefusalNotice`, un composant, pas un
  écran. À trancher en Phase 4.
- **L'assistant d'installation n'a pas de parcours d'écran** : `US-10` est en V1, mais le tunnel à
  trois étapes est le seul flux spécifié.

### FILES TOUCHED

Créés : `.forge/design/screens/liste-des-vues.md`, `administration-vues.md`.

Modifiés : `.forge/design/design-system.md` (JSON `set-nav` remplacé par la version valide, tableau
de navigation aligné sur ce qui est enregistré, une faute de ponctuation), `state.json` (nav
enregistrée), `SESSION_LOG.md` (cette entrée).

### STATUS

```
design-system.md + 6 ecrans   draft
  consultation-vue      liste-des-vues     administration-vues
  wizard-etape-1/2/3
nav enregistree via set-nav : 2 entrees, chacune liee a un ecran
prd · roadmap · conventions · benchmarks   approved
phases 0, 1, 2   closes
phase 3 (design) in progress — gate 19/19 du design system, 6 ecrans
unicode-scan 25 fichiers 0 probleme
forge-guard pass · placeholders pass · nav_items_have_screens pass
consistency-check FAIL (screens_have_slices uniquement, INC-007)
coverage-check FAIL (INC-006)
```

### NEXT SESSION SHOULD

- **Présenter la Phase 3 au gate.** Les 6 écrans couvrent 8 US sur 14 ; les 4 restantes sont V1
  selon la roadmap, sauf `US-13` à trancher.
- Trancher `US-13` : un écran de refus, ou `RefusalNotice` comme composant suffit-il pour le MVP ?
- Phase 4 : la slice d'architecture, qui devra traiter le moteur de requêtes (ADR-007), la pile de
  tests, et `.node-version` au squelette (Phase 7).

### NEXT SESSION SHOULD NOT

- **Ne pas réintroduire de menu contextuel** dans la liste des vues : inaccessible au clavier.
- **Ne pas mettre de cache** sur le journal d'exécution, pour quelque raison que ce soit.
- **Ne pas renommer les clés de navigation** indépendamment des noms d'écran : le lien est vérifié
  par un contrôle.
- **Ne pas montrer d'infobulle de résultat** dans le journal. `B28` s'applique aussi à l'écran.
- **Ne pas démarrer la Phase 4 sans approbation explicite de la Phase 3.**

---

## 2026-09-29 — Session 6 : écran de consultation, et 8 fausses citations réparées

> Cette session a commencé par l'écran le plus utile du produit et s'est terminée par la
> correction d'une faute de méthode qui le rendait faux.

### STARTED FROM

Fin de session 5 : trois écrans du tunnel spécifiés. Reste la consultation (`US-9`), la boucle
quotidienne. `consistency-check` et `coverage-check` en `fail` pour des raisons consignées
(INC-006, INC-007).

### DECIDED

- **Chargement en un bloc unique, jamais indicateur par indicateur.** `B13` impose un ensemble
  cohérent et `B22` interdit le mélange : charger l'un après l'autre produirait un mélange de
  périodes. La granularité est un choix d'affichage, jamais une stratégie de chargement.
- **La date de calcul est permanente, pas au survol.** Un tableau dense montre trop de valeurs pour
  qu'un survol porte une information — ce qui a été survolé n'a jamais été lu. `B14` ne peut être
  tenu à une densité réelle qu'ainsi.
- **`E6` — un total calculé sur un résultat tronqué et présenté sans mention serait un mensonge
  chiffré.** Le compte exact est obligatoire : « 1 000 lignes sur 12 480 ».
- **Un filtre croisé est un changement d'état de la vue, donc une entrée d'historique.** Le retour
  arrière du navigateur revient dans l'historique de la vue, pas vers une autre page.
- **`E16` — version retirée en cours de consultation** : bascule sur la plus récente, bandeau
  non bloquant, **pas** d'écran cassé. Passer en erreur serait faux : la vue existe toujours.
- **`ValueTable` n'est pas optionnel** (`B18`) : un graphique sans tableau de valeurs est une
  information inaccessible. Le tableau est un panneau de la grille, pas une annexe.
- **Une valeur non filtrable n'a aucun curseur.** Un curseur qui ne fait rien est pire que pas de
  curseur ; à l'inverse, une valeur filtrable a **toute sa carte** en zone tactile.
- **Densité / lisibilité sur écran étroit : tranché.** On ne sacrifie ni l'un ni l'autre — une
  colonne, défilement vertical accepté. Le défilement est un coût ; cacher un indicateur est une
  perte. Ce point était ouvert depuis la session 4.

### REJECTED

- **Squelette de chargement sur un écran de consultation.** Un squelette ferait croire que la valeur
  n'a jamais existé. Les valeurs restent affichées, marquées `stale`, avec leur date.
- **Vider l'écran en cas de panne globale.** On ne remplace pas une information fausse par une
  absence d'information pour une panne de service.
- **Faire de la lecture seule un état dégradé.** C'est un état normal : un lecteur n'a pas à être
  traité en visiteur.

### BLOCKED

- **`consistency-check` toujours `fail`** (INC-007) et **`coverage-check prd` toujours `fail`**
  (INC-006). Inchangé, assumé.
- **`set-nav` toujours non exécuté** : les écrans existent, mais « Mes vues » et « Gérer » doivent
  pointer vers quelles routes reste à trancher.
- **Écrans manquants** : liste des vues (`US-1`), administration (`US-11`).

### FILES TOUCHED

Créés : `.forge/design/screens/consultation-vue.md`.

**Réparés** : les trois écrans du tunnel, 8 citations `B*` fausses.

### STATUS

```
design-system.md + 4 ecrans   draft
  consultation-vue, wizard-etape-1/2/3
prd · roadmap · conventions · benchmarks   approved
phases 0, 1, 2   closes
phase 3 (design) in progress
unicode-scan 23 fichiers 0 probleme
forge-guard pass · placeholders pass
```

### NEXT SESSION SHOULD

- Liste des vues (`US-1`) et administration (`US-11`), puis `set-nav`.
- **Appliquer à tout écran futur le contrôle complet** : comparer chaque ID cité à sa **définition**
  dans le PRD, pas seulement à son existence. C'est le contrôle que j'ai omis et qui a laissé
  passer 8 fausses citations.

### NEXT SESSION SHOULD NOT

- **Ne pas revalider une citation d'identifiant** en testant qu'elle existe. `B5` existe et ne parle
  pas de ce qu'on aura écrit. Voir `LEARNINGS.md`, entrée du 2026-09-29.
- **Ne pas plier `B13`** en chargeant indicateur par indicateur pour « aller plus vite ».
- **Ne pas retirer la date de calcul** au survol : à cette densité, elle disparaît.

---

## 2026-09-29 — Session 5 : les trois écrans du tunnel de création

### STARTED FROM

Fin de session 4 : design system livré en `draft`, 18/19 cases du gate cochées. Reste `set-nav` non
exécuté, et **aucun écran spécifié** — la phase 3 n'est pas terminée sans eux.

### DECIDED

- **Un écran par étape du wizard**, et non un seul écran à trois onglets. Raison : chaque étape a
  **ses propres états** que les autres n'ont pas. L'étape 2 a `E2`/`E3`/`E11`/`E14`, l'étape 3 a
  `E9`/`E13`/`E1`. Un écran unique aurait eu à porter la somme des états, donc à les confondre.
- **Étape 1 — densité normale**, seule exception du produit. C'est un formulaire de trois champs :
  la densité n'y aide à rien et coûte la saisie. Le dire dans le document plutôt que de l'appliquer
  par réflexe.
- **Étape 2 — le catalogue montre les variables interdites, grisées et cliquables-pour-expliquer.**
  Un catalogue filtré par les droits semble protecteur et produit deux dégâts : l'utilisateur ne
  sait pas que la donnée existe (donc ne comprend pas pourquoi sa vue est vide, `B13`) et l'interface
  laisse croire à un bug. Marquer est plus honnête que cacher.
- **Étape 2 — `aria-disabled` et non `disabled`** sur une variable interdite : elle reste focusable,
  sinon un lecteur d'écran ne découvrira jamais l'explication — précisément le cas que `B13` veut
  servir.
- **Étape 2 — pas de glisser-déposer pour l'ordre**, seulement des boutons. Le glisser n'a pas
  d'équivalent clavier, et un ordre non accessible est un ordre absent (`B26`).
- **Étape 3 — pas de mode « aperçu »**. L'étape 3 _est_ la disposition, et elle ressemble à la vue
  publiée. Un écran d'aperçu séparé différerait de la réalité, donc l'auteur publierait autre chose
  que ce qu'il a approuvé — et le premier lecteur le constaterait.
- **Étape 3 — glisser-déposer ET boutons**, parce qu'un geste seul n'est pas accessible et un
  bouton seul est lent sur une longue vue.
- **Étape 3 — `E1` (édition concurrente) est un bandeau non bloquant** : ni écrasement, ni perte.
  Le brouillon local est conservé et l'on propose recharger / garder ma copie / annuler.
- **`E6` et `E7` ne sont pas des états d'écran mais des états d'aperçu** : ils sont portés par
  `Metric` + `StateBadge`, pas par une vue d'ensemble. Distinguer les deux évite d'inventer un état.
- **Le test `[P]` passe sur les trois écrans** — c'est le résultat attendu de la session : l'étape 3
  est entièrement composable en vue native, sans rien perdre.

### REJECTED

- **Ajouter des sections anglaises au PRD** pour faire passer `coverage-check` — c'est le contrôle
  qui est faux, pas le document. Le PRD a `## 6. Cas limites` (18 lignes) et `## 9. Hors périmètre`
  ; ajouter `## Edge cases` créerait **deux représentations du même fait**. Consigné INC-006.
- **Déclarer des slices vides** pour calmer `consistency-check` — les slices arrivent en Phase 5.
  Inventer une structure pour faire passer un contrôle, c'est lui donner tort. Consigné INC-007.
- **Un écran unique à trois onglets** pour le wizard — aurait mêlé les états des trois étapes.

### BLOCKED

- **`consistency-check` reste `pass: false`** (`screens_have_slices`, INC-007) et `coverage-check prd`
  reste `pass: false` (`Edge cases` / `Hors scope`, INC-006). **Les deux verdicts sont faux et le
  diagnostic est consigné.** Ne pas « faire passer » ces contrôles en dégradant les documents.
- **`set-nav` toujours non exécuté** : les écrans existent maintenant, la commande devient
  exécutable — mais les entrées de navigation désignent des destinations, et seules deux sont
  spécifiées (le tunnel). À trancher : `Mes vues` et `Gérer` pointent vers quelles routes ?
- **Écrans manquants** : consultation d'une vue (`US-9`, la boucle quotidienne), liste des vues
  (`US-1`), administration (`US-11`). Le tunnel est fait, la **consultation** ne l'est pas — c'est
  l'écran le plus utilisé du produit.

### FILES TOUCHED

Créés : `.forge/design/screens/wizard-etape-1-informations.md`,
`wizard-etape-2-indicateurs.md`, `wizard-etape-3-disposition.md`.

Modifiés : `.forge/prd.md` (deux fautes de langue dans un texte approuvé : `n'bewegt` en E8,
`previously` en E16 — **de-approbation, correction, re-hachage, ré-approbation**, dans cet ordre),
`.forge/audit/issues.md` (INC-006, INC-007), `SESSION_LOG.md` (cette entrée).

### STATUS

```
design-system.md                  draft
3 ecrans du flow creation-de-vue  draft, enregistres
prd · roadmap · conventions · benchmarks   approved
phases 0, 1, 2   closes
phase 3 (design) in progress — 3 ecrans sur au moins 6
unicode-scan 22 fichiers 0 probleme
forge-guard pass · placeholders pass
consistency-check FAIL (faux, INC-007) · coverage-check FAIL (faux, INC-006)
```

### NEXT SESSION SHOULD

- **Spécifier l'écran de consultation d'une vue** (`US-9`) : c'est la boucle quotidienne, et c'est
  celui où `B14`, `B22`, `B23`, `E4`, `E5`, `E6`, `E7`, `E15`, `E16`, `B30` se rencontrent. Un écran
  de plus en moins change le produit plus que le tunnel entier.
- Puis la liste des vues (`US-1`) et l'administration (`US-11`), et exécuter `set-nav` une fois les
  routes réelles nommées.
- Vérifier en Phase 5 que **chaque écran de design est couvert par une slice** — c'est là que la
  règle d'INC-007 devient applicable, et elle est bonne.

### NEXT SESSION SHOULD NOT

- **Ne pas modifier le PRD pour faire passer `coverage-check`** : les sections existent, en français.
- **Ne pas déclarer de slice en Phase 3** pour faire passer `consistency-check`.
- **Ne pas réintroduire un mode « aperçu »** à l'étape 3, ni un glisser sans équivalent clavier à
  l'étape 2.
- **Ne pas cacher les variables interdites** du catalogue : `B13` demande l'inverse.
- **Ne pas oublier la revalidation** après toute modification d'un livrable approuvé — c'est la
  séquence `set-status draft` → correction → `hash` → `set-status approved` qui a été suivie ici.

---

## 2026-09-29 — Session 4 : Phase 3, design system

### STARTED FROM

Phases 0–2 clôturées, quatre livrables approuvés, ADR-001 à ADR-008. Point dur identifié en
session 2 : le design system doit rester **exprimable chez un hôte sans DOM**, sinon Elora ne pourra
pas le consommer en V1.5 et `C6` restera une hypothèse jusqu'au bout.

### DECIDED

- **Le test de portabilité structure tout le document** (§ 0.1). Chaque ligne est marquée `[P]`
  (portable : décisions, ratios, états) ou `[W]` (web : variables CSS, pixels, animations). Un
  écran qui n'utilise que du `[P]` est portable par construction — c'est le critère qu'Elora
  vérifiera.
- **Densité retenue : dense**, justifiée par le nombre de comparaisons possibles par unité de
  temps. Grille d'indicateurs, **pas de cartes** : la carte est une ombre ou une bordure arrondie,
  donc interdite par le gate, et elle crée une frontière là où il n'y a rien à délimiter.
- **Ombre n'est pas le séparateur** : la bordure l'est. Dans une grille d'indicateurs, rien n'est
  au-dessus de rien ; l'ombre ferait dire « plus important » à chaque indicateur, donc à aucun.
- **Un seul rayon, pas d'échelle de rayons.** Une échelle signale une hiérarchie de matière ; un
  tableau de bord n'a pas de matière, il a de la densité.
- **Ratio typographique 1.2 (majorant tiers)**, chiffres tabulaires obligatoires, corps `500` pour
  un chiffre. Le ratio est une décision portable ; la police est une liaison.
- **Navigation à 2 entrées, pas 5** : « Mes vues » (quotidien) et « Gérer » (occasionnel). Pas
  d'entrée « Accueil » — elle ouvrirait une liste vide de plus. L'assistant d'installation va en
  overflow : son usage est **unique**, sa place dans le menu principal dirait qu'il fait partie de
  la boucle quotidienne.
- **Aucune animation ne porte d'information.** Sur un tableau dense, le mouvement coûte une
  information. Ce que dit la règle à un hôte sans DOM : « ne pas animer l'information », pas
  « utiliser 200 ms ».
- **Trois composants obligatoires que la plupart des design systems n'ont pas**, chacun justifié :
  `StateBadge` avec `refused` **distinct** de `error` ; `MetricGrid` à recharge qui **n'efface pas** ;
  `FilterChips` avec un état « non disponible » (absent, il serait incompréhensible).
- **Aucun skill de design externe chargé, absence justifiée** dans le gate : les contraintes
  déterminantes sont de produit (portabilité sans DOM, densité, communication d'un refus `B13`),
  pas de style. Un générateur de direction aurait produit un thème attractif et non portable.

### REJECTED

- **Fusionner `status-error` et `status-refused`** — deux diagnostics, deux actions opposées. Les
  fusionner rendrait l'impossibilité de comprendre un refus, ce que `B13` combat. Retenu aussi un
  critère de portabilité : les deux rôles sont dans des **teintes différentes**, pas deux nuances —
  un hôte sans DOM peut alors choisir deux couleurs qu'il sait distinguer.
- **Griser un chiffre périmé** — un chiffre périmé reste un chiffre ; il change de statut, pas de
  nature. Le griser le ferait disparaître, or `B14` exige qu'il reste visible.
- **Transition entre deux vues** — l'écran qui glisse fait perdre la position de lecture, et la
  position de lecture **est** l'information que l'utilisateur tient.
- **Écrire `.node-version` maintenant** — reporté en Phase 7 avec le squelette.

### BLOCKED

- **`state.js set-nav` non exécuté** : la commande est documentée avec son JSON exact, mais elle est
  dans la checklist du gate comme **à faire à la validation**, avec les écrans. L'exécuter avant
  qu'un écran existe figerait une navigation dont le contenu n'est pas spécifié.
- **Densité ↔ lisibilité sur écran étroit** : la règle (2 colonnes, défilement vertical accepté)
  est proposée, **pas validée**. C'est la contrepartie honnête du choix « dense ».
- **Thème sombre non défini** : il doublera la liaison `[W]` sans rien ajouter aux décisions `[P]`,
  donc il ne remet pas en cause la portabilité.

### FILES TOUCHED

Créés : `.forge/design/design-system.md`.

### STATUS

```
.forge/design/design-system.md  draft   enregistré, gate 18/19 cochees
                                   (manque : set-nav a la validation)
prd · roadmap · conventions · benchmarks   approved
phases 0, 1, 2   closes
phase 3 (design) in progress
13 marqueurs [P], 8 marqueurs [W]
```

### NEXT SESSION SHOULD

- **Spécifier les écrans**, en commençant par le **parcours de création en 3 étapes** (`US-2`/`US-3`/
  `US-4`) : c'est un tunnel (`transactional_web`) dans un produit `dashboard`, donc l'écran le plus
  contraint — et la première cible du test `[P]`.
- Exécuter `state.js set-nav` une fois les écrans nommés, puis cocher la dernière case du gate.
- Trancher la règle densité/lisibilité sur écran étroit, et décider si le thème sombre fait partie
  du périmètre de la Phase 3.

### NEXT SESSION SHOULD NOT

- **Ne pas réintroduire d'ombre comme séparateur**, ni de cartes dans une grille d'indicateurs :
  les deux sont des contre-decisions assumées, pas des oublis.
- **Ne pas animé** une valeur, un résultat ou un filtre : aucune animation ne porte d'information.
- **Ne pas fusionner `refused` et `error`**, ni les placer dans la même famille de teinte : la
  distinction doit survivre à un hôte qui ne voit que des couleurs.
- **Ne pas traiter un `[W]` comme portable** en le recopiant dans une spécification d'écran.
- **Ne pas rouvrir** : ADR-005 à ADR-008, le découpage en 5 tranches, la densité `dense`, la
  navigation à 2 entrées.

---

## 2026-09-29 — Session 3 : les trois points ouverts de la roadmap

> Trois questions ouvertes en fin de session 2. Deux tranchées par l'utilisateur, une découverte en
> route qui a produit un incident d'outillage.

### STARTED FROM

Fin de session 2 : roadmap approuvée, phase 2 clôturée, commit `45dd920`. Trois points étaient
laissés ouverts à la validation : le moteur de requêtes, le statut de `benchmarks.md`, et le projet
hôte du MVP.

### DECIDED

- **Moteur de requêtes : adaptateur** (ADR-007). Le socle définit le port d'exécution, ne connaît
  aucun moteur. Un registre de moteurs est refusé : il repose sur un moteur « similaire » chez
  l'hôte, or « similaire » n'est pas un contrat. Une dépendance de moteur est **la manière la plus
  discrète de rendre un socle non réutilisable** — elle ne se découvre qu'à l'intégration, donc trop
  tard.
- **`benchmarks.md` approuvé, clause de verdict retirée.** Le `PASS` était un auto-contrôle de
  l'agent ; le faire valider par la même personne qui l'a écrit aurait donné à un jugement
  l'autorité d'une mesure. Remplacé par un tableau d'**écarts constatés** : ce que la comparaison
  a montré, et la décision prise pour chacun.
- **Pilote du MVP : `ace3i-bankingsms-ui`** (ADR-006) — le seul candidat avec un **vrai** système
  d'autorisation derrière. Un hôte neuf sans droits préexistants ferait tester les **trois
  contrôles** (`NFR §7.2`), `B25` et `B31`–`B35` contre un faux écrit par nous, ce que
  `security.md` interdit.
- **Exception documentaire, pas outillage** : `state.json` conserve `read_only: true`.
- **Le code se développe ici, l'intégration s'installe là-bas** (ADR-006 § « Où vit le code », fin
  de session 3). `pilot/` et `src/**` restent dans ce dépôt ; `ace3i` ne reçoit qu'un point
  d'entrée. La formulation « on installe dans le SMS banking lorsque nécessaire » a tranché le
  point resté ouvert en fin de phase 2.

### REJECTED

- **`read_only: false` à la main dans `state.json`** (option A2). Éditer l'autorité à la main est
  l'interdit même qu'on pretend respecter ; surtout, `forge-guard.js:130-131` utilise
  `reference_projects` pour **ignorer** un livrable Forge écrit dans une référence : passer le champ
  à `false` **désarmerait ce garde-fou silencieusement**. Une exception mesurée vaut mieux qu'une
  protection désarmée.
- **Elora comme hôte des droits pour le MVP** — Elora est déjà le second hôte de la **V1.5** ;
  l'utiliser deux fois ferait de la V1.5 un test contre lui-même.
- **Un dépôt neuf comme pilote** — respecte la frontière, mais teste les règles de sécurité contre
  un faux auto-écrit.

### BLOCKED

- ~~**Le pilote écrit _dans_ `ace3i-bankingsms-ui` ou _dans ce dépôt_ ?**~~ **Tranché en fin de
  session 3** : le code se développe **ici** (`pilot/`, `src/**`) ; `ace3i` ne reçoit qu'un point
  d'entrée d'intégration, réversible et séparé. Voir ADR-006 § « Où vit le code ».
- **INC-005 non corrigé** : l'outillage n'a pas de commande pour lever un `read_only`, et le champ
  est en réalité une **donnée de contrôle**, pas un libellé.

### FILES TOUCHED

- **Le code se développe ici, l'intégration s'installe là-bas** (ADR-006 § « Où vit le code », fin
  de session 3). `pilot/` et `src/**` restent dans ce dépôt ; `ace3i` ne reçoit qu'un point
  d'entrée. La formulation « on installe dans le SMS banking lorsque nécessaire » a tranché le
  point resté ouvert en fin de phase 2.
- **Gestionnaire `bun`, Node épinglé par `.node-version`** (ADR-008, fin de session 3). Raison
  réelle : le socle devant devenir un package npm, développer avec `npm` et publier avec `bun`
  exposerait deux arbres de dépendances — donc « ce qui est testé » cesserait d'être « ce qui est
  publié ». L'argument d'origine de `conventions.md` (« cohérence avec l'app de référence ») est
  **abandonné** : `ace3i` est en lecture seule, un dépôt indépendant n'hérite pas de son
  gestionnaire. Même caducité sur les lignes Lint et Format.
  `.forge/audit/issues.md` (INC-005 ouvert), `.forge/benchmarks.md` (verdict → écarts constatés,

- un mot manquant restauré ligne 150), `AGENTS.md` (interdits absolus), `.forge/conventions.md`,
  `.forge/roadmap.md` (points ouverts soldés), `SESSION_LOG.md` (cette entrée), `.gitignore`
  (lockfiles `bun`, `node_modules` du projet distinct de l'outillage Forge).

### STATUS

```
.forge/prd.md          approved
.forge/roadmap.md      approved
.forge/conventions.md  approved
.forge/benchmarks.md   approved   <- désormais approuvé, verdict retiré
phases 0, 1, 2         closes
phase 3 (design)       not_started
reference read_only    true ( intact,.outillage de protection armé )
0 divergence, 0 livraison périmée
```

### NEXT SESSION SHOULD

- **Phase 3 — design**, avec le point dur identifié en session 2 : le design system doit rester
  **exprimable chez un hôte sans DOM** (ADR-004), sinon Elora ne pourra pas le consommer en V1.5
  et `C6` restera hypothétique. Chaque choix visuel doit survivre à « un composant React Native
  pourrait-il rendre ça ? ».
- Trancher le lieu d'écriture du pilote **avant** la Phase 4 : les ADR-006 et ADR-007 sont
  conditionnés par ce point.
- Passer `unicode-scan` **et** relire le français à la main. Le scan a trouvé un `U+6D3B` que le
  grep avait laissé passer ; le grep a trouvé « Le PRD traits de la vue » que le scan n'avait pas
  vu. Aucun des deux instruments ne suffit seul.

### NEXT SESSION SHOULD NOT

- **Ne pas écrire dans `Elora`** — lecture seule, sans exception. L'exception d'ADR-006 ne couvre
  que `ace3i-bankingsms-ui`.
- **Ne pas développer de code du socle dans `ace3i-bankingsms-ui`.** Seul un point d'entrée
  d'intégration s'y installe, réversible et séparé (ADR-006). Le socle vit dans `pilot/` et
  `src/**` de ce dépôt.
- **Ne pas passer `read_only` à `false`** pour « faire marcher » une exception : le bon ordre est
  décision dans `DECISIONS.md`, puis signalement dans `.forge/audit/issues.md` (INC-005).
- **Ne pas réintroduire de `PASS` / verdict d'auto-contrôle** dans un livrable, et ne pas le faire
  valider par la même personne qui l'a écrit.
- **Ne pas rouvrir** : ADR-005 (shadcn défaut), ADR-006 (exception documentaire + code ici),
  ADR-007 (adaptateur), ADR-008 (`bun` + `.node-version`), le découpage en 5 tranches, l'absence
  de dates.
- **Ne pas exécuter les scripts Forge avec `bun`.** Ce sont des scripts CommonJS d'un actif
  partagé ; changer d'exécuteur changerait leur comportement sans signal. `node` pour l'outillage,
  `bun` pour le projet.
- **Ne pas figer une version de Node en dur** dans une commande ou un script : `.node-version` +
  `fnm` sont le canal. Un `fnm use` hors du bon répertoire change le runtime sans avertissement.
- **Ne pas écrire un `.node-version` avant le squelette du projet** (Phase 7) : une version
  inventée aujourd'hui serait fausse au moment où le fichier est réellement créé.
- **Ne pas avancer la Phase 3 sans approbation explicite.**

---

## 2026-09-29 — Session 2 : git, `SESSION_LOG.md`, et roadmap

> Cette entrée est **ajoutée** en fin de session 2, pas réécrite dans la session 1. Le fichier est
> append-only : la session 1 dit ce qu'elle croyait vrai à ce moment-là, y compris ses erreurs.

### STARTED FROM

La session 1 s'était terminée sur un commit initial (`00709bd`, 21 fichiers) et un projet en
Phase 2. Deux points restaient ouverts en suspens :

1. L'utilisateur cherchait un `SESSION_LOG.md` que le skill `project-rules-architect` exige et
   qu'ADR-004 avait écarté à tort.
2. `state.js start` rapportait `dod_items: 0`, `escalation: false`, `learnings: 0` sur des fichiers
   manifestement remplis.

### DECIDED

- **Option A : créer `SESSION_LOG.md`** et **amender ADR-004** plutôt que le supprimer. Le tableau
  de répartition du skill (`SKILL.md` l. 38) attribue `SESSION_LOG.md` à ce skill et ne
  l'attribue à aucun autre : un contrat d'agencement prime sur une décision de session.
- **Le journal machine et le journal humain sont deux faits distincts.** `run-log.jsonl` enregistre
  _quelles commandes ont tourné_ ; `SESSION_LOG.md` enregistre _ce qui a été décidé et pourquoi_.
  Aucun ne dérive de l'autre.
- **Roadmap en 5 tranches** : Fondations → MVP → V1 → **V1.5** → V2+. La V1.5 est la tranche qui
  rend `C6` vérifiable — sans elle, « réutilisable » reste une hypothèse et la sortie du
  monolithe n'a aucun déclencheur.
- **Aucune date dans la roadmap** : aucune mesure de vélocité n'existe sur ce projet.
- **Le skill `forge` n'est pas modifié** (décision de l'utilisateur : actif partagé, à améliorer
  dans une session dédiée). Le défaut est consigné comme **INC-004, ouvert**.

### REJECTED

- **ADR-004 dans sa version initiale** (« pas de `SESSION_LOG.md` car Forge tient déjà le journal »)
  — c'est la faute de la session 1, et c'est en la corrigeant qu'on a compris le vrai criterion.
- **Corriger les ancres anglaises de `state.js` dans ce projet** — au profit d'un signalement
  dans `.forge/audit/issues.md`, pour ne pas figer un correctif dans un dépôt de produit.
- **Une V2 détaillée dans la roadmap** — écrire des priorités sans retour de la V1, c'est inventer.
  La section 6 est un carnet de candidats avec **conditions d'entrée**.
- **`npm run lint` / `typecheck` dans la revue pré-commit** — il n'y a pas de `package.json`.
  Les cocher aurait été un contrôle jamais exécuté présenté comme une mesure.

### BLOCKED

- **Moteur de requêtes : adaptateur ou dépendance ?** Non tranché, renvoyé en Phase 4. C'est le
  choix le plus structurant : si c'est une dépendance, `C6` est faux et la V1.5 échouera.
- **`benchmarks.md` toujours en `draft`**, alors que la roadmap s'appuie sur ses invariants.
- **Aucun projet hôte désigné pour le MVP** — conditionne la V1.5.
- **INC-004 non corrigé** : `state.js start` reste non fiable sur ce dépôt. Conséquence inscrite
  dans `DECISIONS.md` et ici : ne jamais citer un compteur de `state.js` sans l'avoir vérifié par
  lecture directe.

### FILES TOUCHED

Créés : `.gitignore`, `.gitattributes`, `.forge/roadmap.md`.

Modifiés : `SESSION_LOG.md` (créé puis cette entrée ajoutée), `DECISIONS.md` (ADR-004 amendé avec
son analyse d'erreur, et sa conséquence `dod_items: 0` retirée du statut de mesure),
`AGENTS.md` (§ Mémoire inter-sessions : 4 fichiers), `.opencode/rules/workflow.md` (gate du journal
de session), `LEARNINGS.md` (+1 correction), `.forge/audit/issues.md` (INC-004 ouvert).

### STATUS

```
.forge/prd.md          approved   B1–B37, 14 US, 11 points §12 tranchés
.forge/roadmap.md      approved   5 tranches, 0 P1 en V2+, 3 points ouverts
.forge/conventions.md  approved   stack arrêtée, 5 sections à trancher en Phase 4
.forge/benchmarks.md   draft      3 produits comparés
phases 0, 1, 2         closes
phase 3 (design)       not_started
0 gate en attente, 0 divergence, 0 livraison périmée
```

### NEXT SESSION SHOULD

- **Phase 3 — design** : `.forge/design/design-system.md`, puis les écrans du parcours de création
  en 3 étapes. Le point dur n'est pas l'esthétique mais la **frontière du registre de composants**
  (ADR-004) : le design doit rester exprimable chez un hôte sans DOM, sinon Elora ne pourra pas le
  consommer en V1.5.
- Trancher les 3 points ouverts de la roadmap avant de verrouiller la stack en Phase 4 : moteur de
  requêtes, statut de `benchmarks.md`, projet hôte du MVP.
- Passer `tooling/unicode-scan.cjs` avant chaque livraison, **et** relire à la main le français :
  le scan a trouvé un `U+6D3B` dans la roadmap que le grep avait laissé passer. Les deux
  instruments ensemble, jamais un seul.

### NEXT SESSION SHOULD NOT

- **Ne pas rouvrir** : le découpage en 5 tranches, l'absence de dates, l'option A du journal de
  session, ni les points déjà tranchés en session 1 (`B29`–`B37`, ADR-002 à ADR-005).
- **Ne pas modifier le skill `forge` dans ce dépôt.** Le défaut est signalé (INC-004) ; le corriger
  dans un produit figerait un correctif au mauvais endroit. **Exception** : les corrections 3 et 4
  des agents, **validées par l'utilisateur et éprouvées** (session 13, rapport
  `.forge/audit/agents-v2-test-report.md`). Elles vivent dans l'installation locale
  (`.agents/skills/` est gitignoré), donc elles ne sont **pas** versionnées avec le produit — d'où
  l'obligation de garder le rapport dans `.forge/audit/`.
- **Ne pas citer un compteur de `state.js start`** (`dod_items`, `learnings`, `escalation`) : ils
  lisent des ancres anglaises dans des documents français et rapportent `0` sans prévenir. Vérifier
  par lecture directe du fichier.
- **Ne pas faire passer la Phase 3 sans approbation explicite.**

---

## 2026-09-29 — Session 1 : cadrage, PRD, benchmark, décisions d'architecture

### STARTED FROM

Aucun code. Deux documents d'analyse hérités d'un autre dépôt, en **lecture seule** :
`.opencode/plan/bi-dashboard-platform-prd-en.md` et `bi-dashboard-platform-analysis-fr.md`, plus une
proposition de direction sur des vues configurables pour le projet SMS Banking. Aucun livrable
existant, aucun état Forge.

Le projet SMS Banking (`ace3i-bankingsms-ui`) est désigné **projet de référence en lecture seule** :
il sert à valider que le socle est réutilisable, jamais à y écrire.

### DECIDED

- **Forge plutôt qu'un plan libre.** Dossier `bi-dashboard-platform` créé, `.forge/` initialisé,
  phases 0 et 1 bouclées. `state.json` v2 devient l'autorité des statuts.
- **PRD générique, pas un PRD SMS.** Le projet SMS devient un _hôte de validation_ en annexe, pas
  le sujet. Règles `B1`–`B37`, cas limites `E1`–`E18`, contraintes `C1`–`C12`, 14 user stories.
- **Quatre règles nées de la comparaison produits** (Retool, Power BI, Metabase, dans
  `.forge/benchmarks.md`) : `B23` l'auteur est soumis aux mêmes restrictions que le lecteur,
  `B24` retour arrière dans l'assistant, `B25` contrôle sur **tout** chemin vers les données,
  `B26` ordre et déduplication stables.
- **`C6` → Elora** (Expo/React Native) comme second projet hôte, **sans** le déclarer « projet de
  référence » : c'est un consommateur, pas une source. Raison retenue : « sans DOM » prouve la
  portabilité mieux qu'un second projet web.
- **Conservation du journal** (`B29`) : 3 à 12 mois, fenêtre chaude 1 à 3 mois, défaut 12/3, calé
  sur PCI DSS 4.0.1 §10.5.1.
- **Drill-down** (`B30`) : filtrage croisé en V1, pas de descente en détail.
- **shadcn est le design system par défaut, jamais une dépendance** (ADR-005). Confirmé par lecture
  du code de la CLI : shadcn fonctionne par **copie de code source**. Conséquence inscrite en
  `.opencode/rules/architecture.md` : `src/core` et `src/react` n'importent jamais un chemin
  `@/components/ui/...`, qui n'existe que dans un projet ayant lancé la CLI.
- **Droits : `journal:read` distinct** de l'administration des vues (`B31`–`B35`), et surtout —
  **actions, pas rôles** : le socle nomme des capacités, l'hôte décide qui les détient (ADR-002).
- **Un seul pouvoir d'écriture** : `view:create` / `view:update` / `view:delete` fusionnés en
  `view:write` (`B36`), parce qu'aucun n'est accordable sans les autres. L'écriture **remplace**
  l'état courant sans détruire l'historique des versions (`B37`).

### REJECTED

- **ADR-004, « pas de `SESSION_LOG.md` parce que Forge tient déjà le journal »** — décision de
  session, **amendée dans cette même session**. Le tableau de répartition du skill
  `project-rules-architect` attribue explicitement `SESSION_LOG.md` à ce skill et ne l'attribue à
  aucun autre. La justification d'origine confondait un journal **machine** avec un journal de
  **session**. Ce fichier est donc créé, et l'ADR est corrigée plutôt que supprimée.
- **Le profil de règles `nextjs-redux-axios`** : sa stack (Redux, axios, Formik) contredit
  l'architecture décidée. Les règles ont été écrites de zéro, sans le profil.
- **Un second projet de référence** : déclarer Elora « projet de référence » aurait confondu un
  consommateur avec une source, et justifié à tort une interdiction d'écriture.
- **`shadcn` en dépendance dure** : casse `C1`/`C3` et rend `C6` impossible avec Elora.
- **Fusion « écrire = supprimer la version précédente »** : le raisonnement est juste pour l'état
  courant, faux pour l'historique. L'accepter tel quel aurait rendu la restauration d'une version
  antérieure impossible. D'où `B37`.

### BLOCKED

- `C6` (extraction en bibliothèque) reste **ouverte jusqu'au second hôte** : tant qu'aucun second
  projet n'a consommé le socle, « réutilisable » reste une hypothèse. Elle ne bloque pas le pilote.
- Vérifier si les skills `forge` et `project-rules-architect` ont été modifiés localement n'est pas
  possible : `skills-lock.json` ne porte que des empreintes de référence, sans date ni comparaison.
- **`state.js start` ne sait pas lire la mémoire du projet en français.** `dod_items: 0`,
  `escalation: false`, `learnings: 0` sont des **faux zéros** : `AGENTS.md` et `LEARNINGS.md` sont
  remplis, l'outil cherche des ancres anglaises et ne signale pas qu'il n'a rien reconnu. Signalé
  comme **INC-004**, non corrigé — décision de l'utilisateur : le skill est un actif partagé, à
  améliorer dans une session dédiée. **Conséquence pratique : ne jamais citer un compteur de
  `state.js start` sur ce dépôt sans l'avoir vérifié par lecture directe du fichier.**

### FILES TOUCHED

Créés : `AGENTS.md`, `DECISIONS.md`, `LEARNINGS.md`, `SESSION_LOG.md`, `.opencode/rules/` (6
fichiers), `tooling/unicode-scan.cjs`, `tooling/scan-selftest.cjs`, `.forge/` (4 livrables +
`state.json` + 2 journaux d'audit).

Modifiés cette session : `.forge/prd.md` (statut passé `draft` → `approved` → `draft` → `approved`
après l'ajout des règles `B31`–`B37`), `.forge/conventions.md`, `.forge/benchmarks.md`,
`DECISIONS.md` (ADR-001 → ADR-005), `LEARNINGS.md` (+4 corrections), `.opencode/rules/security.md`,
`.opencode/rules/architecture.md`, `.forge/audit/issues.md` (INC-001 → INC-003).

### STATUS

```
.forge/prd.md          approved   B1–B37, E1–E18, C1–C12, 14 US, 11 points §12 tranchés
.forge/conventions.md  approved   stack arrêtée, 5 sections à trancher en Phase 4
.forge/benchmarks.md   draft      3 produits comparés, invariants + écarts assumés
phases 0 et 1          closes
phase 2 (roadmap)      not_started
0 gate en attente, 0 divergence, 0 livraison périmée
```

### NEXT SESSION SHOULD

- Attaquer la **Phase 2 — roadmap** : découper en MVP / V1 / V2+, avec pour chaque version ce qu'on
  y met, ce qu'on repousse, et **pourquoi**. Le découpage est plus net maintenant qu'il existe un
  vocabulaire d'actions : chaque tranche peut dire quelles actions elle expose.
- Décider des 5 sections de `conventions.md` marquées `À DÉCIDER EN PHASE 4` — en fait, la phase 4
  est le verrouillage de la stack, donc ces points reviennent sous une autre forme.
- Passer `tooling/unicode-scan.cjs` avant **chaque** livraison. Le scan détecte les caractères hors
  contexte mais **pas** le texte anglais inséré dans du français : un grep manuel reste obligatoire.
  Il a trouvé une dizaine de fautes que le scan ne voyait pas.

### NEXT SESSION SHOULD NOT

- **Ne pas ré-ouvrir les points tranchés** sans le dire explicitement : `B29` (rétention), `B30`
  (drill-down), `B31`–`B35` (`journal:read`), `B36`–`B37` (`view:write`), ADR-002 (le client n'est
  jamais la frontière), ADR-005 (shadcn défaut et non dépendance).
- **Ne pas éditer `status:` à la main** : passer par `state.js set-status`. Un statut écrit à la
  main dans le corps d'un `.forge/*.md` devient faux dès la mise à jour suivante — c'est arrivé
  dans cette session, sur `prd.md` et `conventions.md`.
- **Ne pas laisser un livrable `approved` après l'avoir modifié.** Remettre `draft`, re-hacher,
  faire ré-approuver. `forge-guard` échoue sur `content_hashes_current` — c'est le comportement
  voulu, pas un bug à contourner.
- **Ne pas filtrer un inventaire de fichiers pour alléger la sortie.** `-Exclude "*.jsonl"` a masqué
  le journal de session et j'ai conclu à tort qu'il n'existait pas.
- **Ne pas deviner le schéma d'un journal de données** : j'ai affiché `event`/`phase`/`key` au
  lieu de `type` et obtenu des colonnes vides. Une colonne vide signale une requête fausse, pas une
  donnée absente.
- **Ne pas écrire dans `ace3i-bankingsms-ui`**, ni dans `Elora`, **sauf l'exception de l'ADR-006**
  (`ace3i` devient le pilote du MVP, mais `state.json` conserve `read_only: true`).
